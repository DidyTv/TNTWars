package me.Mr_Coding.tntwars.start;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;

public class Map_Reset implements Listener {
	
	private Plugin plugin;
	public Map_Reset(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}
	
	


	public World resetMap(File backup, File reset, String worldname) throws IOException {
		
		for(Player all : Bukkit.getOnlinePlayers()) {
			all.teleport(Bukkit.getWorld("world").getSpawnLocation());
		}
		
		Bukkit.unloadWorld(worldname, true); // true = welt speichern
		
		try {
			FileUtils.deleteDirectory(reset);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if(!(reset.exists())) {
			try {
				FileUtils.copyDirectory(backup, reset);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		World world = Bukkit.createWorld(new WorldCreator(worldname));
		return world;
		
	}
	
	

}
