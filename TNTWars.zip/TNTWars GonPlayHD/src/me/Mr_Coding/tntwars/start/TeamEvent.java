package me.Mr_Coding.tntwars.start;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class TeamEvent implements Listener {
	
	private start plugin;
	public TeamEvent(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}

	final static String prefix = "�2[�4TNT�6Wars�2]�d ";
	
	
	
	@EventHandler
	public void onItemInCompassClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		
		if(p.getItemInHand().getType().equals(Material.COMPASS)) {
			if(e.getInventory().getName().equalsIgnoreCase(ChatColor.GREEN + "Team w�hlen")) {
				try {
					if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.RED + "Rot")) {
						e.setCancelled(true);
						if(GameManager.rot.size() > 1) {
							p.sendMessage(prefix + "Das Team " + ChatColor.RED + "Rot " + ChatColor.LIGHT_PURPLE + "ist " + ChatColor.RED + "voll!");
						} else {
							if(GameManager.rot.contains(p)) {
								p.sendMessage(prefix + "Du bist bereits in Team " + ChatColor.RED + "Rot!");
							} else {
								GameManager.rot.add(p);
								GameManager.blau.remove(p);
								GameManager.noTeam.remove(p);
								p.sendMessage(prefix + "Du bist nun in Team " + ChatColor.RED + "Rot");		
							}
						}
					}
					
					if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.BLUE + "Blau")) {
						e.setCancelled(true);
						if(GameManager.blau.size() > 1) {
							p.sendMessage(prefix + "Das Team " + ChatColor.BLUE + "Blau" + ChatColor.LIGHT_PURPLE + "ist " + ChatColor.RED + "voll!");
						} else {
							if(GameManager.blau.contains(p)) {
								p.sendMessage(prefix + "Du bist bereits in Team " + ChatColor.BLUE + "Blau!");
							} else {
								GameManager.blau.add(p);
								GameManager.rot.remove(p);
								GameManager.noTeam.remove(p);
								p.sendMessage(prefix + "Du bist nun in Team " + ChatColor.BLUE + "Blau");	
							}
						}
					}
				} catch(Exception ex) {}
			}
		}
	}
	
}
