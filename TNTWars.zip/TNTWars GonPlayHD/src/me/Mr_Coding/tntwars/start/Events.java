package me.Mr_Coding.tntwars.start;

import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;

public class Events implements Listener {
	
	

	private Plugin plugin;
	public Events(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}
	
	

	
}
