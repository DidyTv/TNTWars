package me.Mr_Coding.tntwars.start;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventException;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class GameManager implements Listener {
	
	private start plugin;

	public GameManager(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}

	private HashMap<World, Boolean> active = new HashMap<World, Boolean>();
	
	
	
	public void startSpawners(String Worldname) {
		for(World worlds : Bukkit.getWorlds()) {
			if(worlds.getName().equalsIgnoreCase(Worldname)) {
				active.put(worlds, true);
			}
		}
		
		Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {

			@Override
			public void run() {
				
				for(World world : Bukkit.getWorlds()) {
					if(world.getName().equalsIgnoreCase(Worldname)) {
						int Count = plugin.getConfig().getInt("GameWorld." + world.getName() + ".Spawners.Count");
						
						try {
							
							for(int i = 0; i < Count + 1; i++) {
								try {
									for(World tempworld : Bukkit.getWorlds()) {
										if(plugin.getConfig().getString("GameWorld." + world.getName() + ".Spawners." + i + ".World").equalsIgnoreCase(tempworld.getName())) {
											//Location -1
											Location loc = new Location(tempworld, plugin.getConfig().getDouble("GameWorld." + world.getName() + ".Spawners." + i + ".X"),
													plugin.getConfig().getDouble("GameWorld." + world.getName() + ".Spawners." + i + ".Y"),
													plugin.getConfig().getDouble("GameWorld." + world.getName() + ".Spawners." + i + ".Z"));
											//Location -2
											
											
											ItemStack IS_BronzXP = new ItemStack(Material.CLAY_BRICK);
											ItemMeta IM_BronzXP = IS_BronzXP.getItemMeta();
											
											ArrayList<String> BronzXPLore = new ArrayList<String>();
											BronzXPLore.add("�6XP");
											IM_BronzXP.setLore(BronzXPLore);
											IS_BronzXP.setItemMeta(IM_BronzXP);
											
											
											loc.getWorld().dropItemNaturally(loc, IS_BronzXP);
											
										}
									}
								} catch (Exception ex) {  }
							}
						} catch (Exception ex) {  }
					}
				}
			}
			
		}, 20, 20);
	}
	
	public void stopSpawners(String Worldname) {
		for(World world : Bukkit.getWorlds()) {
			if(world.getName().equalsIgnoreCase(Worldname)) {
				try {
					active.put(world, false);
				} catch (Exception e) {  }
			}
		}
	}

	public static GameManager CurrentState;
	
	//Game Funktion
	
	public static int GameFullint = 0;

	public static ArrayList<Player> rot = new ArrayList<>();
	public static ArrayList<Player> blau = new ArrayList<>();
	public static ArrayList<Player> noTeam = new ArrayList<>();
	
	
	
	
	public static boolean isGameFull() {
		if(GameFullint > 4) {
			return true;
		} else {
			return false;
		}
	}
	
	
	
	//Game mechanik
	
	public static void setState(GameManager state) {
		GameManager.CurrentState = state;
	}
	
	public static boolean isState(GameManager state) {
		return GameManager.CurrentState == state;
	}
	
	public static GameManager getState() {
		return CurrentState;
	}
	
	public static GameManager Lobby() {
		return CurrentState;
	}
	
	public static GameManager Game() {
		return CurrentState;
	}
	
	public static GameManager Restart() {
		return CurrentState;
	}
	
	public static String getStatus() {
		String s = "";
		
		if(isState(GameManager.Lobby())) {
			s = ChatColor.GOLD + "Lobby";
		}
		
		if(isState(GameManager.Game())) {
			s = ChatColor.GOLD + "Game";
		}
		
		if(isState(GameManager.Restart())) {
			s = ChatColor.GOLD + "Restart";
		}
		return s;
	}
	
	@EventHandler
	public void onPickUpItem(PlayerPickupItemEvent e) throws EventException {
		Player p = e.getPlayer();
		ItemStack Item = e.getItem().getItemStack();
		ItemMeta ItemM = Item.getItemMeta();
		try {
			if(ItemM.getLore().contains("�6XP")) {
				e.setCancelled(true);
				p.getWorld().playSound(p.getLocation(), Sound.ORB_PICKUP, 0.2f, 0.2f);
				e.getItem().remove();
				int Amount = Item.getAmount();
				for (int i = 0; i < Amount; i++) {
					if(p.getExp() > 0.97) {
						double tmpxp = p.getExp();
						p.setLevel(p.getLevel() + 1);
						tmpxp = 1D - tmpxp;
						p.setExp((float) tmpxp);
					} else {
						p.setExp((float) (p.getExp() + 0.03));
					}
				}
			}
		} catch (Exception ex) {  }
	}
	
	@EventHandler
	public void onPlayerDeath(PlayerDeathEvent e) {
		Player p = e.getEntity();
		Bukkit.broadcastMessage(p.getName());
		
		if(GameManager.blau.contains(p) || GameManager.rot.contains(p)) {
			p.sendMessage(start.prefix + "�cDu bist �ngestorben�c!");
			for(Player all : Bukkit.getOnlinePlayers()) {
				if(GameManager.rot.contains(all) && !all.equals(p) || GameManager.blau.contains(all) && !all.equals(p)) {
					all.sendMessage(start.prefix + "Der Spieler " + all.getName() + " ist �c�ngestorben�c!");
				}
			}
		}
		
	}
	
	
}
