package me.Mr_Coding.tntwars.items;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import me.Mr_Coding.tntwars.start.start;

public class GranadeThrower implements Listener {
	
	private start plugin;

	public GranadeThrower(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}

	private ArrayList<Player> CantThrow = new ArrayList<Player>();
	private HashMap<Player, Integer> CantThrowTime = new HashMap<Player, Integer>();
	
	
	
	
	public static void Common(Player p, int slot, int size) {
		ItemStack GranadeThrower = new ItemStack(Material.DIAMOND_SWORD);
		GranadeThrower.setAmount(size);
		ItemMeta GranadeThrowerMeta = GranadeThrower.getItemMeta();
		
		
		GranadeThrowerMeta.setDisplayName("�6Normaler Granatwerfer");
		
		ArrayList<String> GranadeThrowerlore = new ArrayList<>();
		GranadeThrowerlore.add(ChatColor.LIGHT_PURPLE + "�66");
		
		GranadeThrowerMeta.setLore(GranadeThrowerlore);
		GranadeThrower.setItemMeta(GranadeThrowerMeta);
		
		p.getInventory().setItem(slot, GranadeThrower);
		return;
	}
	
	public static void Common(Player p, int size) {
		ItemStack GranadeThrower = new ItemStack(Material.DIAMOND_SWORD);
		GranadeThrower.setAmount(size);
		ItemMeta GranadeThrowerMeta = GranadeThrower.getItemMeta();
		
		
		GranadeThrowerMeta.setDisplayName("�6Normaler Granatwerfer");
		
		
		GranadeThrower.setItemMeta(GranadeThrowerMeta);

		p.getInventory().addItem(GranadeThrower);
		return;
	}
	
	@EventHandler
	public void onSpawn(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		
		if(e.getAction() == Action.RIGHT_CLICK_BLOCK || e.getAction() == Action.RIGHT_CLICK_AIR) {

			if(e.getMaterial() == Material.DIAMOND_SWORD) {
				try {
					if(e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "Normaler Granatwerfer")) {
						//Testen ob der Spieler Granate werfen kann
						if(CantThrow.contains(p)) {
							p.sendMessage(start.prefix + "�cL�dt nach... Remaining Time: �a" + CantThrowTime.get(p));
							return;
						}
						
						CantThrow.add(p);
						
						Item Granade = p.getWorld().dropItem(p.getEyeLocation(), new ItemStack(Material.MONSTER_EGG));
						
						Granade.setVelocity(p.getLocation().getDirection().multiply(2));
						Granade.setPickupDelay(90000);
						
						
						//Sounds - 1
						//1
						Granade.getWorld().playSound(Granade.getLocation(), Sound.CHICKEN_WALK, (float) 1, 100);	
						
						//2
						Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

							@Override
							public void run() {
								Granade.getWorld().playSound(Granade.getLocation(), Sound.CHICKEN_WALK, (float) 1, 100);
							}
						}, 20*1);	
						
						//3
						Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

							@Override
							public void run() {
								Granade.getWorld().playSound(Granade.getLocation(), Sound.CHICKEN_WALK, (float) 1, 100);
							}
						}, 20*2);	
						
						//4
						Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

							@Override
							public void run() {
								Granade.getWorld().playSound(Granade.getLocation(), Sound.CHICKEN_WALK, (float) 1, 100);
							}
						}, 20*3);	
						
						//Explode
						Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

							@Override
							public void run() {
								Granade.getWorld().createExplosion(Granade.getLocation(), 3, false);
								Granade.remove();
							}
						}, 20*4);
						//Sounds - 2
						
						
						//CantThrow removen -> Spieler kann wieder Granate werfen
						RemoveCantThrow(p);
					}
				} catch(Exception ex) {Bukkit.getConsoleSender().sendMessage("�4Critial ERROR: �cPlease Report this to �aMr_Coding! �3ERRORCODE: �aGT_PIT_SWITCH_NO_SETDOWN");}

			}
		}
		
	}
	
	private void RemoveCantThrow(Player p) {
		CantThrowTime.put(p, 10);
		

		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 9);
			}
			
		}, 20*1);

		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 8);
			}
			
		}, 20*2);

		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 7);
			}
			
		}, 20*3);

		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 6);
			}
			
		}, 20*4);

		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 5);
			}
			
		}, 20*5);

		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 4);
			}
			
		}, 20*6);

		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 3);
			}
			
		}, 20*7);

		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 2);
			}
			
		}, 20*8);
		
		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 1);
			}
			
		}, 20*9);
		
		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

			@Override
			public void run() {
				CantThrowTime.put(p, 0);
				CantThrow.remove(p);
				p.sendMessage(start.prefix + "Granate Werfer �anachgeladen!");
			}
			
		}, 20*10);
	}
	
	

}
