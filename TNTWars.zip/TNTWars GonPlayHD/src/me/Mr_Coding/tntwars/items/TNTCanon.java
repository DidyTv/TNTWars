package me.Mr_Coding.tntwars.items;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

import me.Mr_Coding.tntwars.start.HimmelsRichtung;
import me.Mr_Coding.tntwars.start.start;
import net.md_5.bungee.api.ChatColor;

public class TNTCanon implements Listener {
	
	private Plugin plugin;
	public TNTCanon(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}
	
	
	int SchedTNTCanonNorden;
	
	private ArrayList<Player> inTNTCanon = new ArrayList<>();
	
	
	
	
	public static void TNTCanon(Player p, int slot, int size) {
		ItemStack TNTCanon = new ItemStack(Material.MONSTER_EGG);
		TNTCanon.setAmount(size);
		TNTCanon.setDurability((short) 93);
		ItemMeta TNTCanonMeta = TNTCanon.getItemMeta();
		
		TNTCanon.setDurability((short) 0);
		
		TNTCanonMeta.setDisplayName(ChatColor.GOLD + "TNTCanon");
		
		ArrayList<String> Granadelore = new ArrayList<>();
		Granadelore.add(ChatColor.LIGHT_PURPLE + "Place it in your eyes direction!");
		
		TNTCanonMeta.setLore(Granadelore);
		TNTCanon.setItemMeta(TNTCanonMeta);
		
		p.getInventory().setItem(slot, TNTCanon);
		return;
	}
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onPlayerInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		if(e.getAction() == Action.RIGHT_CLICK_BLOCK || e.getAction() == Action.RIGHT_CLICK_AIR) {
			if(e.getMaterial() == Material.MONSTER_EGG) {
				try {
					if(e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "TNTCanon")) {
						e.setCancelled(true);
						
						if(inTNTCanon.contains(p)) {
							p.sendMessage("�cDu kannst nur �e1 �6TNTKanone �cplatzieren!");
							return;
						}
						
						
						//Item im inv entfernen
						if(p.getItemInHand().getAmount() < 2) {
							for(ItemStack current : p.getInventory().getContents()) {
								try {
									if(current.getType() != null) {
										if(current.getType() == Material.MONSTER_EGG) {
											if(current.getItemMeta().getDisplayName().equalsIgnoreCase((ChatColor.GOLD + "TNTCanon"))) {
												if(current.getAmount() < 2) {
													p.getInventory().removeItem(current);
													p.updateInventory();
													break;
												}
											}
										}
									}
								} catch(NullPointerException ex) {}
							}
						} else {
							p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
						}
						
						if(HimmelsRichtung.getDirection(p).equalsIgnoreCase("N")) {
							Location loc = e.getClickedBlock().getLocation();
							
							
							loc.setY(loc.getY() + 1);
							Block b = loc.getBlock();
							b.setType(Material.SPRUCE_FENCE);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.DISPENSER);
							b.setData((byte) 2);

							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.IRON_PLATE);
							
							loc.setY(loc.getY() -1);
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.WALL_SIGN);
							b.setData((byte) 4);
							
							loc.setX(loc.getX() + 2);
							b = loc.getBlock();
							b.setType(Material.WALL_SIGN);
							b.setData((byte) 5);
							
							loc.setX(loc.getX() -1);
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.WALL_SIGN);
							b.setData((byte) 3);
							
							

							
							Sign sign1 = (Sign) loc.getBlock().getState();
							
							loc.setZ(loc.getZ() -1);
							loc.setX(loc.getX() + 1);
							Sign sign2 = (Sign) loc.getBlock().getState();
							
							loc.setX(loc.getX() -2);
							Sign sign3 = (Sign) loc.getBlock().getState();
							
							inTNTCanon.add(p);
							
							
							SchedTNTCanonNorden = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
								
								
								
								
								int counter;
								int counter1;

								@Override
								public void run() {
									
									
									if(counter1 > 9*4) {
										Bukkit.getScheduler().cancelTask(SchedTNTCanonNorden);
										inTNTCanon.remove(p);
										//Sign1
										sign1.setLine(0, "");
										sign1.setLine(1, "");
										sign1.setLine(2, "");
										sign1.setLine(3, "");
										sign1.update();
										
										//Sign2
										sign2.setLine(0, "");
										sign2.setLine(1, "");
										sign2.setLine(2, "");
										sign2.setLine(3, "");
										sign2.update();
										
										//Sign3
										sign3.setLine(0, "");
										sign3.setLine(1, "");
										sign3.setLine(2, "");
										sign3.setLine(3, "");
										sign3.update();

										//sign1.getLocation().getBlock().setType(Material.AIR);
										//sign2.getLocation().getBlock().setType(Material.AIR);
										//sign3.getLocation().getBlock().setType(Material.AIR);
										
										counter1 = 0;
										
										p.sendMessage("�dDeine �6TNT-Kanone �dist �ckaputt �dgeganen!");
										return;
									}
									
									if(counter == 3) {
										//Sign1
										sign1.setLine(0, "");
										sign1.setLine(2, "");
										sign1.setLine(3, "");
										sign1.setLine(1, "�c3");
										sign1.update();
										
										//Sign2
										sign2.setLine(0, "");
										sign2.setLine(2, "");
										sign2.setLine(3, "");
										sign2.setLine(1, "�c3");
										sign2.update();
										
										//Sign3
										sign3.setLine(0, "");
										sign3.setLine(2, "");
										sign3.setLine(3, "");
										sign3.setLine(1, "�c3");
										sign3.update();
									} else if(counter == 2) {
										//Sign1
										sign1.setLine(0, "");
										sign1.setLine(2, "");
										sign1.setLine(3, "");
										sign1.setLine(1, "�e2");
										sign1.update();
										
										//Sign2
										sign2.setLine(0, "");
										sign2.setLine(2, "");
										sign2.setLine(3, "");
										sign2.setLine(1, "�e2");
										sign2.update();
										
										//Sign3
										sign3.setLine(0, "");
										sign3.setLine(2, "");
										sign3.setLine(3, "");
										sign3.setLine(1, "�e2");
										sign3.update();
									} else if(counter == 1) {
										//Sign1
										sign1.setLine(0, "");
										sign1.setLine(2, "");
										sign1.setLine(3, "");
										sign1.setLine(1, "�a1");
										sign1.update();
										
										//Sign2
										sign2.setLine(0, "");
										sign2.setLine(2, "");
										sign2.setLine(3, "");
										sign2.setLine(1, "�a1");
										sign2.update();
										
										//Sign3
										sign3.setLine(0, "");
										sign3.setLine(2, "");
										sign3.setLine(3, "");
										sign3.setLine(1, "�a1");
										sign3.update();
									} else {
										this.counter = 4;
										//Explosion
										sign1.getWorld().playEffect(sign1.getLocation(), Effect.EXPLOSION_HUGE, 1);
										sign1.getWorld().playSound(sign1.getLocation(), Sound.BLAZE_BREATH, 1, 10);
										
										Location loctnt = new Location(loc.getWorld(), 
												loc.getX() + 1.5,
												loc.getY(),
												loc.getZ());
										
										Entity TNT = sign1.getWorld().spawnEntity(loctnt, EntityType.PRIMED_TNT);
										Vector v = new Vector(0, 0.1D, -10D);
										TNT.setVelocity(v);
										
										
										//Signs
										//Sign1
										sign1.setLine(0, "�6GO!");
										sign1.setLine(1, "�6GO!");
										sign1.setLine(2, "�6GO!");
										sign1.setLine(3, "�6GO!");
										sign1.update();
										
										//Sign2
										sign2.setLine(0, "�6GO!");
										sign2.setLine(1, "�6GO!");
										sign2.setLine(2, "�6GO!");
										sign2.setLine(3, "�6GO!");
										sign2.update();
										
										//Sign3
										sign3.setLine(0, "�6GO!");
										sign3.setLine(1, "�6GO!");
										sign3.setLine(2, "�6GO!");
										sign3.setLine(3, "�6GO!");
										sign3.update();
									}

									counter--;
									counter1++;
									
								}
								
							}, 0, 20);
								
							
						}
						
						if(HimmelsRichtung.getDirection(p).equalsIgnoreCase("O")) {
							p.sendMessage(ChatColor.RED + "Osten");
						}
						
						if(HimmelsRichtung.getDirection(p).equalsIgnoreCase("S")) {
							p.sendMessage(ChatColor.RED + "S�den");
						}
						
						if(HimmelsRichtung.getDirection(p).equalsIgnoreCase("W") || HimmelsRichtung.getDirection(p).equalsIgnoreCase("NW")) {
							p.sendMessage(ChatColor.RED + "Westen");
						}
						
					}
				} catch(Exception ex) {}
			}
		}
	}
	
	
}
