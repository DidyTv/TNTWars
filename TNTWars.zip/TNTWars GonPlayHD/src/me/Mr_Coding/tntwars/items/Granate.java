package me.Mr_Coding.tntwars.items;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import me.Mr_Coding.tntwars.start.start;
import net.md_5.bungee.api.ChatColor;

public class Granate implements Listener {

	private Plugin plugin;
	public Granate(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}
	
	public static void Granade(Player p, int slot, int size) {
		ItemStack Granate = new ItemStack(Material.FIREWORK_CHARGE);
		Granate.setAmount(size);
		ItemMeta GranateMeta = Granate.getItemMeta();
		
		Granate.setDurability((short) 0);
		
		GranateMeta.setDisplayName(ChatColor.GOLD + "Granate");
		
		ArrayList<String> Granatelore = new ArrayList<>();
		Granatelore.add(ChatColor.LIGHT_PURPLE + "Throw it in your eyes direction!");
		
		GranateMeta.setLore(Granatelore);
		Granate.setItemMeta(GranateMeta);
		
		p.getInventory().setItem(slot, Granate);
		return;
	}
	
	public static void Granade(Player p, int size) {
		ItemStack Granate = new ItemStack(Material.FIREWORK_CHARGE);
		Granate.setAmount(size);
		ItemMeta GranateMeta = Granate.getItemMeta();
		
		Granate.setDurability((short) 0);
		
		GranateMeta.setDisplayName(ChatColor.GOLD + "Granate");
		
		ArrayList<String> Granatelore = new ArrayList<>();
		Granatelore.add(ChatColor.LIGHT_PURPLE + "Throw it in your eyes direction!");
		
		GranateMeta.setLore(Granatelore);
		Granate.setItemMeta(GranateMeta);
		
		p.getInventory().addItem(Granate);
		return;
	}
	
	@EventHandler
	public void onPlayerInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		if(e.getAction() == Action.RIGHT_CLICK_BLOCK || e.getAction() == Action.RIGHT_CLICK_AIR) {
			if(e.getMaterial() == Material.FIREWORK_CHARGE) {
				if(e.getItem().getItemMeta().getDisplayName() != null) {
					if(e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "Granate")) {
						
						Item FireCharge = p.getWorld().dropItem(p.getEyeLocation(), new ItemStack(Material.FIREWORK_CHARGE));
						
						//Item im inv entfernen
						if(p.getItemInHand().getAmount() < 2) {
							for(ItemStack current : p.getInventory().getContents()) {
								try {
									if(current.getType() != null) {
										if(current.getType() == Material.FIREWORK_CHARGE) {
											if(current.getItemMeta().getDisplayName().equalsIgnoreCase((ChatColor.GOLD + "Granate"))) {
												if(current.getAmount() < 2) {
													p.getInventory().removeItem(current);
													p.updateInventory();
													break;
												}
											}
										}
									}
								} catch(NullPointerException ex) {}
							}
						} else {
							p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
						}
						
						FireCharge.setVelocity(p.getLocation().getDirection().multiply(2));
						FireCharge.setPickupDelay(90000);
						
						
						//Sounds
						//1
						FireCharge.getWorld().playSound(FireCharge.getLocation(), Sound.BURP, 1, (float) 10);	
						
						//2
						Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

							@Override
							public void run() {
								FireCharge.getWorld().playSound(FireCharge.getLocation(), Sound.BURP, 1, (float) 10);
							}
						}, 20*1);	
						
						//3
						Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

							@Override
							public void run() {
								FireCharge.getWorld().playSound(FireCharge.getLocation(), Sound.BURP, 1, (float) 10);
							}
						}, 20*2);	
						
						//4
						Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

							@Override
							public void run() {
								FireCharge.getWorld().playSound(FireCharge.getLocation(), Sound.BURP, 1, (float) 10);
							}
						}, 20*3);	
						
						//Explode
						Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

							@Override
							public void run() {
								FireCharge.getWorld().createExplosion(FireCharge.getLocation(), 3, false);
								FireCharge.remove();
							}
						}, 20*4);	
						
					}
				}
			}
		}
	}
	
}
