package me.Mr_Coding.tntwars.items;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import me.Mr_Coding.tntwars.start.HimmelsRichtung;
import me.Mr_Coding.tntwars.start.start;
import net.md_5.bungee.api.ChatColor;

public class TNTMissle implements Listener {

	
	private Plugin plugin;
	public TNTMissle(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}
	
	public static void Cruiser(Player p, int slot, int size) {
		ItemStack TNTMissle = new ItemStack(Material.MONSTER_EGG);
		TNTMissle.setAmount(size);
		TNTMissle.setDurability((short) 93);
		ItemMeta TNTMissleMeta = TNTMissle.getItemMeta();
		
		
		TNTMissleMeta.setDisplayName(ChatColor.GOLD + "TNTMissle");
		
		ArrayList<String> Granadelore = new ArrayList<>();
		Granadelore.add(ChatColor.LIGHT_PURPLE + "Place it in your eyes direction!");
		
		TNTMissleMeta.setLore(Granadelore);
		TNTMissle.setItemMeta(TNTMissleMeta);
		TNTMissle.setDurability((short) 93);
		
		p.getInventory().setItem(slot, TNTMissle);
		return;
	}
	
	public static void Cruiser(Player p, int size) {
		ItemStack TNTMissle = new ItemStack(Material.MONSTER_EGG);
		TNTMissle.setAmount(size);
		TNTMissle.setDurability((short) 93);
		ItemMeta TNTMissleMeta = TNTMissle.getItemMeta();
		
		
		TNTMissleMeta.setDisplayName(ChatColor.GOLD + "TNTMissle");
		
		ArrayList<String> Granadelore = new ArrayList<>();
		Granadelore.add(ChatColor.LIGHT_PURPLE + "Place it in your eyes direction!");
		
		TNTMissleMeta.setLore(Granadelore);
		TNTMissle.setItemMeta(TNTMissleMeta);
		TNTMissle.setDurability((short) 93);
		
		p.getInventory().addItem(TNTMissle);
		return;
	}
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onPlayerInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		if(e.getAction() == Action.RIGHT_CLICK_BLOCK || e.getAction() == Action.RIGHT_CLICK_AIR) {
			try {
				Sign sign = (Sign) e.getClickedBlock().getState();
				
				if(sign.getLine(0).equalsIgnoreCase("�6TNTWars")) {
					if(sign.getLine(1).equalsIgnoreCase("TNTMissle Cruiser")) {
						if(sign.getLine(2).equalsIgnoreCase("�a�nBreak me!")) {
							if(sign.getLine(3).equalsIgnoreCase("1")) {
								Block b = sign.getBlock();
								b.setType(Material.AIR);
								Location loc = b.getLocation();
								
								loc.setZ(loc.getZ() + 1);
								loc.setX(loc.getX() -1);
								b = loc.getBlock();
								b.setType(Material.AIR);
								
								e.setCancelled(true);
								return;
							}
							
							if(sign.getLine(3).equalsIgnoreCase("2")) {
								Block b = sign.getBlock();
								b.setType(Material.AIR);
								Location loc = b.getLocation();
								
								loc.setZ(loc.getZ() -1);
								loc.setX(loc.getX() + 1);
								b = loc.getBlock();
								b.setType(Material.AIR);
								
								e.setCancelled(true);
								return;
							}
							
							if(sign.getLine(3).equalsIgnoreCase("3")) {
								
								Block b = sign.getBlock();
								b.setType(Material.AIR);
								Location loc = b.getLocation();
								
								loc.setX(loc.getX() + 1);
								loc.setZ(loc.getZ() + 1);
								b = loc.getBlock();
								b.setType(Material.AIR);
								
								e.setCancelled(true);
								return;
							}
							
							if(sign.getLine(3).equalsIgnoreCase("4")) {
								
								Block b = sign.getBlock();
								b.setType(Material.AIR);
								Location loc = b.getLocation();

								loc.setX(loc.getX() -1);
								loc.setZ(loc.getZ() -1);
								b = loc.getBlock();
								b.setType(Material.AIR);
								
								e.setCancelled(true);
								return;
							}
							
							if(sign.getLine(3).equalsIgnoreCase("5")) {
								Block b = sign.getBlock();
								b.setType(Material.AIR);
								Location loc = b.getLocation();
								
								loc.setX(loc.getX() -1);
								loc.setZ(loc.getZ() -1);
								b = loc.getBlock();
								b.setType(Material.AIR);
								
								e.setCancelled(true);
								return;
							}
							
							if(sign.getLine(3).equalsIgnoreCase("6")) {
								Block b = sign.getBlock();
								b.setType(Material.AIR);
								Location loc = b.getLocation();
								
								loc.setX(loc.getX() + 1);
								loc.setZ(loc.getZ() + 1);
								b = loc.getBlock();
								b.setType(Material.AIR);
								
								e.setCancelled(true);
								return;
							}
							
							if(sign.getLine(3).equalsIgnoreCase("7")) {
								Block b = sign.getBlock();
								b.setType(Material.AIR);
								Location loc = b.getLocation();
								
								loc.setX(loc.getX() + 1);
								loc.setZ(loc.getZ() -1);
								b = loc.getBlock();
								b.setType(Material.AIR);
								
								e.setCancelled(true);
								return;
							}
							
							if(sign.getLine(3).equalsIgnoreCase("8")) {
								Block b = sign.getBlock();
								b.setType(Material.AIR);
								Location loc = b.getLocation();
								
								loc.setX(loc.getX() -1);
								loc.setZ(loc.getZ() + 1);
								b = loc.getBlock();
								b.setType(Material.AIR);
								
								e.setCancelled(true);
								return;
							}
							
						}	
					}
				}
			} catch(Exception ex) {}
			
			if(e.getMaterial() == Material.MONSTER_EGG) {
				try {
					if(e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "TNTMissle")) {
						e.setCancelled(true);
						
						
						//Norden
						if(HimmelsRichtung.getDirection(p).equalsIgnoreCase("N")) {
							Location loc = e.getClickedBlock().getLocation();
							
							loc.setZ(loc.getZ() -2);
							loc.setY(loc.getY() + 2);
							
							
							Block b1 = loc.getBlock();
							b1.setType(Material.PISTON_BASE);
							b1.setData((byte) 2);
							
							loc.setY(loc.getY() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.PISTON_BASE);
							b1.setData((byte) 3);
							
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.REDSTONE_BLOCK);
							
							loc.setY(loc.getY() -1);
							b1 = loc.getBlock();
							b1.setType(Material.SLIME_BLOCK);
							
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.FURNACE);
							
							loc.setY(loc.getY() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.STAINED_GLASS);
							
							loc.setZ(loc.getZ() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.SLIME_BLOCK);
							
							loc.setX(loc.getX() -1);
							b1 = loc.getBlock();
							b1.setType(Material.PISTON_STICKY_BASE);
							b1.setData((byte) 3);
							
							loc.setY(loc.getY() -1);
							b1 = loc.getBlock();
							b1.setType(Material.PISTON_BASE);
							b1.setData((byte) 2);
							
							loc.setZ(loc.getZ() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.SLIME_BLOCK);
							
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.SLIME_BLOCK);
							
							loc.setZ(loc.getZ() -3);
							b1 = loc.getBlock();
							b1.setType(Material.REDSTONE_BLOCK);
							
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.STAINED_GLASS);
							
							
							loc.setZ(loc.getZ() + 1);
							loc.setY(loc.getY() -1);
							b1 = loc.getBlock();
							b1.setType(Material.SLIME_BLOCK);

							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);

							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.PISTON_BASE);
							b1.setData((byte) 2);
							
							loc.setX(loc.getX() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.REDSTONE_BLOCK);
							
							loc.setZ(loc.getZ() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.STAINED_GLASS);
							
							loc.setZ(loc.getZ() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.STAINED_GLASS);
							
							loc.setY(loc.getY() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -2);
							b1 = loc.getBlock();
							b1.setType(Material.STAINED_GLASS);
							
							loc.setX(loc.getX() -1);
							b1 = loc.getBlock();
							b1.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() + 1);
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setX(loc.getX() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setY(loc.getY() -1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -4);
							b1 = loc.getBlock();
							b1.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b1 = loc.getBlock();
							b1.setType(Material.SLIME_BLOCK);
							
							
							
							Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

								@Override
								public void run() {


									loc.setY(loc.getY() -1);
									loc.setZ(loc.getZ() + 12);
									loc.setX(loc.getX() + 1);
									

									Block b1 = loc.getBlock();
									b1.setType(Material.WALL_SIGN);
									b1.setData((byte) 5);
									
									try {

										Sign sign = (Sign) b1.getLocation().getBlock().getState();

										sign.setLine(0, "�6TNTWars");
										sign.setLine(1, "TNTMissle Cruiser");
										sign.setLine(2, "�a�nBreak me!");
										sign.setLine(3, "1");
										sign.update();
										
									} catch(Exception ex) {}
									
									loc.setZ(loc.getZ() + 1);
									loc.setX(loc.getX() -1);
									b1 = loc.getBlock();
									b1.setType(Material.WALL_SIGN);
									b1.setData((byte) 3);
									
									try {

										Sign sign = (Sign) b1.getLocation().getBlock().getState();
										
										sign.setLine(0, "�6TNTWars");
										sign.setLine(1, "TNTMissle Cruiser");
										sign.setLine(2, "�a�nBreak me!");
										sign.setLine(3, "2");
										sign.update();
										
									} catch(Exception ex) {}
									
									loc.setZ(loc.getZ() -1);
									loc.setX(loc.getX() + 1);
									
									
									loc.setZ(loc.getZ() -3);
									loc.setX(loc.getX() -1);
									b1 = loc.getBlock();
									b1.setType(Material.AIR);
									
									
									

									//Item im inv entfernen
									if(p.getItemInHand().getAmount() < 2) {
										if(e.getItem().getDurability() == 93) {
											for(ItemStack current : p.getInventory().getContents()) {
												try {
													if(current.getType() != null) {
														if(current.getType() == Material.MONSTER_EGG) {
															if(current.getItemMeta().getDisplayName().equalsIgnoreCase((ChatColor.GOLD + "TNTMissle"))) {
																if(current.getDurability() == 93) {
																	if(current.getAmount() < 2) {
																		p.getInventory().removeItem(current);
																		break;
																	}
																}
															}
														}
													}
												} catch(NullPointerException ex) {}
											}
										}
									} else {
										p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
									}

								}
								
							}, 2);
							
							
							p.sendMessage("�6Missle made by �aCubehamster �6on �cYouTube!");
							
						}
						
						//Osten
						if(HimmelsRichtung.getDirection(p).equalsIgnoreCase("O")) {
							Location loc = e.getClickedBlock().getLocation();
							
							loc.setX(loc.getX() + 2);
							loc.setY(loc.getY() + 3);
							
							Block b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 4);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 5);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.REDSTONE_BLOCK);
							
							loc.setX(loc.getX() -1);
							//loc.setY(loc.getY() -1);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.PISTON_STICKY_BASE);
							b.setData((byte) 4);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 5);
							
							loc.setZ(loc.getZ() + 1);
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.FURNACE);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.REDSTONE_BLOCK);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.REDSTONE_BLOCK);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 5);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() - 1);
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() - 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() - 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

								@Override
								public void run() {
									
									loc.setX(loc.getX() -9);
									loc.setZ(loc.getZ() + 1);
									Block b = loc.getBlock();
									b.setType(Material.WALL_SIGN);
									b.setData((byte) 3);
									
									try {

										Sign sign = (Sign) b.getLocation().getBlock().getState();

										sign.setLine(0, "�6TNTWars");
										sign.setLine(1, "TNTMissle Cruiser");
										sign.setLine(2, "�a�nBreak me!");
										sign.setLine(3, "5");
										sign.update();
										
									} catch(Exception ex) {}
									
									loc.setX(loc.getX() -1);
									loc.setZ(loc.getZ() -1);
									b = loc.getBlock();
									b.setType(Material.WALL_SIGN);
									b.setData((byte) 4);
									
									try {

										Sign sign = (Sign) b.getLocation().getBlock().getState();

										sign.setLine(0, "�6TNTWars");
										sign.setLine(1, "TNTMissle Cruiser");
										sign.setLine(2, "�a�nBreak me!");
										sign.setLine(3, "6");
										sign.update();
										
									} catch(Exception ex) {}
									

									loc.setX(loc.getX() + 1);
									loc.setX(loc.getX() + 3);
									b = loc.getBlock();
									b.setType(Material.AIR);
									
									
									//Item im inv entfernen
									if(p.getItemInHand().getAmount() < 2) {
										if(e.getItem().getDurability() == 93) {
											for(ItemStack current : p.getInventory().getContents()) {
												try {
													if(current.getType() != null) {
														if(current.getType() == Material.MONSTER_EGG) {
															if(current.getItemMeta().getDisplayName().equalsIgnoreCase((ChatColor.GOLD + "TNTMissle"))) {
																if(current.getDurability() == 93) {
																	if(current.getAmount() < 2) {
																		p.getInventory().removeItem(current);
																		break;
																	}
																}
															}
														}
													}
												} catch(NullPointerException ex) {}
											}
										}
									} else {
										p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
									}
									
								}
								
							}, 2);

							p.sendMessage("�6Missle made by �aCubehamster �6on �cYouTube!");
							
							
						}
						
						//S�den
						if(HimmelsRichtung.getDirection(p).equalsIgnoreCase("S")) {
							
							Location loc = e.getClickedBlock().getLocation();
							
							loc.setY(loc.getY() + 3);
							loc.setZ(loc.getZ() + 2);
							
							Block b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 2);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 3);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.REDSTONE_BLOCK);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.FURNACE);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setY(loc.getY() - 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.REDSTONE_BLOCK);
							
							loc.setZ(loc.getZ() -2);
							b = loc.getBlock();
							b.setType(Material.PISTON_STICKY_BASE);
							b.setData((byte) 2);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 3);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setZ(loc.getZ() + 6);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 3);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.REDSTONE_BLOCK);
							
							loc.setZ(loc.getZ() + 1);
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);

							loc.setZ(loc.getZ() -1);
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							
							Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

								@Override
								public void run() {

									loc.setX(loc.getX() -2);
									loc.setZ(loc.getZ() -7);
									Block b = loc.getBlock();
									b.setType(Material.WALL_SIGN);
									b.setData((byte) 4);
									
									
									try {

										Sign sign = (Sign) b.getLocation().getBlock().getState();

										sign.setLine(0, "�6TNTWars");
										sign.setLine(1, "TNTMissle Cruiser");
										sign.setLine(2, "�a�nBreak me!");
										sign.setLine(3, "7");
										sign.update();
										
									} catch(Exception ex) {}
									
									loc.setX(loc.getX() + 1);
									loc.setZ(loc.getZ() -1);
									b = loc.getBlock();
									b.setType(Material.WALL_SIGN);
									b.setData((byte) 1);
									
									try {

										Sign sign = (Sign) b.getLocation().getBlock().getState();

										sign.setLine(0, "�6TNTWars");
										sign.setLine(1, "TNTMissle Cruiser");
										sign.setLine(2, "�a�nBreak me!");
										sign.setLine(3, "8");
										sign.update();
										
									} catch(Exception ex) {}
									
									loc.setZ(loc.getZ() + 4);
									b = loc.getBlock();
									b.setType(Material.AIR);
									
									
									//Item im inv entfernen
									if(p.getItemInHand().getAmount() < 2) {
										if(e.getItem().getDurability() == 93) {
											for(ItemStack current : p.getInventory().getContents()) {
												try {
													if(current.getType() != null) {
														if(current.getType() == Material.MONSTER_EGG) {
															if(current.getItemMeta().getDisplayName().equalsIgnoreCase((ChatColor.GOLD + "TNTMissle"))) {
																if(current.getDurability() == 93) {
																	if(current.getAmount() < 2) {
																		p.getInventory().removeItem(current);
																		break;
																	}
																}
															}
														}
													}
												} catch(NullPointerException ex) {}
											}
										}
									} else {
										p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
									}
									
								}
								
							}, 2);
							

							p.sendMessage("�6Missle made by �aCubehamster �6on �cYouTube!");
							
							
						}
						
						//Westen
						if(HimmelsRichtung.getDirection(p).equalsIgnoreCase("W") || HimmelsRichtung.getDirection(p).equalsIgnoreCase("NW")) {
							
							Location loc = e.getClickedBlock().getLocation();
							
							loc.setX(loc.getX() -2);
							loc.setY(loc.getY() + 3);
							
							Block b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 5);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 4);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.FURNACE);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.REDSTONE_BLOCK);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 4);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.PISTON_STICKY_BASE);
							b.setData((byte) 5);
							
							loc.setY(loc.getY() -1);
							loc.setX(loc.getX() -2);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.REDSTONE_BLOCK);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.PISTON_BASE);
							b.setData((byte) 4);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.REDSTONE_BLOCK);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -2);
							b = loc.getBlock();
							b.setType(Material.STAINED_GLASS);
							
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setX(loc.getX() -1);
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.SLIME_BLOCK);
							
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() + 2);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setY(loc.getY() + 1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							loc.setX(loc.getX() + 1);
							loc.setY(loc.getY() -1);
							b = loc.getBlock();
							b.setType(Material.TNT);
							
							Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {

								@Override
								public void run() {
									
									loc.setX(loc.getX() + 8);
									loc.setZ(loc.getZ() -1);
									Block b = loc.getBlock();
									b.setType(Material.WALL_SIGN);
									b.setData((byte) 2);
									
									try {

										Sign sign = (Sign) b.getLocation().getBlock().getState();

										sign.setLine(0, "�6TNTWars");
										sign.setLine(1, "TNTMissle Cruiser");
										sign.setLine(2, "�a�nBreak me!");
										sign.setLine(3, "3");
										sign.update();
										
									} catch(Exception ex) {}
									
									loc.setX(loc.getX() + 1);
									loc.setZ(loc.getZ() + 1);
									b = loc.getBlock();
									b.setType(Material.WALL_SIGN);
									b.setData((byte) 5);
									
									try {

										Sign sign = (Sign) b.getLocation().getBlock().getState();

										sign.setLine(0, "�6TNTWars");
										sign.setLine(1, "TNTMissle Cruiser");
										sign.setLine(2, "�a�nBreak me!");
										sign.setLine(3, "4");
										sign.update();
										
									} catch(Exception ex) {}
									
									
									loc.setX(loc.getX() -1);
									loc.setX(loc.getX() -3);
									b = loc.getBlock();
									b.setType(Material.AIR);
									
									
									//Item im inv entfernen
									if(p.getItemInHand().getAmount() < 2) {
										if(e.getItem().getDurability() == 93) {
											for(ItemStack current : p.getInventory().getContents()) {
												try {
													if(current.getType() != null) {
														if(current.getType() == Material.MONSTER_EGG) {
															if(current.getItemMeta().getDisplayName().equalsIgnoreCase((ChatColor.GOLD + "TNTMissle"))) {
																if(current.getDurability() == 93) {
																	if(current.getAmount() < 2) {
																		p.getInventory().removeItem(current);
																		break;
																	}
																}
															}
														}
													}
												} catch(NullPointerException ex) {}
											}
										}
									} else {
										p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
									}
									
								}
								
							}, 2);
							
							
							p.sendMessage("�6Missle made by �aCubehamster �6on �cYouTube!");
							
						}
						
					}
				} catch(Exception ex) {}
			}
		}
	}
	
	//Events
	@EventHandler
	public void onBlockPhysics(BlockPhysicsEvent e) {
		final Block b = e.getBlock();
		Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable() {
		   public void run() {
		    	if(b.getType() == Material.WALL_SIGN){
		    		
					try {
						Sign s = (Sign) e.getBlock().getState();
						if(s.getLine(0).equalsIgnoreCase("�6TNTWars")) {
							if(s.getLine(1).equalsIgnoreCase("TNTMissle Cruiser")) {
								if(s.getLine(2).equalsIgnoreCase("�a�nBreak me!")) {
									for(Entity ent : s.getWorld().getEntities()) {
										if(ent instanceof Item) {
											Item item = (Item) ent;
											if(item.getType().equals(Material.SIGN)) {
												if(ent.getLocation().equals(s.getLocation())) {
													ent.remove();
												}
											}
										}
									}
								}
							}
						}
					} catch(Exception ex) {}
		    	}
		   }
		}, 1);
	}
	
	@EventHandler
	public void onBlockBreak(BlockBreakEvent e) {
		if(e.getBlock().getType() == Material.WALL_SIGN) {
			Sign sign = (Sign) e.getBlock().getState();
			if(sign.getLine(0).equalsIgnoreCase("�6TNTWars")) {
				if(sign.getLine(1).equalsIgnoreCase("TNTMissle Cruiser")) {
					if(sign.getLine(2).equalsIgnoreCase("�a�nBreak me!")) {
						if(sign.getLine(3).equalsIgnoreCase("1")) {
							Block b = sign.getBlock();
							b.setType(Material.AIR);
							Location loc = b.getLocation();
							
							loc.setZ(loc.getZ() + 1);
							loc.setX(loc.getX() -1);
							b = loc.getBlock();
							b.setType(Material.AIR);
							
							
						}
						
						if(sign.getLine(3).equalsIgnoreCase("2")) {
							Block b = sign.getBlock();
							b.setType(Material.AIR);
							Location loc = b.getLocation();
							
							loc.setZ(loc.getZ() -1);
							loc.setX(loc.getX() + 1);
							b = loc.getBlock();
							b.setType(Material.AIR);
							
						}
						
						if(sign.getLine(3).equalsIgnoreCase("3")) {
							Block b = sign.getBlock();
							b.setType(Material.AIR);
							Location loc = b.getLocation();

							loc.setX(loc.getX() + 1);
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.AIR);
							
							e.setCancelled(true);
							return;
						}
						
						if(sign.getLine(3).equalsIgnoreCase("4")) {
							Block b = sign.getBlock();
							b.setType(Material.AIR);
							Location loc = b.getLocation();

							loc.setX(loc.getX() -1);
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.AIR);
							
							e.setCancelled(true);
							return;
						}
						
						if(sign.getLine(3).equalsIgnoreCase("5")) {
							Block b = sign.getBlock();
							b.setType(Material.AIR);
							Location loc = b.getLocation();
							
							loc.setX(loc.getX() -1);
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.AIR);
							
							e.setCancelled(true);
							return;
						}
						
						if(sign.getLine(3).equalsIgnoreCase("6")) {
							Block b = sign.getBlock();
							b.setType(Material.AIR);
							Location loc = b.getLocation();
							
							loc.setX(loc.getX() + 1);
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.AIR);
							
							e.setCancelled(true);
							return;
						}
						
						if(sign.getLine(3).equalsIgnoreCase("7")) {
							Block b = sign.getBlock();
							b.setType(Material.AIR);
							Location loc = b.getLocation();
							
							loc.setX(loc.getX() + 1);
							loc.setZ(loc.getZ() -1);
							b = loc.getBlock();
							b.setType(Material.AIR);
							
							e.setCancelled(true);
							return;
						}
						
						if(sign.getLine(3).equalsIgnoreCase("8")) {
							Block b = sign.getBlock();
							b.setType(Material.AIR);
							Location loc = b.getLocation();
							
							loc.setX(loc.getX() -1);
							loc.setZ(loc.getZ() + 1);
							b = loc.getBlock();
							b.setType(Material.AIR);
							
							e.setCancelled(true);
							return;
						}
						
					}	
				}
			}
		}
	}
	
}
