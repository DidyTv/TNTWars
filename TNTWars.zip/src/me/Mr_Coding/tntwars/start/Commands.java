package me.Mr_Coding.tntwars.start;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import me.Mr_Coding.tntwars.items.Granate;
import me.Mr_Coding.tntwars.items.TNTCanon;
import me.Mr_Coding.tntwars.items.TNTMissle;
import me.Mr_Coding.tntwars.items.GranadeThrower;

public class Commands implements CommandExecutor {
	private start plugin;
	public Commands(start main) {
		this.plugin = main;
	}
	
	
	int gameanzahl;
	int lobbytime = 31;
	int lobbyscheduler;
	
	int Schedjoin;
	int SchedReset;
	
	public static HashMap<Player, Location> Location = new HashMap<>();
	
	
	
	
	
	
	//erstellt boolean um aus for zu breaken
	boolean joinforbreak = false;
	
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		
		if(args.length > 0) {
			//Plugin infos
			if(args[0].equalsIgnoreCase("Version")) {
				if(sender.hasPermission("TNTWars.Version")) {
					sender.sendMessage(start.prefix + "Aktuelle Version: �a" + plugin.getDescription().getVersion());
					return true;
				} else {
					noPermission(sender);
					return true;
				}
			}
			
			if(args[0].equalsIgnoreCase("Bugs")) {
				if(sender.hasPermission("TNTWars.Bugs")) {
					currentBugs(sender);
					return true;
				} else {
					noPermission(sender);
					return true;
				}
			}
			
			if(args[0].equalsIgnoreCase("Reload")) {
				if(sender.hasPermission("TNTWars.Reload")) {
					try {
						sender.sendMessage(start.prefix + "�2Starting Reload...");
						plugin.saveConfig();
						plugin.reloadConfig();
						sender.sendMessage(start.prefix + "Reload �acomplete!");
					} catch (Exception e) { sender.sendMessage(start.prefix + "Reload �aFAILED!"); }
					
					return true;
				} else {
					noPermission(sender);
					return true;
				}
			}
			
		}
		
		
		
		if(sender instanceof Player) {
			Player p = (Player) sender;
			
			if(args.length > 0) {
		
		
		
		//Commands
			if(args[0].equalsIgnoreCase("Spawner")) {
				if(p.hasPermission("TNTWars.Spawner")) {
					if(args.length > 1) {
						if(!(sender instanceof Player)) {
							if(args.length > 5) {
								for(World worlds : Bukkit.getWorlds()) {
									if(worlds.getName().equalsIgnoreCase(args[5])) {
										try {
											int Count = 0;
											
											double X = Double.parseDouble(args[2]);
											double Y = Double.parseDouble(args[3]);
											double Z = Double.parseDouble(args[4]);
											
											Count = plugin.getConfig().getInt("GameWorld." + worlds.getName() + ".Spawners.Count") + 1;
											plugin.getConfig().set("GameWorld.name" + worlds.getName(), worlds.getName());
											
											if(plugin.getConfig().getString("GameWorld.name" + worlds.getName()).equalsIgnoreCase(worlds.getName())) {
												plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners.Count", Count);
												plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".World", p.getLocation().getWorld().getName());
												plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Name", args[1]);
												plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".X", X);
												plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Y", Y);
												plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Z", Z);

												sender.sendMessage(start.prefix + "Added Spawner �6number �3" + Count + "�d, �6Name �a" + args[1] + "�d with Location:");
												sender.sendMessage("�eX: �d" + X);
												sender.sendMessage("�eY: �d" + Y);
												sender.sendMessage("�eZ: �d" + Z);
												
												plugin.saveConfig();
												return true;
											}
										} catch (Exception e) {  }
										p.sendMessage(start.prefix + "�cERROR! Please Report this Error to �aMr_Coding! �3ERROR CODE: �eTNTWarsSpawnerGWgetSGW.nameworlds.getName");
										return true;
									}
								}
								sender.sendMessage("�cEin Fataler Fehler ist aufgetreten! Bitte berichte dies dem");
								sender.sendMessage("�aDEVELOPER �cnamens �6Mr_Coding");
								sender.sendMessage("�cBitte �berpr�fe die Config.yml in des Plugins �a\"TNTWars\"!");
								return true;
							} else {
								sender.sendMessage(start.prefix + "Es fehlen �6Argumente!");
								sender.sendMessage("�62. �dName");
								sender.sendMessage("�63. �dX");
								sender.sendMessage("�64. �dY");
								sender.sendMessage("�65. �dZ");
								sender.sendMessage("�66. �dWorldname");
								return true;
							}
						}
						
						
						for(World worlds : Bukkit.getWorlds()) {
							if(worlds.getName().equalsIgnoreCase(p.getWorld().getName())) {
								try {
									int Count = 0;
									Count = plugin.getConfig().getInt("GameWorld." + worlds.getName() + ".Spawners.Count") + 1;
									plugin.getConfig().set("GameWorld.name" + worlds.getName(), worlds.getName());
									
									if(plugin.getConfig().getString("GameWorld.name" + worlds.getName()).equalsIgnoreCase(worlds.getName())) {
										plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners.Count", plugin.getConfig().getInt("GameWorld." + worlds.getName() + ".Spawners.Count") + 1);
										plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".World", p.getLocation().getWorld().getName());
										plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Name", args[1]);
										plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".X", p.getLocation().getX());
										plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Y", p.getLocation().getY());
										plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Z", p.getLocation().getZ());

										p.sendMessage(start.prefix + "Added Spawner �6number �3" + Count + "�d, �6Name �a" + args[1] + "�d with Location:");
										p.sendMessage("�eX: �d" + p.getLocation().getX());
										p.sendMessage("�eY: �d" + p.getLocation().getY());
										p.sendMessage("�eZ: �d" + p.getLocation().getZ());
										
										plugin.saveConfig();
										return true;
									}
								} catch (Exception e) {  }
								p.sendMessage(start.prefix + "�cERROR! Please Report this Error to �aMr_Coding! �3ERROR CODE: �eTNTWarsSpawnerGWgetSGW.nameworlds.getName");
								return true;
							}
						}
						p.sendMessage("�cEin Fataler Fehler ist aufgetreten! Bitte berichte dies dem");
						p.sendMessage("�aDEVELOPER �cnamens �6Mr_Coding");
						p.sendMessage("�cBitte �berpr�fe die Config.yml in des Plugins �a\"TNTWars\"!");
						return true;
					} else {
						p.sendMessage(start.prefix + "Bitte gebe einen �eSpawner-�aNamen �dan!");
						return true;
					}
				} else {
					noPermission(p);
					return true;
				}
			}
			
			if(args[0].equalsIgnoreCase("Reset")) {
				if(p.hasPermission("TNTWars.WorldReset")) {
					File fileTNTWars = new File("TNTWars");
					File fileTNTWarsReset = new File("TNTWarsReset");
					
					try {
						Map_Reset MR = new Map_Reset(plugin);
						World worldres = MR.resetMap(fileTNTWarsReset, fileTNTWars, "TNTWars");
						
						for(Player all : Bukkit.getOnlinePlayers()) {
							all.teleport(worldres.getSpawnLocation());
							all.sendMessage(start.prefix + "Map Reset �aerfolgreich!");
						}
						
					} catch (IOException e) {
						e.printStackTrace();
					}
					return true;
				} else {
					noPermission(p);
					return true;
				}
			}
			
			if(args[0].equalsIgnoreCase("setBuilder")) {
				if(sender.hasPermission("TNTWars.setBuilder")) {
					//Legt den Builder der Map fest
					if(args.length > 1) {
						for(World world : this.plugin.getServer().getWorlds()) {
							if(p.getWorld().getName().equalsIgnoreCase(world.getName())) {
								plugin.getConfig().set("GameWorld." + world.getName() + ".Builder", args[1]);
								p.sendMessage(start.prefix + "Builder erfolgreich festgelegt! Name: " + plugin.getConfig().getString("GameWorld." + world.getName() + ".Builder", args[1]));
								plugin.saveConfig();
								plugin.reloadConfig();
								return true;
							}
						}
						p.sendMessage(start.prefix + "Diese Welt wurde �cnicht " + ChatColor.LIGHT_PURPLE + "registriert!");
						p.sendMessage(start.prefix + "Lege diese mit: " + ChatColor.GOLD + "/TNTWars setLobby " + ChatColor.LIGHT_PURPLE + "fest!");
						return true;
					} else {
						p.sendMessage(start.prefix + "Bitte gebe mindestens " + ChatColor.YELLOW + "zwei " + ChatColor.GOLD + "Argumente " + ChatColor.LIGHT_PURPLE + "an!");
						p.sendMessage(start.prefix + ChatColor.YELLOW + "2. " + ChatColor.LIGHT_PURPLE + "Argument: " + ChatColor.GOLD + "Name");
						return true;
					}
				} else {
					noPermission(p);
					return true;
				}
			}
			
			//Setzt den Worldspawn f�r Blau oder Rot
			if(args[0].equalsIgnoreCase("setworldspawn")) {
				if(sender.hasPermission("TNTWars.setworldspawn") || sender.isOp()) {
					if(args.length > 1) {
						if(sender instanceof Player) {
							
							String Worldname = p.getLocation().getWorld().getName();
							final String Blue = "GameWorld." + Worldname + ".Spawn.Blue";
							final String Red = "GameWorld." + Worldname + ".Spawn.Red";
							
							double plocx = p.getLocation().getX();
							double plocy = p.getLocation().getY();
							double plocz = p.getLocation().getZ();
							
							
							
							if(args[1].equalsIgnoreCase("blue")) {
								
								plugin.getConfig().set(Blue + ".Koords.X", plocx);
								plugin.getConfig().set(Blue + ".Koords.Y", plocy);
								plugin.getConfig().set(Blue + ".Koords.Z", plocz);
								plugin.getConfig().set(Blue + ".Koords.EyePitch", p.getLocation().getPitch());
								plugin.getConfig().set(Blue + ".Koords.EyeYaw", p.getLocation().getYaw());
								plugin.getConfig().set("GameWorld.name" + Worldname, Worldname);
								
								//Nachricht -
								p.sendMessage(start.prefix + ChatColor.GREEN + "Erfolgreich Welt spawn  f�r Team Blau auf " 
								+ ChatColor.YELLOW + "X:" + ChatColor.GOLD + plocx + ChatColor.YELLOW + " Y:" + ChatColor.GOLD 
								+ plocy + ChatColor.YELLOW + " Z:" + ChatColor.GOLD + plocz + ChatColor.YELLOW + " EyeYaw:" 
								+ ChatColor.GOLD + p.getLocation().getYaw() + ChatColor.YELLOW + " EyePitch:" + ChatColor.GOLD 
								+ p.getLocation().getPitch() + ChatColor.GREEN + " gesetzt!");
								//Nachricht -
							}

							if(args[1].equalsIgnoreCase("red")) {
								
								plugin.getConfig().set(Red + ".Koords.X", plocx);
								plugin.getConfig().set(Red + ".Koords.Y", plocy);
								plugin.getConfig().set(Red + ".Koords.Z", plocz);
								plugin.getConfig().set(Red + ".Koords.EyePitch", p.getLocation().getPitch());
								plugin.getConfig().set(Red + ".Koords.EyeYaw", p.getLocation().getYaw());
								plugin.getConfig().set("GameWorld.name" + Worldname, Worldname);
								
								//Nachricht -
								p.sendMessage(start.prefix + ChatColor.GREEN + "Erfolgreich Welt spawn  f�r Team Rot auf " 
								+ ChatColor.YELLOW + "X:" + ChatColor.GOLD + plocx + ChatColor.YELLOW + " Y:" + ChatColor.GOLD 
								+ plocy + ChatColor.YELLOW + " Z:" + ChatColor.GOLD + plocz + ChatColor.YELLOW + " EyeYaw:" 
								+ ChatColor.GOLD + p.getLocation().getYaw() + ChatColor.YELLOW + " EyePitch:" + ChatColor.GOLD 
								+ p.getLocation().getPitch() + ChatColor.GREEN + " gesetzt!");
								//Nachricht -
							}
							
							plugin.saveConfig();
							plugin.reloadConfig();
							return true;
						}
					} else {
						p.sendMessage(start.prefix + "Bitte gebe ein " + ChatColor.GOLD + "Argument " + ChatColor.LIGHT_PURPLE + "an!");
						p.sendMessage(start.prefix + "'Red' f�r Team " + ChatColor.RED + "Rot");
						p.sendMessage(start.prefix + "'Blue' f�r Team " + ChatColor.BLUE + "Blau");
						return true;
					}
				} else {
					noPermission(p);
					return true;
				}
			}
			
			//Setzt die Lobby f�r das warten, bis die Runde beginnt!
			if(args[0].equalsIgnoreCase("setlobby")) {
				
				if(sender.hasPermission("TNTWars.setLobby") || sender.isOp()) {
						if(sender instanceof Player) {
							
							String Worldname = p.getLocation().getWorld().getName();
							final String Lobby = "GameWorld." + Worldname + ".Lobby";
							
							double plocx = p.getLocation().getX();
							double plocy = p.getLocation().getY();
							double plocz = p.getLocation().getZ();
							
								plugin.getConfig().set(Lobby + ".Koords.X", plocx);
								plugin.getConfig().set(Lobby + ".Koords.Y", plocy);
								plugin.getConfig().set(Lobby + ".Koords.Z", plocz);
								plugin.getConfig().set(Lobby + ".Koords.EyePitch", p.getLocation().getPitch());
								plugin.getConfig().set(Lobby + ".Koords.EyeYaw", p.getLocation().getYaw());
								plugin.getConfig().set("GameWorld.name" + Worldname, Worldname);
								
								//Nachricht -
								p.sendMessage(start.prefix + ChatColor.GREEN + "Erfolgreich Lobby spawn auf " 
								+ ChatColor.YELLOW + "X:" + ChatColor.GOLD + plocx + ChatColor.YELLOW + " Y:" + ChatColor.GOLD 
								+ plocy + ChatColor.YELLOW + " Z:" + ChatColor.GOLD + plocz + ChatColor.YELLOW + " EyeYaw:" 
								+ ChatColor.GOLD + p.getLocation().getYaw() + ChatColor.YELLOW + " EyePitch:" + ChatColor.GOLD 
								+ p.getLocation().getPitch() + ChatColor.GREEN + " gesetzt!");
								//Nachricht -
								
							
							plugin.saveConfig();
							plugin.reloadConfig();
							return true;
						}
				} else {
					noPermission(p);
					return true;
				}
			}
			
			//Command zum joinen einer Runde
			if(args[0].equalsIgnoreCase("join")) {
				if(p.hasPermission("TNTWars.join")) {
					if(args.length > 1) {
						for(World world : this.plugin.getServer().getWorlds()) {
							if(args[1].equalsIgnoreCase(world.getName())) {
								if(!(GameManager.noTeam.contains(p) || GameManager.rot.contains(p) || GameManager.blau.contains(p))) {
									//Neues System
									GameManager.noTeam.add(p);
									
									//Alte Location des Spielers sichern
									Location localtep = p.getLocation();
									localtep.setPitch(p.getLocation().getPitch());
									localtep.setYaw(p.getLocation().getYaw());
									Location.put(p, localtep);
									
										
									//location -
									Location locspawn = new Location(world, plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Lobby.Koords.X"), plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Lobby.Koords.Y"), plugin.getConfig().getDouble("GameWorld." + world.getName() +
											".Lobby.Koords.Z"), (float) plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Lobby.Koords.EyeYaw"), (float) plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Lobby.Koords.EyePitch"));
									//location -
									
									//location blue -
									Location locblue = new Location(world, plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Spawn.Blue.Koords.X"), plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Spawn.Blue.Koords.Y"), plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Spawn.Blue.Koords.Z"), (float) plugin.getConfig().getDouble("GameWorld." + world.getName() +
											".Spawn.Blue.Koords.EyeYaw"), (float) plugin.getConfig().getDouble("GameWorld." + 
											world.getName() + ".Spawn.Blue.Koords.EyePitch"));
									//location blue -
									
									//location red -
									Location locred = new Location(world, plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Spawn.Red.Koords.X"), plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Spawn.Red.Koords.Y"), plugin.getConfig().getDouble("GameWorld." + world.getName() + 
											".Spawn.Red.Koords.Z"), (float) plugin.getConfig().getDouble("GameWorld." + world.getName() +
											".Spawn.Red.Koords.EyeYaw"), (float) plugin.getConfig().getDouble("GameWorld." + 
											world.getName() + ".Spawn.Red.Koords.EyePitch"));
									//location red -
									
									p.teleport(locspawn);
									p.setGameMode(GameMode.ADVENTURE);
									p.sendMessage(start.prefix + "Du bist dem Spiel " + ChatColor.YELLOW + world.getName() + ChatColor.LIGHT_PURPLE + " beigetreten!");
									
									GameManager.rot.remove(p);
									GameManager.blau.remove(p);
									GameManager.noTeam.remove(p);
									GameManager.noTeam.add(p);
									
									
									
									//Inventar vom Spieler sichern
									plugin.saveinventory.put(p.getName(), p.getInventory().getContents());
									p.getInventory().clear();
									
									//Compass hinzuf�gen
									ItemStack team = new ItemStack(Material.COMPASS);
									ItemMeta teammeta = team.getItemMeta();
									
									teammeta.setDisplayName(ChatColor.GOLD + "Team ausw�hlen");
									
									ArrayList<String> teamlore = new ArrayList<>();
									teamlore.add(ChatColor.LIGHT_PURPLE + "W�hle ein Team!");
									
									teammeta.setLore(teamlore);
									team.setItemMeta(teammeta);
									
									p.getInventory().setItem(4, team);
									
									
									try {
										Bukkit.getScheduler().cancelTask(Schedjoin);	
									} catch(Exception ex) {}
									
									
									
									if(!(Bukkit.getScheduler().isCurrentlyRunning(Schedjoin))) {
										Schedjoin = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {

											@Override
											public void run() {
												if(lobbytime == 30 || lobbytime == 20 || lobbytime == 10 || lobbytime < 6) {
													
													//Nachricht senden, und alle Spieler in der ArrayList unter "all" speichern
													for(Player all : plugin.getServer().getOnlinePlayers()) {
														
														for(Player allsr : GameManager.rot) {
															if(allsr.getName().equalsIgnoreCase(all.getName())) {
																all.sendMessage(start.prefix + "Das Spiel beginnt in " + ChatColor.YELLOW + lobbytime);
																all.setLevel(lobbytime);
															}
														}
														
														for(Player allsb : GameManager.blau) {
															if(allsb.getName().equalsIgnoreCase(all.getName())) {
																all.sendMessage(start.prefix + "Das Spiel beginnt in " + ChatColor.YELLOW + lobbytime);
																all.setLevel(lobbytime);
															}
														}
														
														for(Player allsn : GameManager.noTeam) {
															if(allsn.getName().equalsIgnoreCase(all.getName())) {
																all.sendMessage(start.prefix + "Das Spiel beginnt in " + ChatColor.YELLOW + lobbytime);
																all.setLevel(lobbytime);
															}
														}
														
													}
												}
												
												if(lobbytime < 1) {
													
													//Team setzung
													try {
														while(GameManager.noTeam.size() > 0) {
															for(Player all1 : Bukkit.getOnlinePlayers()) {
																if(GameManager.noTeam.contains(all1)) {

																	
																	if(GameManager.rot.size() > GameManager.blau.size()) {
																		GameManager.blau.add(all1);
																		GameManager.noTeam.remove(all1);
																		GameManager.rot.remove(all1);
																		
																	} else if(GameManager.blau.size() > GameManager.rot.size()) {
																		GameManager.rot.add(all1);
																		GameManager.noTeam.remove(all1);
																		GameManager.blau.remove(all1);
																		
																	} else if(GameManager.rot.size() == GameManager.blau.size()) {
																		int RndmTeam = new Random().nextInt(2);
																		if(RndmTeam == 1) {
																			GameManager.blau.add(all1);
																			GameManager.noTeam.remove(all1);
																			GameManager.rot.remove(all1);
																		}
																		
																		if(RndmTeam == 0) {
																			GameManager.rot.add(all1);
																			GameManager.noTeam.remove(all1);
																			GameManager.blau.remove(all1);
																		}
																	}

																}
															}
														}
														
													} catch(Exception ex) {}
													
													
													if(GameManager.rot.size() > 0 && GameManager.blau.size() > 0) {
														

														GameManager GM = new GameManager(plugin);
														GM.startSpawners(locred.getWorld().getName());
														
														try {
															for(Player allTeamsRot : Bukkit.getServer().getOnlinePlayers()) {
																//F�rs ROTE Team
																for(Player allr : GameManager.rot) {
																	if(allr.getName().equalsIgnoreCase(allTeamsRot.getName())) {
																		
																		
																		allTeamsRot.sendMessage(start.prefix + "Das Spiel " + ChatColor.YELLOW + "BEGINNT!");
																		allTeamsRot.teleport(locred);
																		GameManager.rot.remove(allTeamsRot);
																		
																		
																		
																		
																		//Code beim BEGINNEN des Spiels
																		
																		//Rotes Team
																		allTeamsRot.sendMessage(start.prefix + "Dieses Spiel ist noch in der " + ChatColor.RED +
																				"BETHAPHASE! " + ChatColor.LIGHT_PURPLE + "Bitte habe daf�r verst�ndnis! Bei "
																						+ "Vorschl�gen / Verbesserungen bitte bei " + ChatColor.GREEN + "Mr_Coding " +
																						ChatColor.LIGHT_PURPLE + "melden!");
																		allTeamsRot.sendMessage(start.prefix + "Map build by: " + ChatColor.GOLD + plugin.getConfig().getString("GameWorld." + world.getName() + ".Builder"));
																		
																		allTeamsRot.getInventory().clear();

																		allTeamsRot.setGameMode(GameMode.ADVENTURE);
																		
																		//items
																		GranadeThrower.Common(allTeamsRot, 0, 1);
																		Granate.Granade(allTeamsRot, 1, 1);
																		TNTCanon.TNTCanon(allTeamsRot, 2, 1);
																		TNTMissle.Cruiser(allTeamsRot, 3, 10);
																		
																		
																	}	
																}
															}
														} catch(Exception ex) {}
																
																
															try {
																for(Player allTeamsBlau : plugin.getServer().getOnlinePlayers()) {
																	//F�rs BLAUE Team
																	
																	for(Player allb : GameManager.blau) {
																		if(allb.getName().equalsIgnoreCase(allTeamsBlau.getName())) {
																			
																			
																			allTeamsBlau.sendMessage(start.prefix + "Das Spiel " + ChatColor.YELLOW + "BEGINNT!");
																			allTeamsBlau.teleport(locblue);
																			GameManager.blau.remove(allTeamsBlau.getName());
																			
																			
																			
																			
																			//Code beim BEGINNEN des Spiels
																			
																			//Blaues Team
																			allTeamsBlau.sendMessage(start.prefix + "Dieses Spiel ist noch in der " + ChatColor.RED +
																					"BETHAPHASE! " + ChatColor.LIGHT_PURPLE + "Bitte habe daf�r verst�ndnis! Bei "
																							+ "Vorschl�gen / Verbesserungen bitte bei " + ChatColor.GREEN + "Mr_Coding " +
																							ChatColor.LIGHT_PURPLE + "melden!");
																			allTeamsBlau.sendMessage(start.prefix + "Map build by: " + ChatColor.GOLD + plugin.getConfig().getString("GameWorld." + world.getName() + ".Builder"));
																			
																			allTeamsBlau.getInventory().clear();
																			
																			allTeamsBlau.setGameMode(GameMode.ADVENTURE);
																			
																			//items
																			GranadeThrower.Common(allTeamsBlau, 0, 1);
																			Granate.Granade(allTeamsBlau, 1, 1);
																			TNTCanon.TNTCanon(allTeamsBlau, 2, 1);
																			TNTMissle.Cruiser(allTeamsBlau, 3, 10);
																			
																			
																		}
																	}
																}
															} catch(Exception ex) {}
															
															lobbytime = 31;
															
															
															Bukkit.getScheduler().cancelTask(Schedjoin);
															
															
															
															SchedReset = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {

																//Standard: 900 = 15 min
																int Timer = 900;
																
																
																@Override
																public void run() {
																	
																	Timer--;
																	if(Timer < 1) {
																		Bukkit.getScheduler().cancelTask(SchedReset);
																		for(World world : Bukkit.getWorlds()) {
																			for(Player all : Bukkit.getOnlinePlayers()) {
																				if(all.getWorld().getName().equalsIgnoreCase(world.getName())) {
																					all.sendMessage("�dDie Runde ist �cvorbei!");
																					
																					GM.stopSpawners(world.getName());
																				}
																			}
																		}
																		
																		
																		try {
																			Map_Reset MR = new Map_Reset(plugin);
																			World worldres = MR.resetMap(new File("TNTWarsReset"), new File("TNTWars"), "TNTWars");
																			
																			for(Player all : Bukkit.getOnlinePlayers()) {
																				all.teleport(worldres.getSpawnLocation());
																			}
																			
																			
																		} catch (IOException e) {
																			e.printStackTrace();
																		}
																		
																		
																		return;
																	}
																	
																}
																
															}, 0, 20);
															
															
															
															
													} else {
														
														for(Player all : Bukkit.getOnlinePlayers()) {
															
															//F�rs ROTE Team
															for(Player allr : GameManager.rot) {
																if(all.getName().equalsIgnoreCase(allr.getName())) {
																	all.sendMessage(start.prefix + "Es sind " + ChatColor.YELLOW + "zu WENIG " + ChatColor.LIGHT_PURPLE + "in der Runde!"
																			+ " --> Neustart!");
																}	
															}
															
															//F�rs BLAUE Team
															for(Player allb : GameManager.blau) {
																if(all.getName().equalsIgnoreCase(allb.getName())) {
																	all.sendMessage(start.prefix + "Es sind " + ChatColor.YELLOW + "zu WENIG " + ChatColor.LIGHT_PURPLE + "in der Runde!"
																			+ " --> Neustart!");
																}
															}
															
															//F�rs NOTEAM Team
															for(Player allr : GameManager.noTeam) {
																if(all.getName().equalsIgnoreCase(allr.getName())) {
																	all.sendMessage(start.prefix + "Es sind " + ChatColor.YELLOW + "zu WENIG " + ChatColor.LIGHT_PURPLE + "in der Runde!"
																			+ " --> Neustart!");
																}	
															}
															
															lobbytime = 31;
														}	
													}
													
 												} else {
 													
 													//Nachricht senden, und alle Spieler in der ArrayList unter "all" speichern
													for(Player all : plugin.getServer().getOnlinePlayers()) {
														
														for(Player allsr : GameManager.rot) {
															if(allsr.getName().equalsIgnoreCase(all.getName())) {
																all.setLevel(lobbytime);
															}
														}
														
														for(Player allsb : GameManager.blau) {
															if(allsb.getName().equalsIgnoreCase(all.getName())) {
																all.setLevel(lobbytime);
															}
														}
														
														for(Player allsn : GameManager.noTeam) {
															if(allsn.getName().equalsIgnoreCase(all.getName())) {
																all.setLevel(lobbytime);
															}
														}
														
													}

 													lobbytime--;
													
 												}
											}
											
										}, 0, 20);	
									} else {
										Bukkit.getScheduler().cancelTask(Schedjoin);
									}
									
									
									joinforbreak = true;
								} else {
									p.sendMessage(start.prefix + "Du " + ChatColor.YELLOW + "bist " + ChatColor.LIGHT_PURPLE + "bereits in einem Spiel!");
									joinforbreak = true;
								}
								
							}
						}
						//wenn der bool false bleibt, wird dem spieler gesagt, das spiel gibts nicht!, andernfalls wird der wert auf
						//false gesetzt, um erneut zu testen
						if(joinforbreak == false) {
							p.sendMessage(start.prefix + "Dieses Spiel gibt es nicht!");
						} else {
							joinforbreak = false;
						}
					} else {
						p.sendMessage(start.prefix + "Bitte gebe ein " + ChatColor.GOLD + "Argument " + ChatColor.LIGHT_PURPLE + "an!");
					}	
				} else {
					noPermission(p);
					return true;
				}
				return true;
			}
			
			//Zum Leften des games
			if(args[0].equalsIgnoreCase("l") || args[0].equalsIgnoreCase("leave")) {
				if(p.hasPermission("TNTWars.leave")) {
					if(GameManager.rot.contains(p) || 
							GameManager.blau.contains(p) || 
							GameManager.noTeam.contains(p)) {
						
						GameManager.rot.remove(p);
						GameManager.blau.remove(p);
						GameManager.noTeam.remove(p);
						try {
							if(Location.containsKey(p)) {
								Location loc = Location.get(p);
								p.teleport(loc);
								p.sendMessage(start.prefix + "Du hast die Runde " + ChatColor.RED + "verlassen!");
								ItemStack[] getinvcontents = plugin.saveinventory.get(p.getName());
								try {
									p.getInventory().setContents(getinvcontents);
									return true;
								} catch(Exception ex) {}
								return true;
							}
						} catch(Exception ex) {}	
					} else {
						p.sendMessage(start.prefix + ChatColor.LIGHT_PURPLE + "Du bist in " + ChatColor.RED + "keiner " + ChatColor.LIGHT_PURPLE + "Runde!");
						return true;
					}
				} else {
					noPermission(p);
					return true;
				}
			}
			
			if(args[0].equalsIgnoreCase("start")) {
				if(p.hasPermission("TNTWars.start")) {
					if(GameManager.blau.contains(p) || GameManager.rot.contains(p) || GameManager.noTeam.contains(p)) {
						if(this.lobbytime > 10) {
							this.lobbytime = 10;
							return true;
						} else {
							return true;
						}
					} else {
						p.sendMessage("�dDu bist in �ckeinem �dSpiel!");
						return true;
					}
				} else {
					sender.sendMessage(start.prefix + ChatColor.RED + "Nicht gen�gend Rechte!");
					return true;
				}
			}
			
			//Zum testen von exestierenden Spielen
			if(args[0].equalsIgnoreCase("games")) {
				gameanzahl = 0;
				for(World world : this.plugin.getServer().getWorlds()) {
					if(world.getName().equalsIgnoreCase(this.plugin.getConfig().getString("GameWorld.name" + world.getName()))) {
						gameanzahl++;
					}
				}
				if(gameanzahl == 1) {
					p.sendMessage(start.prefix + "Derzeit ist " + ChatColor.YELLOW + gameanzahl + ChatColor.LIGHT_PURPLE + " Spiel verf�gbar!");
				} else {
					p.sendMessage(start.prefix + "Derzeit sind " + ChatColor.YELLOW + gameanzahl + ChatColor.LIGHT_PURPLE + " Spiele verf�gbar!");
				}
				return true;
			}
			
			//Shop
			if(args[0].equalsIgnoreCase("Shop")) {
				if(sender.hasPermission("TNTWars.Shop")) {
					if(args.length > 1) {
						Entity Ent = p.getWorld().spawnEntity(p.getLocation(), EntityType.CREEPER);
						Creeper Shop = (Creeper) Ent;
						if(args[1].equalsIgnoreCase("Rot")) {
							Shop.setCustomName("�cShop");
						} else if(args[1].equalsIgnoreCase("Blau")) {
							Shop.setCustomName("�1Shop");
						} else {
							Shop.remove();
							p.sendMessage(start.prefix + "Unbekanntes �6Argument!");
							return true;
						}
						Shop.setCustomNameVisible(true);
						Shop.setFallDistance(0.0f);
						((LivingEntity) Ent).setRemoveWhenFarAway(false);
						Shop.setNoDamageTicks(Integer.MAX_VALUE);
						Shop.setCanPickupItems(false);
						Shop.setPowered(true);
						
						
						p.sendMessage(start.prefix + "Shop wurde erstellt!");
						return true;
					} else {
						p.sendMessage(start.prefix + "Zu wenig �6Argumente!");
						p.sendMessage("");
						p.sendMessage("�d/TNTWars �6Shop �eTeam �d(�cRot �d/ �1Blau�d)");
						return true;
					}
				} else {
					noPermission(p);
					return true;
				}
			}
			
			p.sendMessage(start.prefix + "Unbekanntest " + ChatColor.GOLD + "Argument!");
			return true;
		} else {
			Usage(sender);
		}
		
		if(sender.hasPermission("TNTWars.help")) {
			//hilfe
			if(args.length > 0) {
				if(args[0].equalsIgnoreCase("help")) {
					Usage(sender);
				}	
			}
		} else {
			sender.sendMessage(start.prefix + "Nicht gen�gend Rechte!");
		}
		return true;
		} else {
			noPlayer(sender);
			sender.sendMessage("�dVerf�gbare �aArgumente:");
			sender.sendMessage("");
			sender.sendMessage("�dVersion");
			sender.sendMessage("�dBugs");
			sender.sendMessage("�dReload");
			sender.sendMessage("�dHelp");
			return true;
		}
	}
	
	
	
	
	//Methods -1 
	private void Usage(CommandSender sender) {
		sender.sendMessage(start.prefix + "�3Alle Verf�gbaren �aCommands:");
		sender.sendMessage("");
		
		if(sender.hasPermission("TNTWars.Version")) {
			sender.sendMessage("�dVersion       �eZeigt die aktuelle Version!");
		}
		
		if(sender.hasPermission("TNTWars.Bugs")) {
			sender.sendMessage("�dBugs          �eZeigt alle bekannten Bugs!");
		}
		
		if(sender.hasPermission("TNTWars.Reload")) {
			sender.sendMessage("�dReload        �eReloadet das Plugin");
		}
		sender.sendMessage("�dHelp");
		
		
		
		

		sender.sendMessage("");
		if(sender.hasPermission("TNTWars.setworldspawn")) {
			sender.sendMessage("�6setworldspawn �dsetze den Weltspawn f�r Team �cRot");
			sender.sendMessage("�d              oder f�r Team �1Blau!");
		}
		
		if(sender.hasPermission("TNTWars.join")) {
			sender.sendMessage("�6join          �djoine einer Runde!");	
		}
		
		if(sender.hasPermission("TNTWars.setLobby")) {
			sender.sendMessage("�6setLobby      �dsetze die Lobby f�r ein Spiel!");
		}
		
		if(sender.hasPermission("TNTWars.leave")) {
			sender.sendMessage("�6leave         �dverlasse ein Spiel!");
		}
		
		if(sender.hasPermission("TNTWars.setBuilder")) {
			sender.sendMessage("�6setBuilder    �dsetze den / die Builder der Map!");
		}
		
		if(sender.hasPermission("TNTWars.Shop")) {
			sender.sendMessage("�6Shop          �derstelle einen Shop!");
		}
		
		if(sender.hasPermission("TNTWars.Reset")) {
			sender.sendMessage("�6Reset         �dResete Die Welt!");
		}
		
		if(sender.hasPermission("TNTWars.Spawner")) {
			sender.sendMessage("�6Spawner       �dSetze Spawner!");
		}
		
		return;
	}
	
	private void noPlayer(CommandSender sender) {
		sender.sendMessage(start.prefix + "Du bist �ckein �dSpieler!");
		return;
	}
	
	public static void currentBugs(CommandSender sender) {
		sender.sendMessage(start.prefix + "Listing all Bugs...");
		sender.sendMessage("");
		sender.sendMessage("�cSpawner set        �a| �6Sometimes you have to add the World in");
		sender.sendMessage("                         �6the Config.yml!");
		sender.sendMessage("�cTNTCanon           �a| �6Only working a �3\"bit\" �6in the northern");
		sender.sendMessage("                         �6Direction");
	}
	
	private void noPermission(CommandSender sender) {
		sender.sendMessage(start.prefix + "�cNicht gen�gend Rechte!");
	}
	
	//Methods -2
	
}