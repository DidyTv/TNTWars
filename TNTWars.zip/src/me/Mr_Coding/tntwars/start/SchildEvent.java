package me.Mr_Coding.tntwars.start;

import org.bukkit.block.Sign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class SchildEvent implements Listener {

	
	private start plugin;

	public SchildEvent(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}
	
	@EventHandler
	public void onSignChange(SignChangeEvent e) {
		Player p = e.getPlayer();
		if(e.getLine(0).equalsIgnoreCase("[tntwars]")) {
			p.sendMessage(start.prefix + "Schild wurde erfolgreich gesetzt!");
		}
	}
	
	@EventHandler
	public void onPlayerClickSign(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		if(e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if(e.getClickedBlock().getState() instanceof Sign) {
				Sign s = (Sign) e.getClickedBlock().getState();
				
				
				if(s.getLine(0).equalsIgnoreCase("[tntwars]")) {
					p.performCommand("tntwars join " + s.getLine(1));
				}	
			}
		}
	}
}
