package me.Mr_Coding.tntwars.start;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class CompassEvent implements Listener {

	
	private start plugin;
	public CompassEvent(start main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}
	
	@EventHandler
	public void onCompassClick(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		if(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if(e.getMaterial().equals(Material.COMPASS)) {
				ItemStack team = e.getItem();
				ItemMeta teammeta = team.getItemMeta();
				
				if(teammeta.getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "Team ausw�hlen")) {
					//Team Rot
					ItemStack RoteWolle = new ItemStack(Material.WOOL);
					ItemMeta RoteWollemeta = RoteWolle.getItemMeta();
					RoteWollemeta.setDisplayName(ChatColor.RED + "Rot");
					RoteWolle.setDurability((short) 14);
					
					
					RoteWolle.setItemMeta(RoteWollemeta);
					
					plugin.invTeams.setItem(3, RoteWolle);
					
					
					//Team Blau
					ItemStack BlaueWolle = new ItemStack(Material.WOOL);
					ItemMeta BlaueWollemeta = BlaueWolle.getItemMeta();
					BlaueWollemeta.setDisplayName(ChatColor.BLUE + "Blau");
					BlaueWolle.setDurability((short) 11);
					
					
					BlaueWolle.setItemMeta(BlaueWollemeta);
					
					plugin.invTeams.setItem(5, BlaueWolle);
					
					p.openInventory(plugin.invTeams);
				}
			}
		}
	}

}
