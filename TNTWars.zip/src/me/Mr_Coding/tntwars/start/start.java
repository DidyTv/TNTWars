package me.Mr_Coding.tntwars.start;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import me.Mr_Coding.tntwars.items.Granate;
import me.Mr_Coding.tntwars.items.TNTCanon;
import me.Mr_Coding.tntwars.items.TNTMissle;
import me.Mr_Coding.tntwars.items.GranadeThrower;


public class start extends JavaPlugin {
	
	
	
	final static String consoleprefix = "[TNTWars] ";
	public final static String prefix = "�2[�4TNT�6Wars�2]�d ";
	
	public Inventory invTeams = Bukkit.createInventory(null, 9, ChatColor.GREEN + "Team w�hlen");
	
	HashMap<String, ItemStack[]> saveinventory = new HashMap<>();

	
	
	
	public void onEnable() {
		this.reloadConfig();
		loadConfig();
		registerCommands();
		registerEvents();
		Bukkit.getConsoleSender().sendMessage(prefix + "geladen");
	}
	
	public void onDisable() {
		Bukkit.getConsoleSender().sendMessage(prefix + "entladen");
	}
	
	public void loadConfig() {
		FileConfiguration fcg = this.getConfig();
		fcg.options().copyDefaults(true);
		saveConfig();
	}
	
	public void registerCommands() {
		Commands cCommands = new Commands(this);
		getCommand("tntwars").setExecutor(cCommands);
	}
	
	public void registerEvents() {
		new Shop(this);
		new SchildEvent(this);
		new CompassEvent(this);
		new TeamEvent(this);
		new GameManager(this);
		new GranadeThrower(this);
		new Granate(this);
		new Events(this);
		new TNTCanon(this);
		new HimmelsRichtung(this);
		new TNTMissle(this);
		new Map_Reset(this);
	}
}
