package me.Mr_Coding.tntwars.start;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import me.Mr_Coding.tntwars.items.GranadeThrower;
import me.Mr_Coding.tntwars.items.Granate;
import me.Mr_Coding.tntwars.items.TNTMissle;

public class Shop implements Listener {

	private Plugin plugin;
	public Shop(start start) {
		this.plugin = start;
		plugin.getServer().getPluginManager().registerEvents(this, plugin);
		defineShops();
	}
	
	private void notenoughLevel(Player p) {
		p.sendMessage(start.prefix + "�cDu hast zu wenig �aLevel");
	}
	
	private void defineShops() {
		//Public Options
		
		//ItemStacks
		ItemStack ISS_G_P = new ItemStack(Material.STAINED_GLASS_PANE);
		ItemStack ISMissle = new ItemStack(Material.MONSTER_EGG);
		ItemStack ISMissles = new ItemStack(Material.MONSTER_EGG);
		ItemStack ISGranade = new ItemStack(Material.FIREWORK_CHARGE);
		ItemStack ISGranades = new ItemStack(Material.CLAY_BALL);
		ItemStack ISGranadeThrs = new ItemStack(Material.DIAMOND_SWORD);
		ItemStack ISGranadeThr = new ItemStack(Material.DIAMOND_SWORD);
		ItemStack ISBows = new ItemStack(Material.BOW);
		ItemStack ISNormal_Bow = new ItemStack(Material.BOW);
		ItemStack ISFire_Bow = new ItemStack(Material.BOW);
		
		//Back / Exit
		ItemStack ISExit = new ItemStack(Material.BARRIER);
		ItemStack ISBack = new ItemStack(Material.BARRIER);
		

		//ItemStacks bearbeiten
		ISS_G_P.setDurability((short) 7);
		ISMissle.setDurability((short) 93);
		
		
		//ItemMetas
		ItemMeta IMS_G_P = ISS_G_P.getItemMeta();
		ItemMeta IMMissles = ISMissles.getItemMeta();
		ItemMeta IMMissle = ISMissle.getItemMeta();
		ItemMeta IMGranade = ISGranade.getItemMeta();
		ItemMeta IMGranades = ISGranades.getItemMeta();
		ItemMeta IMGranadeThrs = ISGranadeThrs.getItemMeta();
		ItemMeta IMGranadeThr = ISGranadeThr.getItemMeta();
		ItemMeta IMBows = ISBows.getItemMeta();
		ItemMeta IMNormal_Bow = ISNormal_Bow.getItemMeta();
		ItemMeta IMFire_Bow = ISFire_Bow.getItemMeta();

		//Back / Exit
		ItemMeta IMExit = ISExit.getItemMeta();
		ItemMeta IMBack = ISBack.getItemMeta();
		
		
		//ItemMetas bearbeiten
		IMS_G_P.setDisplayName("�8");
		IMMissles.setDisplayName("�6Missles");
		IMMissle.setDisplayName("�6TNT Cruiser");
		IMGranades.setDisplayName("�6Granaten");
		IMGranade.setDisplayName("�6Normale Granate");
		IMGranadeThrs.setDisplayName("�6Granat-Werfer");
		IMGranadeThr.setDisplayName("�6Normaler Granatwerfer");
		IMBows.setDisplayName("�6B�gen");
		IMNormal_Bow.setDisplayName("�6Normaler Bogen");
		IMFire_Bow.setDisplayName("�6Feuer Bogen");
		
		IMExit.setDisplayName("�cEXIT");
		IMBack.setDisplayName("�cBACK");
		
		
		//Loren erstellen
		ArrayList<String> MissleCruiser = new ArrayList<String>();
		ArrayList<String> IMGranadeNormal = new ArrayList<String>();
		ArrayList<String> LoreGranadeThr = new ArrayList<String>();
		
		
		//Loren bearbeiten
		MissleCruiser.add("�a5 Level");
		IMGranadeNormal.add("�a2 Level");
		LoreGranadeThr.add("�a4 Level");
		
		
		//Loren setzen
		IMMissle.setLore(MissleCruiser);
		IMGranade.setLore(IMGranadeNormal);
		IMGranadeThr.setLore(LoreGranadeThr);
		
		
		//Verzauberungen
		IMExit.addEnchant(Enchantment.ARROW_DAMAGE, 0, false);
		IMBack.addEnchant(Enchantment.ARROW_DAMAGE, 0, false);
		
		
		//ItemMetas setzen
		ISS_G_P.setItemMeta(IMS_G_P);
		ISMissles.setItemMeta(IMMissles);
		ISMissle.setItemMeta(IMMissle);
		ISGranade.setItemMeta(IMGranade);
		ISGranades.setItemMeta(IMGranades);
		ISGranadeThrs.setItemMeta(IMGranadeThrs);
		ISGranadeThr.setItemMeta(IMGranadeThr);

		ISExit.setItemMeta(IMExit);
		ISBack.setItemMeta(IMBack);
		
		
		
		
		
		
		
		
		//Rot -1
		
		//1. Reihe
		invShopRot.setItem(0, ISS_G_P);
		invShopRot.setItem(1, ISS_G_P);
		invShopRot.setItem(2, ISS_G_P);
		invShopRot.setItem(3, ISS_G_P);
		invShopRot.setItem(4, ISS_G_P);
		invShopRot.setItem(5, ISS_G_P);
		invShopRot.setItem(6, ISS_G_P);
		invShopRot.setItem(7, ISS_G_P);
		invShopRot.setItem(8, ISS_G_P);
		
		
		//Items
		invShopRot.setItem(9, ISMissles);
		invShopRot.setItem(10, ISGranades);
		invShopRot.setItem(11, ISGranadeThrs);
		//Exit
		invShopRot.setItem(17, ISExit);
		
		
		//2. Reihe
		invShopRot.setItem(18, ISS_G_P);
		invShopRot.setItem(19, ISS_G_P);
		invShopRot.setItem(20, ISS_G_P);
		invShopRot.setItem(21, ISS_G_P);
		invShopRot.setItem(22, ISS_G_P);
		invShopRot.setItem(23, ISS_G_P);
		invShopRot.setItem(24, ISS_G_P);
		invShopRot.setItem(25, ISS_G_P);
		invShopRot.setItem(26, ISS_G_P);

		//Rot -2
		
		//Blau -1
		
		//1. Reihe
		invShopBlau.setItem(0, ISS_G_P);
		invShopBlau.setItem(1, ISS_G_P);
		invShopBlau.setItem(2, ISS_G_P);
		invShopBlau.setItem(3, ISS_G_P);
		invShopBlau.setItem(4, ISS_G_P);
		invShopBlau.setItem(5, ISS_G_P);
		invShopBlau.setItem(6, ISS_G_P);
		invShopBlau.setItem(7, ISS_G_P);
		invShopBlau.setItem(8, ISS_G_P);
		
		
		//Items
		invShopBlau.setItem(9, ISMissles);
		invShopBlau.setItem(10, ISGranades);
		invShopBlau.setItem(11, ISGranadeThrs);
		//Exit
		invShopBlau.setItem(17, ISExit);
		
		
		//2. Reihe
		invShopBlau.setItem(18, ISS_G_P);
		invShopBlau.setItem(19, ISS_G_P);
		invShopBlau.setItem(20, ISS_G_P);
		invShopBlau.setItem(21, ISS_G_P);
		invShopBlau.setItem(22, ISS_G_P);
		invShopBlau.setItem(23, ISS_G_P);
		invShopBlau.setItem(24, ISS_G_P);
		invShopBlau.setItem(25, ISS_G_P);
		invShopBlau.setItem(26, ISS_G_P);
		
		//Blau -2
		
		//invShopMissleRot -1
		
		//1. Reihe
		invShopMisslesRot.setItem(0, ISS_G_P);
		invShopMisslesRot.setItem(1, ISS_G_P);
		invShopMisslesRot.setItem(2, ISS_G_P);
		invShopMisslesRot.setItem(3, ISS_G_P);
		invShopMisslesRot.setItem(4, ISS_G_P);
		invShopMisslesRot.setItem(5, ISS_G_P);
		invShopMisslesRot.setItem(6, ISS_G_P);
		invShopMisslesRot.setItem(7, ISS_G_P);
		invShopMisslesRot.setItem(8, ISS_G_P);
		
		
		//Items
		invShopMisslesRot.setItem(9, ISMissle);
		//Exit
		invShopMisslesRot.setItem(17, ISBack);
		
		//2. Reihe
		
		invShopMisslesRot.setItem(18, ISS_G_P);
		invShopMisslesRot.setItem(19, ISS_G_P);
		invShopMisslesRot.setItem(20, ISS_G_P);
		invShopMisslesRot.setItem(21, ISS_G_P);
		invShopMisslesRot.setItem(22, ISS_G_P);
		invShopMisslesRot.setItem(23, ISS_G_P);
		invShopMisslesRot.setItem(24, ISS_G_P);
		invShopMisslesRot.setItem(25, ISS_G_P);
		invShopMisslesRot.setItem(26, ISS_G_P);
		
		//invShopMissleRot -2
		
		//invShopMissleBlau -1
		
		//1. Reihe
		invShopMisslesBlau.setItem(0, ISS_G_P);
		invShopMisslesBlau.setItem(1, ISS_G_P);
		invShopMisslesBlau.setItem(2, ISS_G_P);
		invShopMisslesBlau.setItem(3, ISS_G_P);
		invShopMisslesBlau.setItem(4, ISS_G_P);
		invShopMisslesBlau.setItem(5, ISS_G_P);
		invShopMisslesBlau.setItem(6, ISS_G_P);
		invShopMisslesBlau.setItem(7, ISS_G_P);
		invShopMisslesBlau.setItem(8, ISS_G_P);
		
		
		//Items
		invShopMisslesBlau.setItem(9, ISMissle);
		//Exit
		invShopMisslesBlau.setItem(17, ISBack);
		
		//2. Reihe
		invShopMisslesBlau.setItem(18, ISS_G_P);
		invShopMisslesBlau.setItem(19, ISS_G_P);
		invShopMisslesBlau.setItem(20, ISS_G_P);
		invShopMisslesBlau.setItem(21, ISS_G_P);
		invShopMisslesBlau.setItem(22, ISS_G_P);
		invShopMisslesBlau.setItem(23, ISS_G_P);
		invShopMisslesBlau.setItem(24, ISS_G_P);
		invShopMisslesBlau.setItem(25, ISS_G_P);
		invShopMisslesBlau.setItem(26, ISS_G_P);
		
		//invShopMissleBlau -2
		
		//invShopGranadesRot -1
		
		//1. Reihe
		invShopGranadesRot.setItem(0, ISS_G_P);
		invShopGranadesRot.setItem(1, ISS_G_P);
		invShopGranadesRot.setItem(2, ISS_G_P);
		invShopGranadesRot.setItem(3, ISS_G_P);
		invShopGranadesRot.setItem(4, ISS_G_P);
		invShopGranadesRot.setItem(5, ISS_G_P);
		invShopGranadesRot.setItem(6, ISS_G_P);
		invShopGranadesRot.setItem(7, ISS_G_P);
		invShopGranadesRot.setItem(8, ISS_G_P);
		
		
		//Items
		invShopGranadesRot.setItem(9, ISGranade);
		//Exit
		invShopGranadesRot.setItem(17, ISBack);
		
		
		//2. Reihe
		invShopGranadesRot.setItem(18, ISS_G_P);
		invShopGranadesRot.setItem(19, ISS_G_P);
		invShopGranadesRot.setItem(20, ISS_G_P);
		invShopGranadesRot.setItem(21, ISS_G_P);
		invShopGranadesRot.setItem(22, ISS_G_P);
		invShopGranadesRot.setItem(23, ISS_G_P);
		invShopGranadesRot.setItem(24, ISS_G_P);
		invShopGranadesRot.setItem(25, ISS_G_P);
		invShopGranadesRot.setItem(26, ISS_G_P);
		
		//invShopGranadesRot -2
		
		//invShopGranadesBlau -1
		
		//1. Reihe
		invShopGranadesBlau.setItem(0, ISS_G_P);
		invShopGranadesBlau.setItem(1, ISS_G_P);
		invShopGranadesBlau.setItem(2, ISS_G_P);
		invShopGranadesBlau.setItem(3, ISS_G_P);
		invShopGranadesBlau.setItem(4, ISS_G_P);
		invShopGranadesBlau.setItem(5, ISS_G_P);
		invShopGranadesBlau.setItem(6, ISS_G_P);
		invShopGranadesBlau.setItem(7, ISS_G_P);
		invShopGranadesBlau.setItem(8, ISS_G_P);
		
		//Items
		invShopGranadesBlau.setItem(9, ISGranade);
		//Exit
		invShopGranadesBlau.setItem(17, ISBack);
		
		
		//2. Reihe
		invShopGranadesBlau.setItem(18, ISS_G_P);
		invShopGranadesBlau.setItem(19, ISS_G_P);
		invShopGranadesBlau.setItem(20, ISS_G_P);
		invShopGranadesBlau.setItem(21, ISS_G_P);
		invShopGranadesBlau.setItem(22, ISS_G_P);
		invShopGranadesBlau.setItem(23, ISS_G_P);
		invShopGranadesBlau.setItem(24, ISS_G_P);
		invShopGranadesBlau.setItem(25, ISS_G_P);
		invShopGranadesBlau.setItem(26, ISS_G_P);
		
		//invShopGranadesBlau -2
		
		//invShopGranadeThrRot -1
		
		//1. Reihe
		invShopGranadeThrRot.setItem(0, ISS_G_P);
		invShopGranadeThrRot.setItem(1, ISS_G_P);
		invShopGranadeThrRot.setItem(2, ISS_G_P);
		invShopGranadeThrRot.setItem(3, ISS_G_P);
		invShopGranadeThrRot.setItem(4, ISS_G_P);
		invShopGranadeThrRot.setItem(5, ISS_G_P);
		invShopGranadeThrRot.setItem(6, ISS_G_P);
		invShopGranadeThrRot.setItem(7, ISS_G_P);
		invShopGranadeThrRot.setItem(8, ISS_G_P);
		
		//Items
		invShopGranadeThrRot.setItem(9, ISGranadeThr);
		//Exit
		invShopGranadeThrRot.setItem(17, ISBack);
		
		
		//2. Reihe
		invShopGranadeThrRot.setItem(18, ISS_G_P);
		invShopGranadeThrRot.setItem(19, ISS_G_P);
		invShopGranadeThrRot.setItem(20, ISS_G_P);
		invShopGranadeThrRot.setItem(21, ISS_G_P);
		invShopGranadeThrRot.setItem(22, ISS_G_P);
		invShopGranadeThrRot.setItem(23, ISS_G_P);
		invShopGranadeThrRot.setItem(24, ISS_G_P);
		invShopGranadeThrRot.setItem(25, ISS_G_P);
		invShopGranadeThrRot.setItem(26, ISS_G_P);
		
		//invShopGranadeThrRot -2
		
		//invShopGranadeThrBlau -1
		
		//1. Reihe
		invShopGranadeThrBlau.setItem(0, ISS_G_P);
		invShopGranadeThrBlau.setItem(1, ISS_G_P);
		invShopGranadeThrBlau.setItem(2, ISS_G_P);
		invShopGranadeThrBlau.setItem(3, ISS_G_P);
		invShopGranadeThrBlau.setItem(4, ISS_G_P);
		invShopGranadeThrBlau.setItem(5, ISS_G_P);
		invShopGranadeThrBlau.setItem(6, ISS_G_P);
		invShopGranadeThrBlau.setItem(7, ISS_G_P);
		invShopGranadeThrBlau.setItem(8, ISS_G_P);
		
		//Items
		invShopGranadeThrBlau.setItem(9, ISGranadeThr);
		//Exit
		invShopGranadeThrBlau.setItem(17, ISBack);
		
		
		//2. Reihe
		invShopGranadeThrBlau.setItem(18, ISS_G_P);
		invShopGranadeThrBlau.setItem(19, ISS_G_P);
		invShopGranadeThrBlau.setItem(20, ISS_G_P);
		invShopGranadeThrBlau.setItem(21, ISS_G_P);
		invShopGranadeThrBlau.setItem(22, ISS_G_P);
		invShopGranadeThrBlau.setItem(23, ISS_G_P);
		invShopGranadeThrBlau.setItem(24, ISS_G_P);
		invShopGranadeThrBlau.setItem(25, ISS_G_P);
		invShopGranadeThrBlau.setItem(26, ISS_G_P);
		
		//invShopGranadeThrBlau -2
		
		//invShopBowsRot -1
		
		//1. Reihe
		invShopBowsRot.setItem(0, ISS_G_P);
		invShopBowsRot.setItem(1, ISS_G_P);
		invShopBowsRot.setItem(2, ISS_G_P);
		invShopBowsRot.setItem(3, ISS_G_P);
		invShopBowsRot.setItem(4, ISS_G_P);
		invShopBowsRot.setItem(5, ISS_G_P);
		invShopBowsRot.setItem(6, ISS_G_P);
		invShopBowsRot.setItem(7, ISS_G_P);
		invShopBowsRot.setItem(8, ISS_G_P);
		
		//Items
		invShopBowsRot.setItem(9, ISNormal_Bow);
		//Exit
		invShopBowsRot.setItem(17, ISBack);
		
		
		//2. Reihe//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//invShopBowsBlau -2
		
		
		
		Bukkit.getConsoleSender().sendMessage(start.prefix + "�cShop wurde geladen!");
		
	}
	
	// Shop Men�
	
	public Inventory invShopRot = Bukkit.createInventory(null, 9*3, "�cShop");
	public Inventory invShopBlau = Bukkit.createInventory(null, 9*3, "�1Shop");
	
	
	//Shop Items / Gadgets

	public Inventory invShopMisslesRot = Bukkit.createInventory(null, 9*3, "�cMissles");
	public Inventory invShopMisslesBlau = Bukkit.createInventory(null, 9*3, "�1Missles");
	public Inventory invShopGranadesRot = Bukkit.createInventory(null, 9*3, "�cGranades");
	public Inventory invShopGranadesBlau = Bukkit.createInventory(null, 9*3, "�1Granades");
	public Inventory invShopGranadeThrRot = Bukkit.createInventory(null, 9*3, "�cGranade Throwers");
	public Inventory invShopGranadeThrBlau = Bukkit.createInventory(null, 9*3, "�1Granade Throwers");
	public Inventory invShopBowsRot = Bukkit.createInventory(null, 9*3, "�cBows");
	public Inventory invShopBowsBlau = Bukkit.createInventory(null, 9*3, "�1Bows");
	
	
	@EventHandler
	public void onInteractEntity(PlayerInteractEntityEvent e) {
		Player p = e.getPlayer();
		if(e.getRightClicked().getType() == EntityType.CREEPER) {
			Creeper Shop = (Creeper) e.getRightClicked();
			if(Shop.getCustomName().equalsIgnoreCase("�cShop")) {
				p.openInventory(invShopRot);
				return;
			}
			
			if(Shop.getCustomName().equalsIgnoreCase("�1Shop")) {
				p.openInventory(invShopBlau);
				return;
			}
		}
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent e) {
		try {
			Player p = (Player) e.getWhoClicked();

			
			
			//Shop Men�
			if(e.getInventory() != null) {
				if(e.getInventory().getName() != null) {
					if(e.getInventory().getName().equalsIgnoreCase("�cShop")) {
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Missles")) {
							e.setCancelled(true);
							p.openInventory(invShopMisslesRot);
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Granaten")) {
							e.setCancelled(true);
							p.openInventory(invShopGranadesRot);
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Granat-Werfer")) {
							e.setCancelled(true);
							p.openInventory(invShopGranadeThrRot);
						}
						

						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�cEXIT")) {
							e.setCancelled(true);
							p.closeInventory();
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8")) {
							e.setCancelled(true);
						}
						return;
					}
					
					if(e.getInventory().getName().equalsIgnoreCase("�1Shop")) {
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Missles")) {
							e.setCancelled(true);
							p.openInventory(invShopMisslesBlau);
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Granaten")) {
							e.setCancelled(true);
							p.openInventory(invShopGranadesBlau);
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Granat-Werfer")) {
							e.setCancelled(true);
							p.openInventory(invShopGranadeThrBlau);
						}
						
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�cEXIT")) {
							e.setCancelled(true);
							e.setCancelled(true);
							p.closeInventory();
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8")) {
							e.setCancelled(true);
						}
						return;
					}
					
					
					//Shop Bl�cke
					if(e.getInventory().getName().equalsIgnoreCase("�cMissles")) {
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6TNT Cruiser")) {
							e.setCancelled(true);
							if(e.getClick() == ClickType.SHIFT_LEFT) {
								if(p.getLevel() >= 5*64) {
									p.setLevel(p.getLevel() - 5*64);
									TNTMissle.Cruiser(p, 64);
								} else {
									notenoughLevel(p);
								}
							} else if(p.getLevel() >= 5) {
								p.setLevel(p.getLevel() - 5);
								TNTMissle.Cruiser(p, 1);
							} else {
								notenoughLevel(p);
							}
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8")) {
							e.setCancelled(true);
						}

						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�cBACK")) {
							e.setCancelled(true);
							p.openInventory(invShopRot);
						}
						return;
					}
					
					if(e.getInventory().getName().equalsIgnoreCase("�1Missles")) {
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6TNT Cruiser")) {
							e.setCancelled(true);
							if(e.getClick() == ClickType.SHIFT_LEFT) {
								if(p.getLevel() >= 5*64) {
									p.setLevel(p.getLevel() - 5*64);
									TNTMissle.Cruiser(p, 64);
								} else {
									notenoughLevel(p);
								}
							} else if(p.getLevel() >= 5) {
								p.setLevel(p.getLevel() - 5);
								TNTMissle.Cruiser(p, 1);
							} else {
								notenoughLevel(p);
							}
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8")) {
							e.setCancelled(true);
						}

						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�cBACK")) {
							e.setCancelled(true);
							p.openInventory(invShopBlau);
						}
						return;
					}
					
					if(e.getInventory().getName().equalsIgnoreCase("�cGranades")) {
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Normale Granate")) {
							e.setCancelled(true);
							if(e.getClick() == ClickType.SHIFT_LEFT) {
								if(p.getLevel() >= 2*64) {
									Granate.Granade(p, 64);
									p.setLevel(p.getLevel() - 2*64);
								} else {
									notenoughLevel(p);
								}
							} else if(p.getLevel() >= 2) {
								Granate.Granade(p, 1);
								p.setLevel(p.getLevel() - 2);
							} else {
								notenoughLevel(p);
							}

						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8")) {
							e.setCancelled(true);
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�cBACK")) {
							e.setCancelled(true);
							p.openInventory(invShopRot);
						}
						return;
					}
					
					if(e.getInventory().getName().equalsIgnoreCase("�1Granades")) {
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Normale Granate")) {
							e.setCancelled(true);
							if(e.getClick() == ClickType.SHIFT_LEFT) {
								if(p.getLevel() >= 2*64) {
									Granate.Granade(p, 64);
									p.setLevel(p.getLevel() - 2*64);
								} else {
									notenoughLevel(p);
								}
							} else if(p.getLevel() >= 2) {
								Granate.Granade(p, 1);
								p.setLevel(p.getLevel() - 2);
							} else {
								notenoughLevel(p);
							}
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8")) {
							e.setCancelled(true);
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�cBACK")) {
							e.setCancelled(true);
							p.openInventory(invShopBlau);
						}
						return;
					}
					
					if(e.getInventory().getName().equalsIgnoreCase("�cGranade Throwers")) {
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Normaler Granatwerfer")) {
							e.setCancelled(true);
							if(p.getLevel() >= 4) {
								GranadeThrower.Common(p, 1);
								p.setLevel(p.getLevel() - 4);
							} else {
								notenoughLevel(p);
							}
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8")) {
							e.setCancelled(true);
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�cBACK")) {
							e.setCancelled(true);
							p.openInventory(invShopBlau);
						}
						return;
					}
					
					if(e.getInventory().getName().equalsIgnoreCase("�1Granade Throwers")) {
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Normaler Granatwerfer")) {
							e.setCancelled(true);
							if(p.getLevel() >= 4) {
								GranadeThrower.Common(p, 1);
								p.setLevel(p.getLevel() - 4);
							} else {
								notenoughLevel(p);
							}
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8")) {
							e.setCancelled(true);
						}
						
						if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�cBACK")) {
							e.setCancelled(true);
							p.openInventory(invShopBlau);
						}
						return;
					}
					
					
				}
			}
			
			
		} catch (Exception ex) {  }
	}
	
	//Creeper Explosion verhindern
	@EventHandler
	public void onCreeperTarget(EntityTargetEvent e) {
		try {
			if(e.getEntity().getType() == EntityType.CREEPER) {
				Creeper Creeper = (Creeper) e.getEntity();
				if(Creeper.getCustomName().equalsIgnoreCase("�cShop") || Creeper.getCustomName().equalsIgnoreCase("�1Shop")) {
					e.setCancelled(true);
				}
			}
		} catch (Exception ex) {  }
	}
	
	@EventHandler
	public void onCreeperPrime(EntityExplodeEvent e) {
		try {
			if(e.getEntity().getType() == EntityType.CREEPER) {
				Creeper Creeper = (Creeper) e.getEntity();
				if(Creeper.getCustomName() != null) {
					if(Creeper.getCustomName().equalsIgnoreCase("�cShop") || Creeper.getCustomName().equalsIgnoreCase("�1Shop")) {
						e.setCancelled(true);
					}
				}
			}
		} catch (Exception ex) {  }
	}
	
	@EventHandler
	public void onEntDamage(EntityDamageEvent e) {
		try {
			if(e.getEntity().getType() == EntityType.CREEPER) {
				if(e.getEntity().getCustomName() != null) {
					if(e.getEntity().getCustomName().equalsIgnoreCase("�cShop") || e.getEntity().getCustomName().equalsIgnoreCase("�1Shop")) {
						e.setCancelled(true);
					}
				}
			}
		} catch (Exception ex) {  }
	}
	
	@EventHandler
	public void onCreeperPrime(ExplosionPrimeEvent e) {
		if(e.getEntity().getType() == EntityType.CREEPER) {
			if(e.getEntity().getCustomName() != null) {
				if(e.getEntity().getCustomName().equalsIgnoreCase("�cShop")) {
					Location loc = e.getEntity().getLocation();
					World world = e.getEntity().getWorld();
					e.setCancelled(true);
					e.getEntity().remove();
					
					Entity Ent = world.spawnEntity(loc, EntityType.CREEPER);
					Ent.teleport(loc);
					Creeper Shop = (Creeper) Ent;
					Shop.setCustomName("�cShop");
					Shop.setCustomNameVisible(true);
					Shop.setFallDistance(0.0f);
					((LivingEntity) Ent).setRemoveWhenFarAway(false);
					Shop.setNoDamageTicks(Integer.MAX_VALUE);
					Shop.setCanPickupItems(false);
					Shop.setPowered(true);
				}
				
				if(e.getEntity().getCustomName().equalsIgnoreCase("�1Shop")) {
					Location loc = e.getEntity().getLocation();
					World world = e.getEntity().getWorld();
					e.setCancelled(true);
					e.getEntity().remove();
					
					Entity Ent = world.spawnEntity(loc, EntityType.CREEPER);
					Ent.teleport(loc);
					Creeper Shop = (Creeper) Ent;
					Shop.setCustomName("�1Shop");
					Shop.setCustomNameVisible(true);
					Shop.setFallDistance(0.0f);
					((LivingEntity) Ent).setRemoveWhenFarAway(false);
					Shop.setNoDamageTicks(Integer.MAX_VALUE);
					Shop.setCanPickupItems(false);
					Shop.setPowered(true);
				}
			}
		}
	}
	
	
	
}
