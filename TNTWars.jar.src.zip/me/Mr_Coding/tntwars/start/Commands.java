/*     */ package me.Mr_Coding.tntwars.start;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import me.Mr_Coding.tntwars.items.TNTCanon;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Creeper;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class Commands implements org.bukkit.command.CommandExecutor
/*     */ {
/*     */   private start plugin;
/*     */   int gameanzahl;
/*     */   
/*     */   public Commands(start main)
/*     */   {
/*  34 */     this.plugin = main;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  39 */   int lobbytime = 31;
/*     */   
/*     */   int lobbyscheduler;
/*     */   
/*     */   int Schedjoin;
/*     */   int SchedReset;
/*  45 */   public static HashMap<Player, Location> Location = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */   boolean joinforbreak = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean onCommand(CommandSender sender, org.bukkit.command.Command cmd, String label, String[] args)
/*     */   {
/*  60 */     if (args.length > 0)
/*     */     {
/*  62 */       if (args[0].equalsIgnoreCase("Version")) {
/*  63 */         if (sender.hasPermission("TNTWars.Version")) {
/*  64 */           sender.sendMessage("§2[§4TNT§6Wars§2]§d Aktuelle Version: §a" + this.plugin.getDescription().getVersion());
/*  65 */           return true;
/*     */         }
/*  67 */         noPermission(sender);
/*  68 */         return true;
/*     */       }
/*     */       
/*     */ 
/*  72 */       if (args[0].equalsIgnoreCase("Bugs")) {
/*  73 */         if (sender.hasPermission("TNTWars.Bugs")) {
/*  74 */           currentBugs(sender);
/*  75 */           return true;
/*     */         }
/*  77 */         noPermission(sender);
/*  78 */         return true;
/*     */       }
/*     */       
/*     */ 
/*  82 */       if (args[0].equalsIgnoreCase("Reload")) {
/*  83 */         if (sender.hasPermission("TNTWars.Reload")) {
/*     */           try {
/*  85 */             sender.sendMessage("§2[§4TNT§6Wars§2]§d §2Starting Reload...");
/*  86 */             this.plugin.saveConfig();
/*  87 */             this.plugin.reloadConfig();
/*  88 */             sender.sendMessage("§2[§4TNT§6Wars§2]§d Reload §acomplete!");
/*  89 */           } catch (Exception e) { sender.sendMessage("§2[§4TNT§6Wars§2]§d Reload §aFAILED!");
/*     */           }
/*  91 */           return true;
/*     */         }
/*  93 */         noPermission(sender);
/*  94 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */     if ((sender instanceof Player)) {
/* 103 */       Player p = (Player)sender;
/*     */       
/* 105 */       if (args.length > 0)
/*     */       {
/*     */         double Y;
/*     */         
/*     */ 
/* 110 */         if (args[0].equalsIgnoreCase("Spawner")) {
/* 111 */           if (p.hasPermission("TNTWars.Spawner")) {
/* 112 */             if (args.length > 1) {
/* 113 */               if (!(sender instanceof Player)) {
/* 114 */                 if (args.length > 5) {
/* 115 */                   for (World worlds : Bukkit.getWorlds()) {
/* 116 */                     if (worlds.getName().equalsIgnoreCase(args[5]))
/*     */                       try {
/* 118 */                         int Count = 0;
/*     */                         
/* 120 */                         double X = Double.parseDouble(args[2]);
/* 121 */                         Y = Double.parseDouble(args[3]);
/* 122 */                         double Z = Double.parseDouble(args[4]);
/*     */                         
/* 124 */                         Count = this.plugin.getConfig().getInt("GameWorld." + worlds.getName() + ".Spawners.Count") + 1;
/* 125 */                         this.plugin.getConfig().set("GameWorld.name" + worlds.getName(), worlds.getName());
/*     */                         
/* 127 */                         if (this.plugin.getConfig().getString("GameWorld.name" + worlds.getName()).equalsIgnoreCase(worlds.getName())) {
/* 128 */                           this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners.Count", Integer.valueOf(Count));
/* 129 */                           this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".World", p.getLocation().getWorld().getName());
/* 130 */                           this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Name", args[1]);
/* 131 */                           this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".X", Double.valueOf(X));
/* 132 */                           this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Y", Double.valueOf(Y));
/* 133 */                           this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Z", Double.valueOf(Z));
/*     */                           
/* 135 */                           sender.sendMessage("§2[§4TNT§6Wars§2]§d Added Spawner §6number §3" + Count + "§d, §6Name §a" + args[1] + "§d with Location:");
/* 136 */                           sender.sendMessage("§eX: §d" + X);
/* 137 */                           sender.sendMessage("§eY: §d" + Y);
/* 138 */                           sender.sendMessage("§eZ: §d" + Z);
/*     */                           
/* 140 */                           this.plugin.saveConfig();
/* 141 */                           return true;
/*     */                         }
/*     */                       } catch (Exception localException1) {
/* 144 */                         p.sendMessage("§2[§4TNT§6Wars§2]§d §cERROR! Please Report this Error to §aMr_Coding! §3ERROR CODE: §eTNTWarsSpawnerGWgetSGW.nameworlds.getName");
/* 145 */                         return true;
/*     */                       }
/*     */                   }
/* 148 */                   sender.sendMessage("§cEin Fataler Fehler ist aufgetreten! Bitte berichte dies dem");
/* 149 */                   sender.sendMessage("§aDEVELOPER §cnamens §6Mr_Coding");
/* 150 */                   sender.sendMessage("§cBitte überprüfe die Config.yml in des Plugins §a\"TNTWars\"!");
/* 151 */                   return true;
/*     */                 }
/* 153 */                 sender.sendMessage("§2[§4TNT§6Wars§2]§d Es fehlen §6Argumente!");
/* 154 */                 sender.sendMessage("§62. §dName");
/* 155 */                 sender.sendMessage("§63. §dX");
/* 156 */                 sender.sendMessage("§64. §dY");
/* 157 */                 sender.sendMessage("§65. §dZ");
/* 158 */                 sender.sendMessage("§66. §dWorldname");
/* 159 */                 return true;
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 164 */               for (World worlds : Bukkit.getWorlds()) {
/* 165 */                 if (worlds.getName().equalsIgnoreCase(p.getWorld().getName()))
/*     */                   try {
/* 167 */                     int Count = 0;
/* 168 */                     Count = this.plugin.getConfig().getInt("GameWorld." + worlds.getName() + ".Spawners.Count") + 1;
/* 169 */                     this.plugin.getConfig().set("GameWorld.name" + worlds.getName(), worlds.getName());
/*     */                     
/* 171 */                     if (this.plugin.getConfig().getString("GameWorld.name" + worlds.getName()).equalsIgnoreCase(worlds.getName())) {
/* 172 */                       this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners.Count", Integer.valueOf(this.plugin.getConfig().getInt("GameWorld." + worlds.getName() + ".Spawners.Count") + 1));
/* 173 */                       this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".World", p.getLocation().getWorld().getName());
/* 174 */                       this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Name", args[1]);
/* 175 */                       this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".X", Double.valueOf(p.getLocation().getX()));
/* 176 */                       this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Y", Double.valueOf(p.getLocation().getY()));
/* 177 */                       this.plugin.getConfig().set("GameWorld." + worlds.getName() + ".Spawners." + Count + ".Z", Double.valueOf(p.getLocation().getZ()));
/*     */                       
/* 179 */                       p.sendMessage("§2[§4TNT§6Wars§2]§d Added Spawner §6number §3" + Count + "§d, §6Name §a" + args[1] + "§d with Location:");
/* 180 */                       p.sendMessage("§eX: §d" + p.getLocation().getX());
/* 181 */                       p.sendMessage("§eY: §d" + p.getLocation().getY());
/* 182 */                       p.sendMessage("§eZ: §d" + p.getLocation().getZ());
/*     */                       
/* 184 */                       this.plugin.saveConfig();
/* 185 */                       return true;
/*     */                     }
/*     */                   } catch (Exception localException2) {
/* 188 */                     p.sendMessage("§2[§4TNT§6Wars§2]§d §cERROR! Please Report this Error to §aMr_Coding! §3ERROR CODE: §eTNTWarsSpawnerGWgetSGW.nameworlds.getName");
/* 189 */                     return true;
/*     */                   }
/*     */               }
/* 192 */               p.sendMessage("§cEin Fataler Fehler ist aufgetreten! Bitte berichte dies dem");
/* 193 */               p.sendMessage("§aDEVELOPER §cnamens §6Mr_Coding");
/* 194 */               p.sendMessage("§cBitte überprüfe die Config.yml in des Plugins §a\"TNTWars\"!");
/* 195 */               return true;
/*     */             }
/* 197 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Bitte gebe einen §eSpawner-§aNamen §dan!");
/* 198 */             return true;
/*     */           }
/*     */           
/* 201 */           noPermission(p);
/* 202 */           return true;
/*     */         }
/*     */         
/*     */         Object fileTNTWarsReset;
/* 206 */         if (args[0].equalsIgnoreCase("Reset")) {
/* 207 */           if (p.hasPermission("TNTWars.WorldReset")) {
/* 208 */             File fileTNTWars = new File("TNTWars");
/* 209 */             fileTNTWarsReset = new File("TNTWarsReset");
/*     */             try
/*     */             {
/* 212 */               Map_Reset MR = new Map_Reset(this.plugin);
/* 213 */               World worldres = MR.resetMap((File)fileTNTWarsReset, fileTNTWars, "TNTWars");
/*     */               
/* 215 */               for (Player all : Bukkit.getOnlinePlayers()) {
/* 216 */                 all.teleport(worldres.getSpawnLocation());
/* 217 */                 all.sendMessage("§2[§4TNT§6Wars§2]§d Map Reset §aerfolgreich!");
/*     */               }
/*     */             }
/*     */             catch (IOException e) {
/* 221 */               e.printStackTrace();
/*     */             }
/* 223 */             return true;
/*     */           }
/* 225 */           noPermission(p);
/* 226 */           return true;
/*     */         }
/*     */         
/*     */ 
/* 230 */         if (args[0].equalsIgnoreCase("setBuilder")) {
/* 231 */           if (sender.hasPermission("TNTWars.setBuilder"))
/*     */           {
/* 233 */             if (args.length > 1) {
/* 234 */               for (fileTNTWarsReset = this.plugin.getServer().getWorlds().iterator(); ((Iterator)fileTNTWarsReset).hasNext();) { World world = (World)((Iterator)fileTNTWarsReset).next();
/* 235 */                 if (p.getWorld().getName().equalsIgnoreCase(world.getName())) {
/* 236 */                   this.plugin.getConfig().set("GameWorld." + world.getName() + ".Builder", args[1]);
/* 237 */                   p.sendMessage("§2[§4TNT§6Wars§2]§d Builder erfolgreich festgelegt! Name: " + this.plugin.getConfig().getString(new StringBuilder("GameWorld.").append(world.getName()).append(".Builder").toString(), args[1]));
/* 238 */                   this.plugin.saveConfig();
/* 239 */                   this.plugin.reloadConfig();
/* 240 */                   return true;
/*     */                 }
/*     */               }
/* 243 */               p.sendMessage("§2[§4TNT§6Wars§2]§d Diese Welt wurde §cnicht " + ChatColor.LIGHT_PURPLE + "registriert!");
/* 244 */               p.sendMessage("§2[§4TNT§6Wars§2]§d Lege diese mit: " + ChatColor.GOLD + "/TNTWars setLobby " + ChatColor.LIGHT_PURPLE + "fest!");
/* 245 */               return true;
/*     */             }
/* 247 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Bitte gebe mindestens " + ChatColor.YELLOW + "zwei " + ChatColor.GOLD + "Argumente " + ChatColor.LIGHT_PURPLE + "an!");
/* 248 */             p.sendMessage("§2[§4TNT§6Wars§2]§d " + ChatColor.YELLOW + "2. " + ChatColor.LIGHT_PURPLE + "Argument: " + ChatColor.GOLD + "Name");
/* 249 */             return true;
/*     */           }
/*     */           
/* 252 */           noPermission(p);
/* 253 */           return true;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 258 */         if (args[0].equalsIgnoreCase("setworldspawn")) {
/* 259 */           if ((sender.hasPermission("TNTWars.setworldspawn")) || (sender.isOp())) {
/* 260 */             if (args.length > 1) {
/* 261 */               if ((sender instanceof Player))
/*     */               {
/* 263 */                 String Worldname = p.getLocation().getWorld().getName();
/* 264 */                 String Blue = "GameWorld." + Worldname + ".Spawn.Blue";
/* 265 */                 String Red = "GameWorld." + Worldname + ".Spawn.Red";
/*     */                 
/* 267 */                 double plocx = p.getLocation().getX();
/* 268 */                 double plocy = p.getLocation().getY();
/* 269 */                 double plocz = p.getLocation().getZ();
/*     */                 
/*     */ 
/*     */ 
/* 273 */                 if (args[1].equalsIgnoreCase("blue"))
/*     */                 {
/* 275 */                   this.plugin.getConfig().set(Blue + ".Koords.X", Double.valueOf(plocx));
/* 276 */                   this.plugin.getConfig().set(Blue + ".Koords.Y", Double.valueOf(plocy));
/* 277 */                   this.plugin.getConfig().set(Blue + ".Koords.Z", Double.valueOf(plocz));
/* 278 */                   this.plugin.getConfig().set(Blue + ".Koords.EyePitch", Float.valueOf(p.getLocation().getPitch()));
/* 279 */                   this.plugin.getConfig().set(Blue + ".Koords.EyeYaw", Float.valueOf(p.getLocation().getYaw()));
/* 280 */                   this.plugin.getConfig().set("GameWorld.name" + Worldname, Worldname);
/*     */                   
/*     */ 
/* 283 */                   p.sendMessage("§2[§4TNT§6Wars§2]§d " + ChatColor.GREEN + "Erfolgreich Welt spawn  für Team Blau auf " + 
/* 284 */                     ChatColor.YELLOW + "X:" + ChatColor.GOLD + plocx + ChatColor.YELLOW + " Y:" + ChatColor.GOLD + 
/* 285 */                     plocy + ChatColor.YELLOW + " Z:" + ChatColor.GOLD + plocz + ChatColor.YELLOW + " EyeYaw:" + 
/* 286 */                     ChatColor.GOLD + p.getLocation().getYaw() + ChatColor.YELLOW + " EyePitch:" + ChatColor.GOLD + 
/* 287 */                     p.getLocation().getPitch() + ChatColor.GREEN + " gesetzt!");
/*     */                 }
/*     */                 
/*     */ 
/* 291 */                 if (args[1].equalsIgnoreCase("red"))
/*     */                 {
/* 293 */                   this.plugin.getConfig().set(Red + ".Koords.X", Double.valueOf(plocx));
/* 294 */                   this.plugin.getConfig().set(Red + ".Koords.Y", Double.valueOf(plocy));
/* 295 */                   this.plugin.getConfig().set(Red + ".Koords.Z", Double.valueOf(plocz));
/* 296 */                   this.plugin.getConfig().set(Red + ".Koords.EyePitch", Float.valueOf(p.getLocation().getPitch()));
/* 297 */                   this.plugin.getConfig().set(Red + ".Koords.EyeYaw", Float.valueOf(p.getLocation().getYaw()));
/* 298 */                   this.plugin.getConfig().set("GameWorld.name" + Worldname, Worldname);
/*     */                   
/*     */ 
/* 301 */                   p.sendMessage("§2[§4TNT§6Wars§2]§d " + ChatColor.GREEN + "Erfolgreich Welt spawn  für Team Rot auf " + 
/* 302 */                     ChatColor.YELLOW + "X:" + ChatColor.GOLD + plocx + ChatColor.YELLOW + " Y:" + ChatColor.GOLD + 
/* 303 */                     plocy + ChatColor.YELLOW + " Z:" + ChatColor.GOLD + plocz + ChatColor.YELLOW + " EyeYaw:" + 
/* 304 */                     ChatColor.GOLD + p.getLocation().getYaw() + ChatColor.YELLOW + " EyePitch:" + ChatColor.GOLD + 
/* 305 */                     p.getLocation().getPitch() + ChatColor.GREEN + " gesetzt!");
/*     */                 }
/*     */                 
/*     */ 
/* 309 */                 this.plugin.saveConfig();
/* 310 */                 this.plugin.reloadConfig();
/* 311 */                 return true;
/*     */               }
/*     */             } else {
/* 314 */               p.sendMessage("§2[§4TNT§6Wars§2]§d Bitte gebe ein " + ChatColor.GOLD + "Argument " + ChatColor.LIGHT_PURPLE + "an!");
/* 315 */               p.sendMessage("§2[§4TNT§6Wars§2]§d 'Red' für Team " + ChatColor.RED + "Rot");
/* 316 */               p.sendMessage("§2[§4TNT§6Wars§2]§d 'Blue' für Team " + ChatColor.BLUE + "Blau");
/* 317 */               return true;
/*     */             }
/*     */           } else {
/* 320 */             noPermission(p);
/* 321 */             return true;
/*     */           }
/*     */         }
/*     */         
/*     */         Object Lobby;
/* 326 */         if (args[0].equalsIgnoreCase("setlobby"))
/*     */         {
/* 328 */           if ((sender.hasPermission("TNTWars.setLobby")) || (sender.isOp())) {
/* 329 */             if ((sender instanceof Player))
/*     */             {
/* 331 */               String Worldname = p.getLocation().getWorld().getName();
/* 332 */               Lobby = "GameWorld." + Worldname + ".Lobby";
/*     */               
/* 334 */               double plocx = p.getLocation().getX();
/* 335 */               double plocy = p.getLocation().getY();
/* 336 */               double plocz = p.getLocation().getZ();
/*     */               
/* 338 */               this.plugin.getConfig().set(Lobby + ".Koords.X", Double.valueOf(plocx));
/* 339 */               this.plugin.getConfig().set(Lobby + ".Koords.Y", Double.valueOf(plocy));
/* 340 */               this.plugin.getConfig().set(Lobby + ".Koords.Z", Double.valueOf(plocz));
/* 341 */               this.plugin.getConfig().set(Lobby + ".Koords.EyePitch", Float.valueOf(p.getLocation().getPitch()));
/* 342 */               this.plugin.getConfig().set(Lobby + ".Koords.EyeYaw", Float.valueOf(p.getLocation().getYaw()));
/* 343 */               this.plugin.getConfig().set("GameWorld.name" + Worldname, Worldname);
/*     */               
/*     */ 
/* 346 */               p.sendMessage("§2[§4TNT§6Wars§2]§d " + ChatColor.GREEN + "Erfolgreich Lobby spawn auf " + 
/* 347 */                 ChatColor.YELLOW + "X:" + ChatColor.GOLD + plocx + ChatColor.YELLOW + " Y:" + ChatColor.GOLD + 
/* 348 */                 plocy + ChatColor.YELLOW + " Z:" + ChatColor.GOLD + plocz + ChatColor.YELLOW + " EyeYaw:" + 
/* 349 */                 ChatColor.GOLD + p.getLocation().getYaw() + ChatColor.YELLOW + " EyePitch:" + ChatColor.GOLD + 
/* 350 */                 p.getLocation().getPitch() + ChatColor.GREEN + " gesetzt!");
/*     */               
/*     */ 
/*     */ 
/* 354 */               this.plugin.saveConfig();
/* 355 */               this.plugin.reloadConfig();
/* 356 */               return true;
/*     */             }
/*     */           } else {
/* 359 */             noPermission(p);
/* 360 */             return true;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 365 */         if (args[0].equalsIgnoreCase("join")) {
/* 366 */           if (p.hasPermission("TNTWars.join")) {
/* 367 */             if (args.length > 1) {
/* 368 */               for (Lobby = this.plugin.getServer().getWorlds().iterator(); ((Iterator)Lobby).hasNext();) { final World world = (World)((Iterator)Lobby).next();
/* 369 */                 if (args[1].equalsIgnoreCase(world.getName())) {
/* 370 */                   if ((!GameManager.noTeam.contains(p)) && (!GameManager.rot.contains(p)) && (!GameManager.blau.contains(p)))
/*     */                   {
/* 372 */                     GameManager.noTeam.add(p);
/*     */                     
/*     */ 
/* 375 */                     Location localtep = p.getLocation();
/* 376 */                     localtep.setPitch(p.getLocation().getPitch());
/* 377 */                     localtep.setYaw(p.getLocation().getYaw());
/* 378 */                     Location.put(p, localtep);
/*     */                     
/*     */ 
/*     */ 
/* 382 */                     Location locspawn = new Location(world, this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 383 */                       ".Lobby.Koords.X"), this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 384 */                       ".Lobby.Koords.Y"), this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 385 */                       ".Lobby.Koords.Z"), (float)this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 386 */                       ".Lobby.Koords.EyeYaw"), (float)this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 387 */                       ".Lobby.Koords.EyePitch"));
/*     */                     
/*     */ 
/*     */ 
/* 391 */                     final Location locblue = new Location(world, this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 392 */                       ".Spawn.Blue.Koords.X"), this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 393 */                       ".Spawn.Blue.Koords.Y"), this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 394 */                       ".Spawn.Blue.Koords.Z"), (float)this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 395 */                       ".Spawn.Blue.Koords.EyeYaw"), (float)this.plugin.getConfig().getDouble("GameWorld." + 
/* 396 */                       world.getName() + ".Spawn.Blue.Koords.EyePitch"));
/*     */                     
/*     */ 
/*     */ 
/* 400 */                     final Location locred = new Location(world, this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 401 */                       ".Spawn.Red.Koords.X"), this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 402 */                       ".Spawn.Red.Koords.Y"), this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 403 */                       ".Spawn.Red.Koords.Z"), (float)this.plugin.getConfig().getDouble("GameWorld." + world.getName() + 
/* 404 */                       ".Spawn.Red.Koords.EyeYaw"), (float)this.plugin.getConfig().getDouble("GameWorld." + 
/* 405 */                       world.getName() + ".Spawn.Red.Koords.EyePitch"));
/*     */                     
/*     */ 
/* 408 */                     p.teleport(locspawn);
/* 409 */                     p.setGameMode(GameMode.ADVENTURE);
/* 410 */                     p.sendMessage("§2[§4TNT§6Wars§2]§d Du bist dem Spiel " + ChatColor.YELLOW + world.getName() + ChatColor.LIGHT_PURPLE + " beigetreten!");
/*     */                     
/* 412 */                     GameManager.rot.remove(p);
/* 413 */                     GameManager.blau.remove(p);
/* 414 */                     GameManager.noTeam.remove(p);
/* 415 */                     GameManager.noTeam.add(p);
/*     */                     
/*     */ 
/*     */ 
/*     */ 
/* 420 */                     this.plugin.saveinventory.put(p.getName(), p.getInventory().getContents());
/* 421 */                     p.getInventory().clear();
/*     */                     
/*     */ 
/* 424 */                     ItemStack team = new ItemStack(org.bukkit.Material.COMPASS);
/* 425 */                     ItemMeta teammeta = team.getItemMeta();
/*     */                     
/* 427 */                     teammeta.setDisplayName(ChatColor.GOLD + "Team auswählen");
/*     */                     
/* 429 */                     ArrayList<String> teamlore = new ArrayList();
/* 430 */                     teamlore.add(ChatColor.LIGHT_PURPLE + "Wähle ein Team!");
/*     */                     
/* 432 */                     teammeta.setLore(teamlore);
/* 433 */                     team.setItemMeta(teammeta);
/*     */                     
/* 435 */                     p.getInventory().setItem(4, team);
/*     */                     
/*     */                     try
/*     */                     {
/* 439 */                       Bukkit.getScheduler().cancelTask(this.Schedjoin);
/*     */                     }
/*     */                     catch (Exception localException3) {}
/*     */                     
/*     */ 
/* 444 */                     if (!Bukkit.getScheduler().isCurrentlyRunning(this.Schedjoin)) {
/* 445 */                       this.Schedjoin = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable()
/*     */                       {
/*     */                         public void run() {
/*     */                           Iterator localIterator1;
/* 449 */                           if ((Commands.this.lobbytime == 30) || (Commands.this.lobbytime == 20) || (Commands.this.lobbytime == 10) || (Commands.this.lobbytime < 6))
/*     */                           {
/*     */ 
/* 452 */                             for (localIterator1 = Commands.this.plugin.getServer().getOnlinePlayers().iterator(); localIterator1.hasNext(); 
/*     */                                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 468 */                                 ???.hasNext())
/*     */                             {
/* 452 */                               Player all = (Player)localIterator1.next();
/*     */                               
/* 454 */                               for (Player allsr : GameManager.rot) {
/* 455 */                                 if (allsr.getName().equalsIgnoreCase(all.getName())) {
/* 456 */                                   all.sendMessage("§2[§4TNT§6Wars§2]§d Das Spiel beginnt in " + ChatColor.YELLOW + Commands.this.lobbytime);
/* 457 */                                   all.setLevel(Commands.this.lobbytime);
/*     */                                 }
/*     */                               }
/*     */                               
/* 461 */                               for (Player allsb : GameManager.blau) {
/* 462 */                                 if (allsb.getName().equalsIgnoreCase(all.getName())) {
/* 463 */                                   all.sendMessage("§2[§4TNT§6Wars§2]§d Das Spiel beginnt in " + ChatColor.YELLOW + Commands.this.lobbytime);
/* 464 */                                   all.setLevel(Commands.this.lobbytime);
/*     */                                 }
/*     */                               }
/*     */                               
/* 468 */                               ??? = GameManager.noTeam.iterator(); continue;Player allsn = (Player)???.next();
/* 469 */                               if (allsn.getName().equalsIgnoreCase(all.getName())) {
/* 470 */                                 all.sendMessage("§2[§4TNT§6Wars§2]§d Das Spiel beginnt in " + ChatColor.YELLOW + Commands.this.lobbytime);
/* 471 */                                 all.setLevel(Commands.this.lobbytime);
/*     */                               }
/*     */                             }
/*     */                           }
/*     */                           
/*     */                           Object allb;
/*     */                           
/* 478 */                           if (Commands.this.lobbytime < 1)
/*     */                           {
/*     */                             int RndmTeam;
/*     */                             try {
/* 482 */                               while (GameManager.noTeam.size() > 0) {
/* 483 */                                 for (Player all1 : Bukkit.getOnlinePlayers()) {
/* 484 */                                   if (GameManager.noTeam.contains(all1))
/*     */                                   {
/*     */ 
/* 487 */                                     if (GameManager.rot.size() > GameManager.blau.size()) {
/* 488 */                                       GameManager.blau.add(all1);
/* 489 */                                       GameManager.noTeam.remove(all1);
/* 490 */                                       GameManager.rot.remove(all1);
/*     */                                     }
/* 492 */                                     else if (GameManager.blau.size() > GameManager.rot.size()) {
/* 493 */                                       GameManager.rot.add(all1);
/* 494 */                                       GameManager.noTeam.remove(all1);
/* 495 */                                       GameManager.blau.remove(all1);
/*     */                                     }
/* 497 */                                     else if (GameManager.rot.size() == GameManager.blau.size()) {
/* 498 */                                       RndmTeam = new java.util.Random().nextInt(2);
/* 499 */                                       if (RndmTeam == 1) {
/* 500 */                                         GameManager.blau.add(all1);
/* 501 */                                         GameManager.noTeam.remove(all1);
/* 502 */                                         GameManager.rot.remove(all1);
/*     */                                       }
/*     */                                       
/* 505 */                                       if (RndmTeam == 0) {
/* 506 */                                         GameManager.rot.add(all1);
/* 507 */                                         GameManager.noTeam.remove(all1);
/* 508 */                                         GameManager.blau.remove(all1);
/*     */                                       }
/*     */                                     }
/*     */                                   }
/*     */                                 }
/*     */                               }
/*     */                             }
/*     */                             catch (Exception localException) {}
/*     */                             
/*     */ 
/*     */ 
/* 519 */                             if ((GameManager.rot.size() > 0) && (GameManager.blau.size() > 0))
/*     */                             {
/*     */ 
/* 522 */                               final GameManager GM = new GameManager(Commands.this.plugin);
/* 523 */                               GM.startSpawners(locred.getWorld().getName());
/*     */                               Iterator localIterator4;
/*     */                               try {
/* 526 */                                 for (RndmTeam = Bukkit.getServer().getOnlinePlayers().iterator(); RndmTeam.hasNext(); 
/*     */                                     
/* 528 */                                     localIterator4.hasNext())
/*     */                                 {
/* 526 */                                   Player allTeamsRot = (Player)RndmTeam.next();
/*     */                                   
/* 528 */                                   localIterator4 = GameManager.rot.iterator(); continue;Player allr = (Player)localIterator4.next();
/* 529 */                                   if (allr.getName().equalsIgnoreCase(allTeamsRot.getName()))
/*     */                                   {
/*     */ 
/* 532 */                                     allTeamsRot.sendMessage("§2[§4TNT§6Wars§2]§d Das Spiel " + ChatColor.YELLOW + "BEGINNT!");
/* 533 */                                     allTeamsRot.teleport(locred);
/* 534 */                                     GameManager.rot.remove(allTeamsRot);
/*     */                                     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 542 */                                     allTeamsRot.sendMessage("§2[§4TNT§6Wars§2]§d Dieses Spiel ist noch in der " + ChatColor.RED + 
/* 543 */                                       "BETHAPHASE! " + ChatColor.LIGHT_PURPLE + "Bitte habe dafür verständnis! Bei " + 
/* 544 */                                       "Vorschlägen / Verbesserungen bitte bei " + ChatColor.GREEN + "Mr_Coding " + 
/* 545 */                                       ChatColor.LIGHT_PURPLE + "melden!");
/* 546 */                                     allTeamsRot.sendMessage("§2[§4TNT§6Wars§2]§d Map build by: " + ChatColor.GOLD + Commands.this.plugin.getConfig().getString(new StringBuilder("GameWorld.").append(world.getName()).append(".Builder").toString()));
/*     */                                     
/* 548 */                                     allTeamsRot.getInventory().clear();
/*     */                                     
/* 550 */                                     allTeamsRot.setGameMode(GameMode.ADVENTURE);
/*     */                                     
/*     */ 
/* 553 */                                     me.Mr_Coding.tntwars.items.GranadeThrower.Common(allTeamsRot, 0, 1);
/* 554 */                                     me.Mr_Coding.tntwars.items.Granate.Granade(allTeamsRot, 1, 1);
/* 555 */                                     TNTCanon.TNTCanon(allTeamsRot, 2, 1);
/* 556 */                                     me.Mr_Coding.tntwars.items.TNTMissle.Cruiser(allTeamsRot, 3, 10);
/*     */                                   }
/*     */                                 }
/*     */                               }
/*     */                               catch (Exception localException3) {}
/*     */                               
/*     */ 
/*     */ 
/*     */                               try
/*     */                               {
/* 566 */                                 for (RndmTeam = Commands.this.plugin.getServer().getOnlinePlayers().iterator(); RndmTeam.hasNext(); 
/*     */                                     
/*     */ 
/* 569 */                                     localIterator4.hasNext())
/*     */                                 {
/* 566 */                                   Player allTeamsBlau = (Player)RndmTeam.next();
/*     */                                   
/*     */ 
/* 569 */                                   localIterator4 = GameManager.blau.iterator(); continue;allb = (Player)localIterator4.next();
/* 570 */                                   if (((Player)allb).getName().equalsIgnoreCase(allTeamsBlau.getName()))
/*     */                                   {
/*     */ 
/* 573 */                                     allTeamsBlau.sendMessage("§2[§4TNT§6Wars§2]§d Das Spiel " + ChatColor.YELLOW + "BEGINNT!");
/* 574 */                                     allTeamsBlau.teleport(locblue);
/* 575 */                                     GameManager.blau.remove(allTeamsBlau.getName());
/*     */                                     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 583 */                                     allTeamsBlau.sendMessage("§2[§4TNT§6Wars§2]§d Dieses Spiel ist noch in der " + ChatColor.RED + 
/* 584 */                                       "BETHAPHASE! " + ChatColor.LIGHT_PURPLE + "Bitte habe dafür verständnis! Bei " + 
/* 585 */                                       "Vorschlägen / Verbesserungen bitte bei " + ChatColor.GREEN + "Mr_Coding " + 
/* 586 */                                       ChatColor.LIGHT_PURPLE + "melden!");
/* 587 */                                     allTeamsBlau.sendMessage("§2[§4TNT§6Wars§2]§d Map build by: " + ChatColor.GOLD + Commands.this.plugin.getConfig().getString(new StringBuilder("GameWorld.").append(world.getName()).append(".Builder").toString()));
/*     */                                     
/* 589 */                                     allTeamsBlau.getInventory().clear();
/*     */                                     
/* 591 */                                     allTeamsBlau.setGameMode(GameMode.ADVENTURE);
/*     */                                     
/*     */ 
/* 594 */                                     me.Mr_Coding.tntwars.items.GranadeThrower.Common(allTeamsBlau, 0, 1);
/* 595 */                                     me.Mr_Coding.tntwars.items.Granate.Granade(allTeamsBlau, 1, 1);
/* 596 */                                     TNTCanon.TNTCanon(allTeamsBlau, 2, 1);
/* 597 */                                     me.Mr_Coding.tntwars.items.TNTMissle.Cruiser(allTeamsBlau, 3, 10);
/*     */                                   }
/*     */                                 }
/*     */                               }
/*     */                               catch (Exception localException4) {}
/*     */                               
/*     */ 
/*     */ 
/* 605 */                               Commands.this.lobbytime = 31;
/*     */                               
/*     */ 
/* 608 */                               Bukkit.getScheduler().cancelTask(Commands.this.Schedjoin);
/*     */                               
/*     */ 
/*     */ 
/* 612 */                               Commands.this.SchedReset = Bukkit.getScheduler().scheduleSyncRepeatingTask(Commands.this.plugin, new Runnable()
/*     */                               {
/*     */ 
/* 615 */                                 int Timer = 900;
/*     */                                 
/*     */ 
/*     */ 
/*     */                                 public void run()
/*     */                                 {
/* 621 */                                   this.Timer -= 1;
/* 622 */                                   if (this.Timer < 1) {
/* 623 */                                     Bukkit.getScheduler().cancelTask(Commands.this.SchedReset);
/* 624 */                                     Iterator localIterator2; for (Iterator localIterator1 = Bukkit.getWorlds().iterator(); localIterator1.hasNext(); 
/* 625 */                                         localIterator2.hasNext())
/*     */                                     {
/* 624 */                                       World world = (World)localIterator1.next();
/* 625 */                                       localIterator2 = Bukkit.getOnlinePlayers().iterator(); continue;Player all = (Player)localIterator2.next();
/* 626 */                                       if (all.getWorld().getName().equalsIgnoreCase(world.getName())) {
/* 627 */                                         all.sendMessage("§dDie Runde ist §cvorbei!");
/*     */                                         
/* 629 */                                         GM.stopSpawners(world.getName());
/*     */                                       }
/*     */                                     }
/*     */                                     
/*     */ 
/*     */                                     try
/*     */                                     {
/* 636 */                                       Map_Reset MR = new Map_Reset(Commands.this.plugin);
/* 637 */                                       World worldres = MR.resetMap(new File("TNTWarsReset"), new File("TNTWars"), "TNTWars");
/*     */                                       
/* 639 */                                       for (Player all : Bukkit.getOnlinePlayers()) {
/* 640 */                                         all.teleport(worldres.getSpawnLocation());
/*     */                                       }
/*     */                                     }
/*     */                                     catch (IOException e)
/*     */                                     {
/* 645 */                                       e.printStackTrace();
/*     */                                     }
/*     */                                     
/*     */ 
/* 649 */                                     return;
/*     */                                   }
/*     */                                   
/*     */                                 }
/*     */                                 
/* 654 */                               }, 0L, 20L);
/*     */ 
/*     */ 
/*     */                             }
/*     */                             else
/*     */                             {
/*     */ 
/* 661 */                               for (Player all : Bukkit.getOnlinePlayers())
/*     */                               {
/*     */ 
/* 664 */                                 for (allb = GameManager.rot.iterator(); ((Iterator)allb).hasNext();) { Player allr = (Player)((Iterator)allb).next();
/* 665 */                                   if (all.getName().equalsIgnoreCase(allr.getName())) {
/* 666 */                                     all.sendMessage("§2[§4TNT§6Wars§2]§d Es sind " + ChatColor.YELLOW + "zu WENIG " + ChatColor.LIGHT_PURPLE + "in der Runde!" + 
/* 667 */                                       " --> Neustart!");
/*     */                                   }
/*     */                                 }
/*     */                                 
/*     */ 
/* 672 */                                 for (allb = GameManager.blau.iterator(); ((Iterator)allb).hasNext();) { Player allb = (Player)((Iterator)allb).next();
/* 673 */                                   if (all.getName().equalsIgnoreCase(allb.getName())) {
/* 674 */                                     all.sendMessage("§2[§4TNT§6Wars§2]§d Es sind " + ChatColor.YELLOW + "zu WENIG " + ChatColor.LIGHT_PURPLE + "in der Runde!" + 
/* 675 */                                       " --> Neustart!");
/*     */                                   }
/*     */                                 }
/*     */                                 
/*     */ 
/* 680 */                                 for (allb = GameManager.noTeam.iterator(); ((Iterator)allb).hasNext();) { Player allr = (Player)((Iterator)allb).next();
/* 681 */                                   if (all.getName().equalsIgnoreCase(allr.getName())) {
/* 682 */                                     all.sendMessage("§2[§4TNT§6Wars§2]§d Es sind " + ChatColor.YELLOW + "zu WENIG " + ChatColor.LIGHT_PURPLE + "in der Runde!" + 
/* 683 */                                       " --> Neustart!");
/*     */                                   }
/*     */                                 }
/*     */                                 
/* 687 */                                 Commands.this.lobbytime = 31;
/*     */                               }
/*     */                               
/*     */                             }
/*     */                           }
/*     */                           else
/*     */                           {
/* 694 */                             for (localException2 = Commands.this.plugin.getServer().getOnlinePlayers().iterator(); localException2.hasNext(); 
/*     */                                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 708 */                                 ((Iterator)allb).hasNext())
/*     */                             {
/* 694 */                               Player all = (Player)localException2.next();
/*     */                               
/* 696 */                               for (allb = GameManager.rot.iterator(); ((Iterator)allb).hasNext();) { Player allsr = (Player)((Iterator)allb).next();
/* 697 */                                 if (allsr.getName().equalsIgnoreCase(all.getName())) {
/* 698 */                                   all.setLevel(Commands.this.lobbytime);
/*     */                                 }
/*     */                               }
/*     */                               
/* 702 */                               for (allb = GameManager.blau.iterator(); ((Iterator)allb).hasNext();) { Player allsb = (Player)((Iterator)allb).next();
/* 703 */                                 if (allsb.getName().equalsIgnoreCase(all.getName())) {
/* 704 */                                   all.setLevel(Commands.this.lobbytime);
/*     */                                 }
/*     */                               }
/*     */                               
/* 708 */                               allb = GameManager.noTeam.iterator(); continue;Player allsn = (Player)((Iterator)allb).next();
/* 709 */                               if (allsn.getName().equalsIgnoreCase(all.getName())) {
/* 710 */                                 all.setLevel(Commands.this.lobbytime);
/*     */                               }
/*     */                             }
/*     */                             
/*     */ 
/*     */ 
/* 716 */                             Commands.this.lobbytime -= 1;
/*     */                           }
/*     */                           
/*     */                         }
/*     */                         
/* 721 */                       }, 0L, 20L);
/*     */                     } else {
/* 723 */                       Bukkit.getScheduler().cancelTask(this.Schedjoin);
/*     */                     }
/*     */                     
/*     */ 
/* 727 */                     this.joinforbreak = true;
/*     */                   } else {
/* 729 */                     p.sendMessage("§2[§4TNT§6Wars§2]§d Du " + ChatColor.YELLOW + "bist " + ChatColor.LIGHT_PURPLE + "bereits in einem Spiel!");
/* 730 */                     this.joinforbreak = true;
/*     */                   }
/*     */                 }
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 737 */               if (!this.joinforbreak) {
/* 738 */                 p.sendMessage("§2[§4TNT§6Wars§2]§d Dieses Spiel gibt es nicht!");
/*     */               } else {
/* 740 */                 this.joinforbreak = false;
/*     */               }
/*     */             } else {
/* 743 */               p.sendMessage("§2[§4TNT§6Wars§2]§d Bitte gebe ein " + ChatColor.GOLD + "Argument " + ChatColor.LIGHT_PURPLE + "an!");
/*     */             }
/*     */           } else {
/* 746 */             noPermission(p);
/* 747 */             return true;
/*     */           }
/* 749 */           return true;
/*     */         }
/*     */         
/*     */         Object getinvcontents;
/* 753 */         if ((args[0].equalsIgnoreCase("l")) || (args[0].equalsIgnoreCase("leave"))) {
/* 754 */           if (p.hasPermission("TNTWars.leave")) {
/* 755 */             if ((GameManager.rot.contains(p)) || 
/* 756 */               (GameManager.blau.contains(p)) || 
/* 757 */               (GameManager.noTeam.contains(p)))
/*     */             {
/* 759 */               GameManager.rot.remove(p);
/* 760 */               GameManager.blau.remove(p);
/* 761 */               GameManager.noTeam.remove(p);
/*     */               try {
/* 763 */                 if (!Location.containsKey(p)) break label5531;
/* 764 */                 Location loc = (Location)Location.get(p);
/* 765 */                 p.teleport(loc);
/* 766 */                 p.sendMessage("§2[§4TNT§6Wars§2]§d Du hast die Runde " + ChatColor.RED + "verlassen!");
/* 767 */                 getinvcontents = (ItemStack[])this.plugin.saveinventory.get(p.getName());
/*     */                 try {
/* 769 */                   p.getInventory().setContents((ItemStack[])getinvcontents);
/* 770 */                   return true;
/*     */                 } catch (Exception localException4) {
/* 772 */                   return true;
/*     */                 }
/*     */                 
/*     */ 
/* 776 */                 p.sendMessage("§2[§4TNT§6Wars§2]§d " + ChatColor.LIGHT_PURPLE + "Du bist in " + ChatColor.RED + "keiner " + ChatColor.LIGHT_PURPLE + "Runde!"); } catch (Exception localException5) {} }
/* 777 */             return true;
/*     */           }
/*     */           
/* 780 */           noPermission(p);
/* 781 */           return true;
/*     */         }
/*     */         
/*     */         label5531:
/* 785 */         if (args[0].equalsIgnoreCase("start")) {
/* 786 */           if (p.hasPermission("TNTWars.start")) {
/* 787 */             if ((GameManager.blau.contains(p)) || (GameManager.rot.contains(p)) || (GameManager.noTeam.contains(p))) {
/* 788 */               if (this.lobbytime > 10) {
/* 789 */                 this.lobbytime = 10;
/* 790 */                 return true;
/*     */               }
/* 792 */               return true;
/*     */             }
/*     */             
/* 795 */             p.sendMessage("§dDu bist in §ckeinem §dSpiel!");
/* 796 */             return true;
/*     */           }
/*     */           
/* 799 */           sender.sendMessage("§2[§4TNT§6Wars§2]§d " + ChatColor.RED + "Nicht genügend Rechte!");
/* 800 */           return true;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 805 */         if (args[0].equalsIgnoreCase("games")) {
/* 806 */           this.gameanzahl = 0;
/* 807 */           for (getinvcontents = this.plugin.getServer().getWorlds().iterator(); ((Iterator)getinvcontents).hasNext();) { World world = (World)((Iterator)getinvcontents).next();
/* 808 */             if (world.getName().equalsIgnoreCase(this.plugin.getConfig().getString("GameWorld.name" + world.getName()))) {
/* 809 */               this.gameanzahl += 1;
/*     */             }
/*     */           }
/* 812 */           if (this.gameanzahl == 1) {
/* 813 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Derzeit ist " + ChatColor.YELLOW + this.gameanzahl + ChatColor.LIGHT_PURPLE + " Spiel verfügbar!");
/*     */           } else {
/* 815 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Derzeit sind " + ChatColor.YELLOW + this.gameanzahl + ChatColor.LIGHT_PURPLE + " Spiele verfügbar!");
/*     */           }
/* 817 */           return true;
/*     */         }
/*     */         
/*     */ 
/* 821 */         if (args[0].equalsIgnoreCase("Shop")) {
/* 822 */           if (sender.hasPermission("TNTWars.Shop")) {
/* 823 */             if (args.length > 1) {
/* 824 */               org.bukkit.entity.Entity Ent = p.getWorld().spawnEntity(p.getLocation(), org.bukkit.entity.EntityType.CREEPER);
/* 825 */               Creeper Shop = (Creeper)Ent;
/* 826 */               if (args[1].equalsIgnoreCase("Rot")) {
/* 827 */                 Shop.setCustomName("§cShop");
/* 828 */               } else if (args[1].equalsIgnoreCase("Blau")) {
/* 829 */                 Shop.setCustomName("§1Shop");
/*     */               } else {
/* 831 */                 Shop.remove();
/* 832 */                 p.sendMessage("§2[§4TNT§6Wars§2]§d Unbekanntes §6Argument!");
/* 833 */                 return true;
/*     */               }
/* 835 */               Shop.setCustomNameVisible(true);
/* 836 */               Shop.setFallDistance(0.0F);
/* 837 */               ((LivingEntity)Ent).setRemoveWhenFarAway(false);
/* 838 */               Shop.setNoDamageTicks(Integer.MAX_VALUE);
/* 839 */               Shop.setCanPickupItems(false);
/* 840 */               Shop.setPowered(true);
/*     */               
/*     */ 
/* 843 */               p.sendMessage("§2[§4TNT§6Wars§2]§d Shop wurde erstellt!");
/* 844 */               return true;
/*     */             }
/* 846 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Zu wenig §6Argumente!");
/* 847 */             p.sendMessage("");
/* 848 */             p.sendMessage("§d/TNTWars §6Shop §eTeam §d(§cRot §d/ §1Blau§d)");
/* 849 */             return true;
/*     */           }
/*     */           
/* 852 */           noPermission(p);
/* 853 */           return true;
/*     */         }
/*     */         
/*     */ 
/* 857 */         p.sendMessage("§2[§4TNT§6Wars§2]§d Unbekanntest " + ChatColor.GOLD + "Argument!");
/* 858 */         return true;
/*     */       }
/* 860 */       Usage(sender);
/*     */       
/*     */ 
/* 863 */       if (sender.hasPermission("TNTWars.help"))
/*     */       {
/* 865 */         if ((args.length > 0) && 
/* 866 */           (args[0].equalsIgnoreCase("help"))) {
/* 867 */           Usage(sender);
/*     */         }
/*     */       }
/*     */       else {
/* 871 */         sender.sendMessage("§2[§4TNT§6Wars§2]§d Nicht genügend Rechte!");
/*     */       }
/* 873 */       return true;
/*     */     }
/* 875 */     noPlayer(sender);
/* 876 */     sender.sendMessage("§dVerfügbare §aArgumente:");
/* 877 */     sender.sendMessage("");
/* 878 */     sender.sendMessage("§dVersion");
/* 879 */     sender.sendMessage("§dBugs");
/* 880 */     sender.sendMessage("§dReload");
/* 881 */     sender.sendMessage("§dHelp");
/* 882 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void Usage(CommandSender sender)
/*     */   {
/* 891 */     sender.sendMessage("§2[§4TNT§6Wars§2]§d §3Alle Verfügbaren §aCommands:");
/* 892 */     sender.sendMessage("");
/*     */     
/* 894 */     if (sender.hasPermission("TNTWars.Version")) {
/* 895 */       sender.sendMessage("§dVersion       §eZeigt die aktuelle Version!");
/*     */     }
/*     */     
/* 898 */     if (sender.hasPermission("TNTWars.Bugs")) {
/* 899 */       sender.sendMessage("§dBugs          §eZeigt alle bekannten Bugs!");
/*     */     }
/*     */     
/* 902 */     if (sender.hasPermission("TNTWars.Reload")) {
/* 903 */       sender.sendMessage("§dReload        §eReloadet das Plugin");
/*     */     }
/* 905 */     sender.sendMessage("§dHelp");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 911 */     sender.sendMessage("");
/* 912 */     if (sender.hasPermission("TNTWars.setworldspawn")) {
/* 913 */       sender.sendMessage("§6setworldspawn §dsetze den Weltspawn für Team §cRot");
/* 914 */       sender.sendMessage("§d              oder für Team §1Blau!");
/*     */     }
/*     */     
/* 917 */     if (sender.hasPermission("TNTWars.join")) {
/* 918 */       sender.sendMessage("§6join          §djoine einer Runde!");
/*     */     }
/*     */     
/* 921 */     if (sender.hasPermission("TNTWars.setLobby")) {
/* 922 */       sender.sendMessage("§6setLobby      §dsetze die Lobby für ein Spiel!");
/*     */     }
/*     */     
/* 925 */     if (sender.hasPermission("TNTWars.leave")) {
/* 926 */       sender.sendMessage("§6leave         §dverlasse ein Spiel!");
/*     */     }
/*     */     
/* 929 */     if (sender.hasPermission("TNTWars.setBuilder")) {
/* 930 */       sender.sendMessage("§6setBuilder    §dsetze den / die Builder der Map!");
/*     */     }
/*     */     
/* 933 */     if (sender.hasPermission("TNTWars.Shop")) {
/* 934 */       sender.sendMessage("§6Shop          §derstelle einen Shop!");
/*     */     }
/*     */     
/* 937 */     if (sender.hasPermission("TNTWars.Reset")) {
/* 938 */       sender.sendMessage("§6Reset         §dResete Die Welt!");
/*     */     }
/*     */     
/* 941 */     if (sender.hasPermission("TNTWars.Spawner")) {
/* 942 */       sender.sendMessage("§6Spawner       §dSetze Spawner!");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void noPlayer(CommandSender sender)
/*     */   {
/* 949 */     sender.sendMessage("§2[§4TNT§6Wars§2]§d Du bist §ckein §dSpieler!");
/*     */   }
/*     */   
/*     */   public static void currentBugs(CommandSender sender)
/*     */   {
/* 954 */     sender.sendMessage("§2[§4TNT§6Wars§2]§d Listing all Bugs...");
/* 955 */     sender.sendMessage("");
/* 956 */     sender.sendMessage("§cSpawner set        §a| §6Sometimes you have to add the World in");
/* 957 */     sender.sendMessage("                         §6the Config.yml!");
/* 958 */     sender.sendMessage("§cTNTCanon           §a| §6Only working a §3\"bit\" §6in the northern");
/* 959 */     sender.sendMessage("                         §6Direction");
/*     */   }
/*     */   
/*     */   private void noPermission(CommandSender sender) {
/* 963 */     sender.sendMessage("§2[§4TNT§6Wars§2]§d §cNicht genügend Rechte!");
/*     */   }
/*     */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\Commands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */