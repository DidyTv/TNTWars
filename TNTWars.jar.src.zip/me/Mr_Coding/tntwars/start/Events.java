/*    */ package me.Mr_Coding.tntwars.start;
/*    */ 
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ 
/*    */ public class Events implements org.bukkit.event.Listener
/*    */ {
/*    */   private Plugin plugin;
/*    */   
/*    */   public Events(start main)
/*    */   {
/* 12 */     this.plugin = main;
/* 13 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*    */   }
/*    */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\Events.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */