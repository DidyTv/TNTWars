/*    */ package me.Mr_Coding.tntwars.start;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import me.Mr_Coding.tntwars.items.GranadeThrower;
/*    */ import me.Mr_Coding.tntwars.items.Granate;
/*    */ import me.Mr_Coding.tntwars.items.TNTCanon;
/*    */ import me.Mr_Coding.tntwars.items.TNTMissle;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.command.ConsoleCommandSender;
/*    */ import org.bukkit.command.PluginCommand;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.configuration.file.FileConfigurationOptions;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class start
/*    */   extends JavaPlugin
/*    */ {
/*    */   static final String consoleprefix = "[TNTWars] ";
/*    */   public static final String prefix = "§2[§4TNT§6Wars§2]§d ";
/* 25 */   public Inventory invTeams = Bukkit.createInventory(null, 9, ChatColor.GREEN + "Team wählen");
/*    */   
/* 27 */   HashMap<String, ItemStack[]> saveinventory = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */   public void onEnable()
/*    */   {
/* 33 */     reloadConfig();
/* 34 */     loadConfig();
/* 35 */     registerCommands();
/* 36 */     registerEvents();
/* 37 */     Bukkit.getConsoleSender().sendMessage("§2[§4TNT§6Wars§2]§d geladen");
/*    */   }
/*    */   
/*    */   public void onDisable() {
/* 41 */     Bukkit.getConsoleSender().sendMessage("§2[§4TNT§6Wars§2]§d entladen");
/*    */   }
/*    */   
/*    */   public void loadConfig() {
/* 45 */     FileConfiguration fcg = getConfig();
/* 46 */     fcg.options().copyDefaults(true);
/* 47 */     saveConfig();
/*    */   }
/*    */   
/*    */   public void registerCommands() {
/* 51 */     Commands cCommands = new Commands(this);
/* 52 */     getCommand("tntwars").setExecutor(cCommands);
/*    */   }
/*    */   
/*    */   public void registerEvents() {
/* 56 */     new Shop(this);
/* 57 */     new SchildEvent(this);
/* 58 */     new CompassEvent(this);
/* 59 */     new TeamEvent(this);
/* 60 */     new GameManager(this);
/* 61 */     new GranadeThrower(this);
/* 62 */     new Granate(this);
/* 63 */     new Events(this);
/* 64 */     new TNTCanon(this);
/* 65 */     new HimmelsRichtung(this);
/* 66 */     new TNTMissle(this);
/* 67 */     new Map_Reset(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\start.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */