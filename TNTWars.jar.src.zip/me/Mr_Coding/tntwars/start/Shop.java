/*     */ package me.Mr_Coding.tntwars.start;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import me.Mr_Coding.tntwars.items.GranadeThrower;
/*     */ import me.Mr_Coding.tntwars.items.Granate;
/*     */ import me.Mr_Coding.tntwars.items.TNTMissle;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Creeper;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.EntityExplodeEvent;
/*     */ import org.bukkit.event.entity.EntityTargetEvent;
/*     */ import org.bukkit.event.entity.ExplosionPrimeEvent;
/*     */ import org.bukkit.event.inventory.ClickType;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ 
/*     */ public class Shop implements org.bukkit.event.Listener
/*     */ {
/*     */   private Plugin plugin;
/*     */   
/*     */   public Shop(start start)
/*     */   {
/*  37 */     this.plugin = start;
/*  38 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*  39 */     defineShops();
/*     */   }
/*     */   
/*     */   private void notenoughLevel(Player p) {
/*  43 */     p.sendMessage("§2[§4TNT§6Wars§2]§d §cDu hast zu wenig §aLevel");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void defineShops()
/*     */   {
/*  50 */     ItemStack ISS_G_P = new ItemStack(Material.STAINED_GLASS_PANE);
/*  51 */     ItemStack ISMissle = new ItemStack(Material.MONSTER_EGG);
/*  52 */     ItemStack ISMissles = new ItemStack(Material.MONSTER_EGG);
/*  53 */     ItemStack ISGranade = new ItemStack(Material.FIREWORK_CHARGE);
/*  54 */     ItemStack ISGranades = new ItemStack(Material.CLAY_BALL);
/*  55 */     ItemStack ISGranadeThrs = new ItemStack(Material.DIAMOND_SWORD);
/*  56 */     ItemStack ISGranadeThr = new ItemStack(Material.DIAMOND_SWORD);
/*  57 */     ItemStack ISBows = new ItemStack(Material.BOW);
/*  58 */     ItemStack ISNormal_Bow = new ItemStack(Material.BOW);
/*  59 */     ItemStack ISFire_Bow = new ItemStack(Material.BOW);
/*     */     
/*     */ 
/*  62 */     ItemStack ISExit = new ItemStack(Material.BARRIER);
/*  63 */     ItemStack ISBack = new ItemStack(Material.BARRIER);
/*     */     
/*     */ 
/*     */ 
/*  67 */     ISS_G_P.setDurability((short)7);
/*  68 */     ISMissle.setDurability((short)93);
/*     */     
/*     */ 
/*     */ 
/*  72 */     ItemMeta IMS_G_P = ISS_G_P.getItemMeta();
/*  73 */     ItemMeta IMMissles = ISMissles.getItemMeta();
/*  74 */     ItemMeta IMMissle = ISMissle.getItemMeta();
/*  75 */     ItemMeta IMGranade = ISGranade.getItemMeta();
/*  76 */     ItemMeta IMGranades = ISGranades.getItemMeta();
/*  77 */     ItemMeta IMGranadeThrs = ISGranadeThrs.getItemMeta();
/*  78 */     ItemMeta IMGranadeThr = ISGranadeThr.getItemMeta();
/*  79 */     ItemMeta IMBows = ISBows.getItemMeta();
/*  80 */     ItemMeta IMNormal_Bow = ISNormal_Bow.getItemMeta();
/*  81 */     ItemMeta IMFire_Bow = ISFire_Bow.getItemMeta();
/*     */     
/*     */ 
/*  84 */     ItemMeta IMExit = ISExit.getItemMeta();
/*  85 */     ItemMeta IMBack = ISBack.getItemMeta();
/*     */     
/*     */ 
/*     */ 
/*  89 */     IMS_G_P.setDisplayName("§8");
/*  90 */     IMMissles.setDisplayName("§6Missles");
/*  91 */     IMMissle.setDisplayName("§6TNT Cruiser");
/*  92 */     IMGranades.setDisplayName("§6Granaten");
/*  93 */     IMGranade.setDisplayName("§6Normale Granate");
/*  94 */     IMGranadeThrs.setDisplayName("§6Granat-Werfer");
/*  95 */     IMGranadeThr.setDisplayName("§6Normaler Granatwerfer");
/*  96 */     IMBows.setDisplayName("§6Bögen");
/*  97 */     IMNormal_Bow.setDisplayName("§6Normaler Bogen");
/*  98 */     IMFire_Bow.setDisplayName("§6Feuer Bogen");
/*     */     
/* 100 */     IMExit.setDisplayName("§cEXIT");
/* 101 */     IMBack.setDisplayName("§cBACK");
/*     */     
/*     */ 
/*     */ 
/* 105 */     ArrayList<String> MissleCruiser = new ArrayList();
/* 106 */     ArrayList<String> IMGranadeNormal = new ArrayList();
/* 107 */     ArrayList<String> LoreGranadeThr = new ArrayList();
/*     */     
/*     */ 
/*     */ 
/* 111 */     MissleCruiser.add("§a5 Level");
/* 112 */     IMGranadeNormal.add("§a2 Level");
/* 113 */     LoreGranadeThr.add("§a4 Level");
/*     */     
/*     */ 
/*     */ 
/* 117 */     IMMissle.setLore(MissleCruiser);
/* 118 */     IMGranade.setLore(IMGranadeNormal);
/* 119 */     IMGranadeThr.setLore(LoreGranadeThr);
/*     */     
/*     */ 
/*     */ 
/* 123 */     IMExit.addEnchant(Enchantment.ARROW_DAMAGE, 0, false);
/* 124 */     IMBack.addEnchant(Enchantment.ARROW_DAMAGE, 0, false);
/*     */     
/*     */ 
/*     */ 
/* 128 */     ISS_G_P.setItemMeta(IMS_G_P);
/* 129 */     ISMissles.setItemMeta(IMMissles);
/* 130 */     ISMissle.setItemMeta(IMMissle);
/* 131 */     ISGranade.setItemMeta(IMGranade);
/* 132 */     ISGranades.setItemMeta(IMGranades);
/* 133 */     ISGranadeThrs.setItemMeta(IMGranadeThrs);
/* 134 */     ISGranadeThr.setItemMeta(IMGranadeThr);
/*     */     
/* 136 */     ISExit.setItemMeta(IMExit);
/* 137 */     ISBack.setItemMeta(IMBack);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */     this.invShopRot.setItem(0, ISS_G_P);
/* 150 */     this.invShopRot.setItem(1, ISS_G_P);
/* 151 */     this.invShopRot.setItem(2, ISS_G_P);
/* 152 */     this.invShopRot.setItem(3, ISS_G_P);
/* 153 */     this.invShopRot.setItem(4, ISS_G_P);
/* 154 */     this.invShopRot.setItem(5, ISS_G_P);
/* 155 */     this.invShopRot.setItem(6, ISS_G_P);
/* 156 */     this.invShopRot.setItem(7, ISS_G_P);
/* 157 */     this.invShopRot.setItem(8, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/* 161 */     this.invShopRot.setItem(9, ISMissles);
/* 162 */     this.invShopRot.setItem(10, ISGranades);
/* 163 */     this.invShopRot.setItem(11, ISGranadeThrs);
/*     */     
/* 165 */     this.invShopRot.setItem(17, ISExit);
/*     */     
/*     */ 
/*     */ 
/* 169 */     this.invShopRot.setItem(18, ISS_G_P);
/* 170 */     this.invShopRot.setItem(19, ISS_G_P);
/* 171 */     this.invShopRot.setItem(20, ISS_G_P);
/* 172 */     this.invShopRot.setItem(21, ISS_G_P);
/* 173 */     this.invShopRot.setItem(22, ISS_G_P);
/* 174 */     this.invShopRot.setItem(23, ISS_G_P);
/* 175 */     this.invShopRot.setItem(24, ISS_G_P);
/* 176 */     this.invShopRot.setItem(25, ISS_G_P);
/* 177 */     this.invShopRot.setItem(26, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */     this.invShopBlau.setItem(0, ISS_G_P);
/* 185 */     this.invShopBlau.setItem(1, ISS_G_P);
/* 186 */     this.invShopBlau.setItem(2, ISS_G_P);
/* 187 */     this.invShopBlau.setItem(3, ISS_G_P);
/* 188 */     this.invShopBlau.setItem(4, ISS_G_P);
/* 189 */     this.invShopBlau.setItem(5, ISS_G_P);
/* 190 */     this.invShopBlau.setItem(6, ISS_G_P);
/* 191 */     this.invShopBlau.setItem(7, ISS_G_P);
/* 192 */     this.invShopBlau.setItem(8, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/* 196 */     this.invShopBlau.setItem(9, ISMissles);
/* 197 */     this.invShopBlau.setItem(10, ISGranades);
/* 198 */     this.invShopBlau.setItem(11, ISGranadeThrs);
/*     */     
/* 200 */     this.invShopBlau.setItem(17, ISExit);
/*     */     
/*     */ 
/*     */ 
/* 204 */     this.invShopBlau.setItem(18, ISS_G_P);
/* 205 */     this.invShopBlau.setItem(19, ISS_G_P);
/* 206 */     this.invShopBlau.setItem(20, ISS_G_P);
/* 207 */     this.invShopBlau.setItem(21, ISS_G_P);
/* 208 */     this.invShopBlau.setItem(22, ISS_G_P);
/* 209 */     this.invShopBlau.setItem(23, ISS_G_P);
/* 210 */     this.invShopBlau.setItem(24, ISS_G_P);
/* 211 */     this.invShopBlau.setItem(25, ISS_G_P);
/* 212 */     this.invShopBlau.setItem(26, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */     this.invShopMisslesRot.setItem(0, ISS_G_P);
/* 220 */     this.invShopMisslesRot.setItem(1, ISS_G_P);
/* 221 */     this.invShopMisslesRot.setItem(2, ISS_G_P);
/* 222 */     this.invShopMisslesRot.setItem(3, ISS_G_P);
/* 223 */     this.invShopMisslesRot.setItem(4, ISS_G_P);
/* 224 */     this.invShopMisslesRot.setItem(5, ISS_G_P);
/* 225 */     this.invShopMisslesRot.setItem(6, ISS_G_P);
/* 226 */     this.invShopMisslesRot.setItem(7, ISS_G_P);
/* 227 */     this.invShopMisslesRot.setItem(8, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/* 231 */     this.invShopMisslesRot.setItem(9, ISMissle);
/*     */     
/* 233 */     this.invShopMisslesRot.setItem(17, ISBack);
/*     */     
/*     */ 
/*     */ 
/* 237 */     this.invShopMisslesRot.setItem(18, ISS_G_P);
/* 238 */     this.invShopMisslesRot.setItem(19, ISS_G_P);
/* 239 */     this.invShopMisslesRot.setItem(20, ISS_G_P);
/* 240 */     this.invShopMisslesRot.setItem(21, ISS_G_P);
/* 241 */     this.invShopMisslesRot.setItem(22, ISS_G_P);
/* 242 */     this.invShopMisslesRot.setItem(23, ISS_G_P);
/* 243 */     this.invShopMisslesRot.setItem(24, ISS_G_P);
/* 244 */     this.invShopMisslesRot.setItem(25, ISS_G_P);
/* 245 */     this.invShopMisslesRot.setItem(26, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 252 */     this.invShopMisslesBlau.setItem(0, ISS_G_P);
/* 253 */     this.invShopMisslesBlau.setItem(1, ISS_G_P);
/* 254 */     this.invShopMisslesBlau.setItem(2, ISS_G_P);
/* 255 */     this.invShopMisslesBlau.setItem(3, ISS_G_P);
/* 256 */     this.invShopMisslesBlau.setItem(4, ISS_G_P);
/* 257 */     this.invShopMisslesBlau.setItem(5, ISS_G_P);
/* 258 */     this.invShopMisslesBlau.setItem(6, ISS_G_P);
/* 259 */     this.invShopMisslesBlau.setItem(7, ISS_G_P);
/* 260 */     this.invShopMisslesBlau.setItem(8, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/* 264 */     this.invShopMisslesBlau.setItem(9, ISMissle);
/*     */     
/* 266 */     this.invShopMisslesBlau.setItem(17, ISBack);
/*     */     
/*     */ 
/* 269 */     this.invShopMisslesBlau.setItem(18, ISS_G_P);
/* 270 */     this.invShopMisslesBlau.setItem(19, ISS_G_P);
/* 271 */     this.invShopMisslesBlau.setItem(20, ISS_G_P);
/* 272 */     this.invShopMisslesBlau.setItem(21, ISS_G_P);
/* 273 */     this.invShopMisslesBlau.setItem(22, ISS_G_P);
/* 274 */     this.invShopMisslesBlau.setItem(23, ISS_G_P);
/* 275 */     this.invShopMisslesBlau.setItem(24, ISS_G_P);
/* 276 */     this.invShopMisslesBlau.setItem(25, ISS_G_P);
/* 277 */     this.invShopMisslesBlau.setItem(26, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 284 */     this.invShopGranadesRot.setItem(0, ISS_G_P);
/* 285 */     this.invShopGranadesRot.setItem(1, ISS_G_P);
/* 286 */     this.invShopGranadesRot.setItem(2, ISS_G_P);
/* 287 */     this.invShopGranadesRot.setItem(3, ISS_G_P);
/* 288 */     this.invShopGranadesRot.setItem(4, ISS_G_P);
/* 289 */     this.invShopGranadesRot.setItem(5, ISS_G_P);
/* 290 */     this.invShopGranadesRot.setItem(6, ISS_G_P);
/* 291 */     this.invShopGranadesRot.setItem(7, ISS_G_P);
/* 292 */     this.invShopGranadesRot.setItem(8, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/* 296 */     this.invShopGranadesRot.setItem(9, ISGranade);
/*     */     
/* 298 */     this.invShopGranadesRot.setItem(17, ISBack);
/*     */     
/*     */ 
/*     */ 
/* 302 */     this.invShopGranadesRot.setItem(18, ISS_G_P);
/* 303 */     this.invShopGranadesRot.setItem(19, ISS_G_P);
/* 304 */     this.invShopGranadesRot.setItem(20, ISS_G_P);
/* 305 */     this.invShopGranadesRot.setItem(21, ISS_G_P);
/* 306 */     this.invShopGranadesRot.setItem(22, ISS_G_P);
/* 307 */     this.invShopGranadesRot.setItem(23, ISS_G_P);
/* 308 */     this.invShopGranadesRot.setItem(24, ISS_G_P);
/* 309 */     this.invShopGranadesRot.setItem(25, ISS_G_P);
/* 310 */     this.invShopGranadesRot.setItem(26, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 317 */     this.invShopGranadesBlau.setItem(0, ISS_G_P);
/* 318 */     this.invShopGranadesBlau.setItem(1, ISS_G_P);
/* 319 */     this.invShopGranadesBlau.setItem(2, ISS_G_P);
/* 320 */     this.invShopGranadesBlau.setItem(3, ISS_G_P);
/* 321 */     this.invShopGranadesBlau.setItem(4, ISS_G_P);
/* 322 */     this.invShopGranadesBlau.setItem(5, ISS_G_P);
/* 323 */     this.invShopGranadesBlau.setItem(6, ISS_G_P);
/* 324 */     this.invShopGranadesBlau.setItem(7, ISS_G_P);
/* 325 */     this.invShopGranadesBlau.setItem(8, ISS_G_P);
/*     */     
/*     */ 
/* 328 */     this.invShopGranadesBlau.setItem(9, ISGranade);
/*     */     
/* 330 */     this.invShopGranadesBlau.setItem(17, ISBack);
/*     */     
/*     */ 
/*     */ 
/* 334 */     this.invShopGranadesBlau.setItem(18, ISS_G_P);
/* 335 */     this.invShopGranadesBlau.setItem(19, ISS_G_P);
/* 336 */     this.invShopGranadesBlau.setItem(20, ISS_G_P);
/* 337 */     this.invShopGranadesBlau.setItem(21, ISS_G_P);
/* 338 */     this.invShopGranadesBlau.setItem(22, ISS_G_P);
/* 339 */     this.invShopGranadesBlau.setItem(23, ISS_G_P);
/* 340 */     this.invShopGranadesBlau.setItem(24, ISS_G_P);
/* 341 */     this.invShopGranadesBlau.setItem(25, ISS_G_P);
/* 342 */     this.invShopGranadesBlau.setItem(26, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 349 */     this.invShopGranadeThrRot.setItem(0, ISS_G_P);
/* 350 */     this.invShopGranadeThrRot.setItem(1, ISS_G_P);
/* 351 */     this.invShopGranadeThrRot.setItem(2, ISS_G_P);
/* 352 */     this.invShopGranadeThrRot.setItem(3, ISS_G_P);
/* 353 */     this.invShopGranadeThrRot.setItem(4, ISS_G_P);
/* 354 */     this.invShopGranadeThrRot.setItem(5, ISS_G_P);
/* 355 */     this.invShopGranadeThrRot.setItem(6, ISS_G_P);
/* 356 */     this.invShopGranadeThrRot.setItem(7, ISS_G_P);
/* 357 */     this.invShopGranadeThrRot.setItem(8, ISS_G_P);
/*     */     
/*     */ 
/* 360 */     this.invShopGranadeThrRot.setItem(9, ISGranadeThr);
/*     */     
/* 362 */     this.invShopGranadeThrRot.setItem(17, ISBack);
/*     */     
/*     */ 
/*     */ 
/* 366 */     this.invShopGranadeThrRot.setItem(18, ISS_G_P);
/* 367 */     this.invShopGranadeThrRot.setItem(19, ISS_G_P);
/* 368 */     this.invShopGranadeThrRot.setItem(20, ISS_G_P);
/* 369 */     this.invShopGranadeThrRot.setItem(21, ISS_G_P);
/* 370 */     this.invShopGranadeThrRot.setItem(22, ISS_G_P);
/* 371 */     this.invShopGranadeThrRot.setItem(23, ISS_G_P);
/* 372 */     this.invShopGranadeThrRot.setItem(24, ISS_G_P);
/* 373 */     this.invShopGranadeThrRot.setItem(25, ISS_G_P);
/* 374 */     this.invShopGranadeThrRot.setItem(26, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 381 */     this.invShopGranadeThrBlau.setItem(0, ISS_G_P);
/* 382 */     this.invShopGranadeThrBlau.setItem(1, ISS_G_P);
/* 383 */     this.invShopGranadeThrBlau.setItem(2, ISS_G_P);
/* 384 */     this.invShopGranadeThrBlau.setItem(3, ISS_G_P);
/* 385 */     this.invShopGranadeThrBlau.setItem(4, ISS_G_P);
/* 386 */     this.invShopGranadeThrBlau.setItem(5, ISS_G_P);
/* 387 */     this.invShopGranadeThrBlau.setItem(6, ISS_G_P);
/* 388 */     this.invShopGranadeThrBlau.setItem(7, ISS_G_P);
/* 389 */     this.invShopGranadeThrBlau.setItem(8, ISS_G_P);
/*     */     
/*     */ 
/* 392 */     this.invShopGranadeThrBlau.setItem(9, ISGranadeThr);
/*     */     
/* 394 */     this.invShopGranadeThrBlau.setItem(17, ISBack);
/*     */     
/*     */ 
/*     */ 
/* 398 */     this.invShopGranadeThrBlau.setItem(18, ISS_G_P);
/* 399 */     this.invShopGranadeThrBlau.setItem(19, ISS_G_P);
/* 400 */     this.invShopGranadeThrBlau.setItem(20, ISS_G_P);
/* 401 */     this.invShopGranadeThrBlau.setItem(21, ISS_G_P);
/* 402 */     this.invShopGranadeThrBlau.setItem(22, ISS_G_P);
/* 403 */     this.invShopGranadeThrBlau.setItem(23, ISS_G_P);
/* 404 */     this.invShopGranadeThrBlau.setItem(24, ISS_G_P);
/* 405 */     this.invShopGranadeThrBlau.setItem(25, ISS_G_P);
/* 406 */     this.invShopGranadeThrBlau.setItem(26, ISS_G_P);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 413 */     this.invShopBowsRot.setItem(0, ISS_G_P);
/* 414 */     this.invShopBowsRot.setItem(1, ISS_G_P);
/* 415 */     this.invShopBowsRot.setItem(2, ISS_G_P);
/* 416 */     this.invShopBowsRot.setItem(3, ISS_G_P);
/* 417 */     this.invShopBowsRot.setItem(4, ISS_G_P);
/* 418 */     this.invShopBowsRot.setItem(5, ISS_G_P);
/* 419 */     this.invShopBowsRot.setItem(6, ISS_G_P);
/* 420 */     this.invShopBowsRot.setItem(7, ISS_G_P);
/* 421 */     this.invShopBowsRot.setItem(8, ISS_G_P);
/*     */     
/*     */ 
/* 424 */     this.invShopBowsRot.setItem(9, ISNormal_Bow);
/*     */     
/* 426 */     this.invShopBowsRot.setItem(17, ISBack);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 435 */     Bukkit.getConsoleSender().sendMessage("§2[§4TNT§6Wars§2]§d §cShop wurde geladen!");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 441 */   public Inventory invShopRot = Bukkit.createInventory(null, 27, "§cShop");
/* 442 */   public Inventory invShopBlau = Bukkit.createInventory(null, 27, "§1Shop");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 447 */   public Inventory invShopMisslesRot = Bukkit.createInventory(null, 27, "§cMissles");
/* 448 */   public Inventory invShopMisslesBlau = Bukkit.createInventory(null, 27, "§1Missles");
/* 449 */   public Inventory invShopGranadesRot = Bukkit.createInventory(null, 27, "§cGranades");
/* 450 */   public Inventory invShopGranadesBlau = Bukkit.createInventory(null, 27, "§1Granades");
/* 451 */   public Inventory invShopGranadeThrRot = Bukkit.createInventory(null, 27, "§cGranade Throwers");
/* 452 */   public Inventory invShopGranadeThrBlau = Bukkit.createInventory(null, 27, "§1Granade Throwers");
/* 453 */   public Inventory invShopBowsRot = Bukkit.createInventory(null, 27, "§cBows");
/* 454 */   public Inventory invShopBowsBlau = Bukkit.createInventory(null, 27, "§1Bows");
/*     */   
/*     */   @EventHandler
/*     */   public void onInteractEntity(PlayerInteractEntityEvent e)
/*     */   {
/* 459 */     Player p = e.getPlayer();
/* 460 */     if (e.getRightClicked().getType() == EntityType.CREEPER) {
/* 461 */       Creeper Shop = (Creeper)e.getRightClicked();
/* 462 */       if (Shop.getCustomName().equalsIgnoreCase("§cShop")) {
/* 463 */         p.openInventory(this.invShopRot);
/* 464 */         return;
/*     */       }
/*     */       
/* 467 */       if (Shop.getCustomName().equalsIgnoreCase("§1Shop")) {
/* 468 */         p.openInventory(this.invShopBlau);
/* 469 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent e) {
/*     */     try {
/* 477 */       Player p = (Player)e.getWhoClicked();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 482 */       if ((e.getInventory() != null) && 
/* 483 */         (e.getInventory().getName() != null)) {
/* 484 */         if (e.getInventory().getName().equalsIgnoreCase("§cShop")) {
/* 485 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Missles")) {
/* 486 */             e.setCancelled(true);
/* 487 */             p.openInventory(this.invShopMisslesRot);
/*     */           }
/*     */           
/* 490 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Granaten")) {
/* 491 */             e.setCancelled(true);
/* 492 */             p.openInventory(this.invShopGranadesRot);
/*     */           }
/*     */           
/* 495 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Granat-Werfer")) {
/* 496 */             e.setCancelled(true);
/* 497 */             p.openInventory(this.invShopGranadeThrRot);
/*     */           }
/*     */           
/*     */ 
/* 501 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cEXIT")) {
/* 502 */             e.setCancelled(true);
/* 503 */             p.closeInventory();
/*     */           }
/*     */           
/* 506 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8")) {
/* 507 */             e.setCancelled(true);
/*     */           }
/* 509 */           return;
/*     */         }
/*     */         
/* 512 */         if (e.getInventory().getName().equalsIgnoreCase("§1Shop")) {
/* 513 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Missles")) {
/* 514 */             e.setCancelled(true);
/* 515 */             p.openInventory(this.invShopMisslesBlau);
/*     */           }
/*     */           
/* 518 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Granaten")) {
/* 519 */             e.setCancelled(true);
/* 520 */             p.openInventory(this.invShopGranadesBlau);
/*     */           }
/*     */           
/* 523 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Granat-Werfer")) {
/* 524 */             e.setCancelled(true);
/* 525 */             p.openInventory(this.invShopGranadeThrBlau);
/*     */           }
/*     */           
/*     */ 
/* 529 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cEXIT")) {
/* 530 */             e.setCancelled(true);
/* 531 */             e.setCancelled(true);
/* 532 */             p.closeInventory();
/*     */           }
/*     */           
/* 535 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8")) {
/* 536 */             e.setCancelled(true);
/*     */           }
/* 538 */           return;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 543 */         if (e.getInventory().getName().equalsIgnoreCase("§cMissles")) {
/* 544 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6TNT Cruiser")) {
/* 545 */             e.setCancelled(true);
/* 546 */             if (e.getClick() == ClickType.SHIFT_LEFT) {
/* 547 */               if (p.getLevel() >= 320) {
/* 548 */                 p.setLevel(p.getLevel() - 320);
/* 549 */                 TNTMissle.Cruiser(p, 64);
/*     */               } else {
/* 551 */                 notenoughLevel(p);
/*     */               }
/* 553 */             } else if (p.getLevel() >= 5) {
/* 554 */               p.setLevel(p.getLevel() - 5);
/* 555 */               TNTMissle.Cruiser(p, 1);
/*     */             } else {
/* 557 */               notenoughLevel(p);
/*     */             }
/*     */           }
/*     */           
/* 561 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8")) {
/* 562 */             e.setCancelled(true);
/*     */           }
/*     */           
/* 565 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cBACK")) {
/* 566 */             e.setCancelled(true);
/* 567 */             p.openInventory(this.invShopRot);
/*     */           }
/* 569 */           return;
/*     */         }
/*     */         
/* 572 */         if (e.getInventory().getName().equalsIgnoreCase("§1Missles")) {
/* 573 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6TNT Cruiser")) {
/* 574 */             e.setCancelled(true);
/* 575 */             if (e.getClick() == ClickType.SHIFT_LEFT) {
/* 576 */               if (p.getLevel() >= 320) {
/* 577 */                 p.setLevel(p.getLevel() - 320);
/* 578 */                 TNTMissle.Cruiser(p, 64);
/*     */               } else {
/* 580 */                 notenoughLevel(p);
/*     */               }
/* 582 */             } else if (p.getLevel() >= 5) {
/* 583 */               p.setLevel(p.getLevel() - 5);
/* 584 */               TNTMissle.Cruiser(p, 1);
/*     */             } else {
/* 586 */               notenoughLevel(p);
/*     */             }
/*     */           }
/*     */           
/* 590 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8")) {
/* 591 */             e.setCancelled(true);
/*     */           }
/*     */           
/* 594 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cBACK")) {
/* 595 */             e.setCancelled(true);
/* 596 */             p.openInventory(this.invShopBlau);
/*     */           }
/* 598 */           return;
/*     */         }
/*     */         
/* 601 */         if (e.getInventory().getName().equalsIgnoreCase("§cGranades"))
/*     */         {
/* 603 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Normale Granate")) {
/* 604 */             e.setCancelled(true);
/* 605 */             if (e.getClick() == ClickType.SHIFT_LEFT) {
/* 606 */               if (p.getLevel() >= 128) {
/* 607 */                 Granate.Granade(p, 64);
/* 608 */                 p.setLevel(p.getLevel() - 128);
/*     */               } else {
/* 610 */                 notenoughLevel(p);
/*     */               }
/* 612 */             } else if (p.getLevel() >= 2) {
/* 613 */               Granate.Granade(p, 1);
/* 614 */               p.setLevel(p.getLevel() - 2);
/*     */             } else {
/* 616 */               notenoughLevel(p);
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 621 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8")) {
/* 622 */             e.setCancelled(true);
/*     */           }
/*     */           
/* 625 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cBACK")) {
/* 626 */             e.setCancelled(true);
/* 627 */             p.openInventory(this.invShopRot);
/*     */           }
/* 629 */           return;
/*     */         }
/*     */         
/* 632 */         if (e.getInventory().getName().equalsIgnoreCase("§1Granades"))
/*     */         {
/* 634 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Normale Granate")) {
/* 635 */             e.setCancelled(true);
/* 636 */             if (e.getClick() == ClickType.SHIFT_LEFT) {
/* 637 */               if (p.getLevel() >= 128) {
/* 638 */                 Granate.Granade(p, 64);
/* 639 */                 p.setLevel(p.getLevel() - 128);
/*     */               } else {
/* 641 */                 notenoughLevel(p);
/*     */               }
/* 643 */             } else if (p.getLevel() >= 2) {
/* 644 */               Granate.Granade(p, 1);
/* 645 */               p.setLevel(p.getLevel() - 2);
/*     */             } else {
/* 647 */               notenoughLevel(p);
/*     */             }
/*     */           }
/*     */           
/* 651 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8")) {
/* 652 */             e.setCancelled(true);
/*     */           }
/*     */           
/* 655 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cBACK")) {
/* 656 */             e.setCancelled(true);
/* 657 */             p.openInventory(this.invShopBlau);
/*     */           }
/* 659 */           return;
/*     */         }
/*     */         
/* 662 */         if (e.getInventory().getName().equalsIgnoreCase("§cGranade Throwers")) {
/* 663 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Normaler Granatwerfer")) {
/* 664 */             e.setCancelled(true);
/* 665 */             if (p.getLevel() >= 4) {
/* 666 */               GranadeThrower.Common(p, 1);
/* 667 */               p.setLevel(p.getLevel() - 4);
/*     */             } else {
/* 669 */               notenoughLevel(p);
/*     */             }
/*     */           }
/*     */           
/* 673 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8")) {
/* 674 */             e.setCancelled(true);
/*     */           }
/*     */           
/* 677 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cBACK")) {
/* 678 */             e.setCancelled(true);
/* 679 */             p.openInventory(this.invShopBlau);
/*     */           }
/* 681 */           return;
/*     */         }
/*     */         
/* 684 */         if (e.getInventory().getName().equalsIgnoreCase("§1Granade Throwers")) {
/* 685 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Normaler Granatwerfer")) {
/* 686 */             e.setCancelled(true);
/* 687 */             if (p.getLevel() >= 4) {
/* 688 */               GranadeThrower.Common(p, 1);
/* 689 */               p.setLevel(p.getLevel() - 4);
/*     */             } else {
/* 691 */               notenoughLevel(p);
/*     */             }
/*     */           }
/*     */           
/* 695 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8")) {
/* 696 */             e.setCancelled(true);
/*     */           }
/*     */           
/* 699 */           if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cBACK")) {
/* 700 */             e.setCancelled(true);
/* 701 */             p.openInventory(this.invShopBlau);
/*     */           }
/* 703 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @EventHandler
/*     */   public void onCreeperTarget(EntityTargetEvent e)
/*     */   {
/*     */     try
/*     */     {
/* 718 */       if (e.getEntity().getType() == EntityType.CREEPER) {
/* 719 */         Creeper Creeper = (Creeper)e.getEntity();
/* 720 */         if ((Creeper.getCustomName().equalsIgnoreCase("§cShop")) || (Creeper.getCustomName().equalsIgnoreCase("§1Shop"))) {
/* 721 */           e.setCancelled(true);
/*     */         }
/*     */       }
/*     */     } catch (Exception localException) {}
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onCreeperPrime(EntityExplodeEvent e) {
/*     */     try {
/* 730 */       if (e.getEntity().getType() == EntityType.CREEPER) {
/* 731 */         Creeper Creeper = (Creeper)e.getEntity();
/* 732 */         if ((Creeper.getCustomName() != null) && (
/* 733 */           (Creeper.getCustomName().equalsIgnoreCase("§cShop")) || (Creeper.getCustomName().equalsIgnoreCase("§1Shop")))) {
/* 734 */           e.setCancelled(true);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntDamage(EntityDamageEvent e) {
/*     */     try {
/* 744 */       if ((e.getEntity().getType() == EntityType.CREEPER) && 
/* 745 */         (e.getEntity().getCustomName() != null) && (
/* 746 */         (e.getEntity().getCustomName().equalsIgnoreCase("§cShop")) || (e.getEntity().getCustomName().equalsIgnoreCase("§1Shop")))) {
/* 747 */         e.setCancelled(true);
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onCreeperPrime(ExplosionPrimeEvent e)
/*     */   {
/* 756 */     if ((e.getEntity().getType() == EntityType.CREEPER) && 
/* 757 */       (e.getEntity().getCustomName() != null)) {
/* 758 */       if (e.getEntity().getCustomName().equalsIgnoreCase("§cShop")) {
/* 759 */         Location loc = e.getEntity().getLocation();
/* 760 */         World world = e.getEntity().getWorld();
/* 761 */         e.setCancelled(true);
/* 762 */         e.getEntity().remove();
/*     */         
/* 764 */         Entity Ent = world.spawnEntity(loc, EntityType.CREEPER);
/* 765 */         Ent.teleport(loc);
/* 766 */         Creeper Shop = (Creeper)Ent;
/* 767 */         Shop.setCustomName("§cShop");
/* 768 */         Shop.setCustomNameVisible(true);
/* 769 */         Shop.setFallDistance(0.0F);
/* 770 */         ((LivingEntity)Ent).setRemoveWhenFarAway(false);
/* 771 */         Shop.setNoDamageTicks(Integer.MAX_VALUE);
/* 772 */         Shop.setCanPickupItems(false);
/* 773 */         Shop.setPowered(true);
/*     */       }
/*     */       
/* 776 */       if (e.getEntity().getCustomName().equalsIgnoreCase("§1Shop")) {
/* 777 */         Location loc = e.getEntity().getLocation();
/* 778 */         World world = e.getEntity().getWorld();
/* 779 */         e.setCancelled(true);
/* 780 */         e.getEntity().remove();
/*     */         
/* 782 */         Entity Ent = world.spawnEntity(loc, EntityType.CREEPER);
/* 783 */         Ent.teleport(loc);
/* 784 */         Creeper Shop = (Creeper)Ent;
/* 785 */         Shop.setCustomName("§1Shop");
/* 786 */         Shop.setCustomNameVisible(true);
/* 787 */         Shop.setFallDistance(0.0F);
/* 788 */         ((LivingEntity)Ent).setRemoveWhenFarAway(false);
/* 789 */         Shop.setNoDamageTicks(Integer.MAX_VALUE);
/* 790 */         Shop.setCanPickupItems(false);
/* 791 */         Shop.setPowered(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\Shop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */