/*    */ package me.Mr_Coding.tntwars.start;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class HimmelsRichtung
/*    */ {
/*    */   public HimmelsRichtung(start main) {}
/*    */   
/*    */   public static String getDirection(Player p)
/*    */     throws NullPointerException
/*    */   {
/* 13 */     double rotation = (p.getLocation().getYaw() - 90.0F) % 360.0F;
/* 14 */     if (rotation < 0.0D)
/* 15 */       rotation += 360.0D;
/* 16 */     if ((0.0D <= rotation) && (rotation < 67.5D))
/* 17 */       return "NW";
/* 18 */     if ((67.5D <= rotation) && (rotation < 112.5D))
/* 19 */       return "N";
/* 20 */     if ((112.5D <= rotation) && (rotation < 157.5D))
/* 21 */       return "NO";
/* 22 */     if ((157.5D <= rotation) && (rotation < 202.5D))
/* 23 */       return "O";
/* 24 */     if ((202.5D <= rotation) && (rotation < 247.5D))
/* 25 */       return "SO";
/* 26 */     if ((247.5D <= rotation) && (rotation < 292.5D))
/* 27 */       return "S";
/* 28 */     if ((292.5D <= rotation) && (rotation < 337.5D))
/* 29 */       return "SW";
/* 30 */     if ((337.5D <= rotation) && (rotation < 360.0D)) {
/* 31 */       return "W";
/*    */     }
/* 33 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\HimmelsRichtung.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */