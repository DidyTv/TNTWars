/*    */ package me.Mr_Coding.tntwars.start;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.io.FileUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ 
/*    */ public class Map_Reset implements org.bukkit.event.Listener
/*    */ {
/*    */   private Plugin plugin;
/*    */   
/*    */   public Map_Reset(start main)
/*    */   {
/* 18 */     this.plugin = main;
/* 19 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public World resetMap(File backup, File reset, String worldname)
/*    */     throws IOException
/*    */   {
/* 27 */     for (Player all : ) {
/* 28 */       all.teleport(Bukkit.getWorld("world").getSpawnLocation());
/*    */     }
/*    */     
/* 31 */     Bukkit.unloadWorld(worldname, true);
/*    */     try
/*    */     {
/* 34 */       FileUtils.deleteDirectory(reset);
/*    */     } catch (IOException e) {
/* 36 */       e.printStackTrace();
/*    */     }
/*    */     
/* 39 */     if (!reset.exists()) {
/*    */       try {
/* 41 */         FileUtils.copyDirectory(backup, reset);
/*    */       } catch (IOException e) {
/* 43 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */     
/* 47 */     World world = Bukkit.createWorld(new org.bukkit.WorldCreator(worldname));
/* 48 */     return world;
/*    */   }
/*    */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\Map_Reset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */