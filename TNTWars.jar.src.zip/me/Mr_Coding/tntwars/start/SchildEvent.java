/*    */ package me.Mr_Coding.tntwars.start;
/*    */ 
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.block.Sign;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.block.SignChangeEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ 
/*    */ public class SchildEvent implements org.bukkit.event.Listener
/*    */ {
/*    */   private start plugin;
/*    */   
/*    */   public SchildEvent(start main)
/*    */   {
/* 17 */     this.plugin = main;
/* 18 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onSignChange(SignChangeEvent e) {
/* 23 */     Player p = e.getPlayer();
/* 24 */     if (e.getLine(0).equalsIgnoreCase("[tntwars]")) {
/* 25 */       p.sendMessage("§2[§4TNT§6Wars§2]§d Schild wurde erfolgreich gesetzt!");
/*    */     }
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerClickSign(PlayerInteractEvent e) {
/* 31 */     Player p = e.getPlayer();
/* 32 */     if ((e.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) && 
/* 33 */       ((e.getClickedBlock().getState() instanceof Sign))) {
/* 34 */       Sign s = (Sign)e.getClickedBlock().getState();
/*    */       
/*    */ 
/* 37 */       if (s.getLine(0).equalsIgnoreCase("[tntwars]")) {
/* 38 */         p.performCommand("tntwars join " + s.getLine(1));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\SchildEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */