/*    */ package me.Mr_Coding.tntwars.start;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Chunk;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class WorldManager
/*    */ {
/*    */   public static World loadWorld(String world)
/*    */   {
/* 13 */     if (!isLoaded(world)) {
/* 14 */       return Bukkit.getServer().createWorld(new org.bukkit.WorldCreator(world));
/*    */     }
/* 16 */     return Bukkit.getWorld(world);
/*    */   }
/*    */   
/*    */   public static boolean isLoaded(String world)
/*    */   {
/* 21 */     for (World w : Bukkit.getServer().getWorlds()) {
/* 22 */       if (w.getName().equals(world)) {
/* 23 */         return true;
/*    */       }
/*    */     }
/*    */     
/* 27 */     return false;
/*    */   }
/*    */   
/*    */   public static boolean unloadWorld(String world) {
/* 31 */     if (isLoaded(world)) {
/* 32 */       World w = Bukkit.getWorld(world);
/* 33 */       for (Player p : w.getPlayers()) {
/* 34 */         p.teleport(((World)Bukkit.getWorlds().get(0)).getSpawnLocation());
/*    */       }
/*    */       Chunk[] arrayOfChunk;
/* 37 */       int j = (arrayOfChunk = w.getLoadedChunks()).length; for (int i = 0; i < j; i++) { Chunk c = arrayOfChunk[i];
/* 38 */         c.unload();
/*    */       }
/*    */       
/* 41 */       boolean unload = Bukkit.unloadWorld(w, true);
/* 42 */       return unload;
/*    */     }
/*    */     
/* 45 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\WorldManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */