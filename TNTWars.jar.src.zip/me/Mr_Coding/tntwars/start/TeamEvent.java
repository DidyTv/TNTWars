/*    */ package me.Mr_Coding.tntwars.start;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class TeamEvent implements org.bukkit.event.Listener
/*    */ {
/*    */   private start plugin;
/*    */   static final String prefix = "§2[§4TNT§6Wars§2]§d ";
/*    */   
/*    */   public TeamEvent(start main)
/*    */   {
/* 14 */     this.plugin = main;
/* 15 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @org.bukkit.event.EventHandler
/*    */   public void onItemInCompassClick(org.bukkit.event.inventory.InventoryClickEvent e)
/*    */   {
/* 24 */     Player p = (Player)e.getWhoClicked();
/*    */     
/* 26 */     if ((p.getItemInHand().getType().equals(org.bukkit.Material.COMPASS)) && 
/* 27 */       (e.getInventory().getName().equalsIgnoreCase(ChatColor.GREEN + "Team wählen"))) {
/*    */       try {
/* 29 */         if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.RED + "Rot")) {
/* 30 */           e.setCancelled(true);
/* 31 */           if (GameManager.rot.size() > 1) {
/* 32 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Das Team " + ChatColor.RED + "Rot " + ChatColor.LIGHT_PURPLE + "ist " + ChatColor.RED + "voll!");
/*    */           }
/* 34 */           else if (GameManager.rot.contains(p)) {
/* 35 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Du bist bereits in Team " + ChatColor.RED + "Rot!");
/*    */           } else {
/* 37 */             GameManager.rot.add(p);
/* 38 */             GameManager.blau.remove(p);
/* 39 */             GameManager.noTeam.remove(p);
/* 40 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Du bist nun in Team " + ChatColor.RED + "Rot");
/*    */           }
/*    */         }
/*    */         
/*    */ 
/* 45 */         if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.BLUE + "Blau")) {
/* 46 */           e.setCancelled(true);
/* 47 */           if (GameManager.blau.size() > 1) {
/* 48 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Das Team " + ChatColor.BLUE + "Blau" + ChatColor.LIGHT_PURPLE + "ist " + ChatColor.RED + "voll!");
/*    */           }
/* 50 */           else if (GameManager.blau.contains(p)) {
/* 51 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Du bist bereits in Team " + ChatColor.BLUE + "Blau!");
/*    */           } else {
/* 53 */             GameManager.blau.add(p);
/* 54 */             GameManager.rot.remove(p);
/* 55 */             GameManager.noTeam.remove(p);
/* 56 */             p.sendMessage("§2[§4TNT§6Wars§2]§d Du bist nun in Team " + ChatColor.BLUE + "Blau");
/*    */           }
/*    */         }
/*    */       }
/*    */       catch (Exception localException) {}
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\TeamEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */