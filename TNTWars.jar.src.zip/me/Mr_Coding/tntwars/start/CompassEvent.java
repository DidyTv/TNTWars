/*    */ package me.Mr_Coding.tntwars.start;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ public class CompassEvent implements org.bukkit.event.Listener
/*    */ {
/*    */   private start plugin;
/*    */   
/*    */   public CompassEvent(start main)
/*    */   {
/* 18 */     this.plugin = main;
/* 19 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*    */   }
/*    */   
/*    */   @org.bukkit.event.EventHandler
/*    */   public void onCompassClick(PlayerInteractEvent e) {
/* 24 */     Player p = e.getPlayer();
/* 25 */     if (((e.getAction() == Action.RIGHT_CLICK_AIR) || (e.getAction() == Action.RIGHT_CLICK_BLOCK)) && 
/* 26 */       (e.getMaterial().equals(Material.COMPASS))) {
/* 27 */       ItemStack team = e.getItem();
/* 28 */       ItemMeta teammeta = team.getItemMeta();
/*    */       
/* 30 */       if (teammeta.getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "Team auswählen"))
/*    */       {
/* 32 */         ItemStack RoteWolle = new ItemStack(Material.WOOL);
/* 33 */         ItemMeta RoteWollemeta = RoteWolle.getItemMeta();
/* 34 */         RoteWollemeta.setDisplayName(ChatColor.RED + "Rot");
/* 35 */         RoteWolle.setDurability((short)14);
/*    */         
/*    */ 
/* 38 */         RoteWolle.setItemMeta(RoteWollemeta);
/*    */         
/* 40 */         this.plugin.invTeams.setItem(3, RoteWolle);
/*    */         
/*    */ 
/*    */ 
/* 44 */         ItemStack BlaueWolle = new ItemStack(Material.WOOL);
/* 45 */         ItemMeta BlaueWollemeta = BlaueWolle.getItemMeta();
/* 46 */         BlaueWollemeta.setDisplayName(ChatColor.BLUE + "Blau");
/* 47 */         BlaueWolle.setDurability((short)11);
/*    */         
/*    */ 
/* 50 */         BlaueWolle.setItemMeta(BlaueWollemeta);
/*    */         
/* 52 */         this.plugin.invTeams.setItem(5, BlaueWolle);
/*    */         
/* 54 */         p.openInventory(this.plugin.invTeams);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\CompassEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */