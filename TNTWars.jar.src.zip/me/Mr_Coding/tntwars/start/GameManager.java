/*     */ package me.Mr_Coding.tntwars.start;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventException;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ public class GameManager implements org.bukkit.event.Listener
/*     */ {
/*     */   private start plugin;
/*     */   
/*     */   public GameManager(start main)
/*     */   {
/*  26 */     this.plugin = main;
/*  27 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*  30 */   private HashMap<World, Boolean> active = new HashMap();
/*     */   public static GameManager CurrentState;
/*     */   
/*     */   public void startSpawners(final String Worldname)
/*     */   {
/*  35 */     for (World worlds : ) {
/*  36 */       if (worlds.getName().equalsIgnoreCase(Worldname)) {
/*  37 */         this.active.put(worlds, Boolean.valueOf(true));
/*     */       }
/*     */     }
/*     */     
/*  41 */     Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable()
/*     */     {
/*     */ 
/*     */       public void run()
/*     */       {
/*  46 */         for (World world : ) {
/*  47 */           if (world.getName().equalsIgnoreCase(Worldname)) {
/*  48 */             int Count = GameManager.this.plugin.getConfig().getInt("GameWorld." + world.getName() + ".Spawners.Count");
/*     */             
/*     */             try
/*     */             {
/*  52 */               for (int i = 0; i < Count + 1; i++) {
/*     */                 try {
/*  54 */                   for (World tempworld : Bukkit.getWorlds()) {
/*  55 */                     if (GameManager.this.plugin.getConfig().getString("GameWorld." + world.getName() + ".Spawners." + i + ".World").equalsIgnoreCase(tempworld.getName()))
/*     */                     {
/*  57 */                       Location loc = new Location(tempworld, GameManager.this.plugin.getConfig().getDouble("GameWorld." + world.getName() + ".Spawners." + i + ".X"), 
/*  58 */                         GameManager.this.plugin.getConfig().getDouble("GameWorld." + world.getName() + ".Spawners." + i + ".Y"), 
/*  59 */                         GameManager.this.plugin.getConfig().getDouble("GameWorld." + world.getName() + ".Spawners." + i + ".Z"));
/*     */                       
/*     */ 
/*     */ 
/*  63 */                       ItemStack IS_BronzXP = new ItemStack(Material.CLAY_BRICK);
/*  64 */                       ItemMeta IM_BronzXP = IS_BronzXP.getItemMeta();
/*     */                       
/*  66 */                       ArrayList<String> BronzXPLore = new ArrayList();
/*  67 */                       BronzXPLore.add("§6XP");
/*  68 */                       IM_BronzXP.setLore(BronzXPLore);
/*  69 */                       IS_BronzXP.setItemMeta(IM_BronzXP);
/*     */                       
/*     */ 
/*  72 */                       loc.getWorld().dropItemNaturally(loc, IS_BronzXP);
/*     */                     }
/*     */                   }
/*     */                 }
/*     */                 catch (Exception localException) {}
/*     */               }
/*     */             }
/*     */             catch (Exception localException1) {}
/*     */           }
/*     */         }
/*     */       }
/*  83 */     }, 20L, 20L);
/*     */   }
/*     */   
/*     */   public void stopSpawners(String Worldname) {
/*  87 */     for (World world : ) {
/*  88 */       if (world.getName().equalsIgnoreCase(Worldname)) {
/*     */         try {
/*  90 */           this.active.put(world, Boolean.valueOf(false));
/*     */         }
/*     */         catch (Exception localException) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 100 */   public static int GameFullint = 0;
/*     */   
/* 102 */   public static ArrayList<Player> rot = new ArrayList();
/* 103 */   public static ArrayList<Player> blau = new ArrayList();
/* 104 */   public static ArrayList<Player> noTeam = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isGameFull()
/*     */   {
/* 110 */     if (GameFullint > 4) {
/* 111 */       return true;
/*     */     }
/* 113 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setState(GameManager state)
/*     */   {
/* 122 */     CurrentState = state;
/*     */   }
/*     */   
/*     */   public static boolean isState(GameManager state) {
/* 126 */     return CurrentState == state;
/*     */   }
/*     */   
/*     */   public static GameManager getState() {
/* 130 */     return CurrentState;
/*     */   }
/*     */   
/*     */   public static GameManager Lobby() {
/* 134 */     return CurrentState;
/*     */   }
/*     */   
/*     */   public static GameManager Game() {
/* 138 */     return CurrentState;
/*     */   }
/*     */   
/*     */   public static GameManager Restart() {
/* 142 */     return CurrentState;
/*     */   }
/*     */   
/*     */   public static String getStatus() {
/* 146 */     String s = "";
/*     */     
/* 148 */     if (isState(Lobby())) {
/* 149 */       s = ChatColor.GOLD + "Lobby";
/*     */     }
/*     */     
/* 152 */     if (isState(Game())) {
/* 153 */       s = ChatColor.GOLD + "Game";
/*     */     }
/*     */     
/* 156 */     if (isState(Restart())) {
/* 157 */       s = ChatColor.GOLD + "Restart";
/*     */     }
/* 159 */     return s;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPickUpItem(PlayerPickupItemEvent e) throws EventException {
/* 164 */     Player p = e.getPlayer();
/* 165 */     ItemStack Item = e.getItem().getItemStack();
/* 166 */     ItemMeta ItemM = Item.getItemMeta();
/*     */     try {
/* 168 */       if (ItemM.getLore().contains("§6XP")) {
/* 169 */         e.setCancelled(true);
/* 170 */         p.getWorld().playSound(p.getLocation(), org.bukkit.Sound.ORB_PICKUP, 0.2F, 0.2F);
/* 171 */         e.getItem().remove();
/* 172 */         int Amount = Item.getAmount();
/* 173 */         for (int i = 0; i < Amount; i++) {
/* 174 */           if (p.getExp() > 0.97D) {
/* 175 */             double tmpxp = p.getExp();
/* 176 */             p.setLevel(p.getLevel() + 1);
/* 177 */             tmpxp = 1.0D - tmpxp;
/* 178 */             p.setExp((float)tmpxp);
/*     */           } else {
/* 180 */             p.setExp((float)(p.getExp() + 0.03D));
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception localException) {}
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDeath(PlayerDeathEvent e) {
/* 189 */     Player p = e.getEntity();
/* 190 */     Bukkit.broadcastMessage(p.getName());
/*     */     
/* 192 */     if ((blau.contains(p)) || (rot.contains(p))) {
/* 193 */       p.sendMessage("§2[§4TNT§6Wars§2]§d §cDu bist §ngestorben§c!");
/* 194 */       for (Player all : Bukkit.getOnlinePlayers()) {
/* 195 */         if (((rot.contains(all)) && (!all.equals(p))) || ((blau.contains(all)) && (!all.equals(p)))) {
/* 196 */           all.sendMessage("§2[§4TNT§6Wars§2]§d Der Spieler " + all.getName() + " ist §c§ngestorben§c!");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\start\GameManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */