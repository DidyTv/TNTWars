/*      */ package me.Mr_Coding.tntwars.items;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import me.Mr_Coding.tntwars.start.HimmelsRichtung;
/*      */ import me.Mr_Coding.tntwars.start.start;
/*      */ import net.md_5.bungee.api.ChatColor;
/*      */ import org.bukkit.Bukkit;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.block.Block;
/*      */ import org.bukkit.block.Sign;
/*      */ import org.bukkit.entity.Entity;
/*      */ import org.bukkit.entity.Item;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.block.Action;
/*      */ import org.bukkit.event.block.BlockBreakEvent;
/*      */ import org.bukkit.event.block.BlockPhysicsEvent;
/*      */ import org.bukkit.event.player.PlayerInteractEvent;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ import org.bukkit.inventory.PlayerInventory;
/*      */ import org.bukkit.inventory.meta.ItemMeta;
/*      */ import org.bukkit.plugin.Plugin;
/*      */ import org.bukkit.scheduler.BukkitScheduler;
/*      */ 
/*      */ public class TNTMissle implements org.bukkit.event.Listener
/*      */ {
/*      */   private Plugin plugin;
/*      */   
/*      */   public TNTMissle(start main)
/*      */   {
/*   32 */     this.plugin = main;
/*   33 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*      */   }
/*      */   
/*      */   public static void Cruiser(Player p, int slot, int size) {
/*   37 */     ItemStack TNTMissle = new ItemStack(Material.MONSTER_EGG);
/*   38 */     TNTMissle.setAmount(size);
/*   39 */     TNTMissle.setDurability((short)93);
/*   40 */     ItemMeta TNTMissleMeta = TNTMissle.getItemMeta();
/*      */     
/*      */ 
/*   43 */     TNTMissleMeta.setDisplayName(ChatColor.GOLD + "TNTMissle");
/*      */     
/*   45 */     ArrayList<String> Granadelore = new ArrayList();
/*   46 */     Granadelore.add(ChatColor.LIGHT_PURPLE + "Place it in your eyes direction!");
/*      */     
/*   48 */     TNTMissleMeta.setLore(Granadelore);
/*   49 */     TNTMissle.setItemMeta(TNTMissleMeta);
/*   50 */     TNTMissle.setDurability((short)93);
/*      */     
/*   52 */     p.getInventory().setItem(slot, TNTMissle);
/*      */   }
/*      */   
/*      */   public static void Cruiser(Player p, int size)
/*      */   {
/*   57 */     ItemStack TNTMissle = new ItemStack(Material.MONSTER_EGG);
/*   58 */     TNTMissle.setAmount(size);
/*   59 */     TNTMissle.setDurability((short)93);
/*   60 */     ItemMeta TNTMissleMeta = TNTMissle.getItemMeta();
/*      */     
/*      */ 
/*   63 */     TNTMissleMeta.setDisplayName(ChatColor.GOLD + "TNTMissle");
/*      */     
/*   65 */     ArrayList<String> Granadelore = new ArrayList();
/*   66 */     Granadelore.add(ChatColor.LIGHT_PURPLE + "Place it in your eyes direction!");
/*      */     
/*   68 */     TNTMissleMeta.setLore(Granadelore);
/*   69 */     TNTMissle.setItemMeta(TNTMissleMeta);
/*   70 */     TNTMissle.setDurability((short)93);
/*      */     
/*   72 */     p.getInventory().addItem(new ItemStack[] { TNTMissle });
/*      */   }
/*      */   
/*      */ 
/*      */   @EventHandler
/*      */   public void onPlayerInteract(final PlayerInteractEvent e)
/*      */   {
/*   79 */     final Player p = e.getPlayer();
/*   80 */     if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) || (e.getAction() == Action.RIGHT_CLICK_AIR)) {
/*      */       try {
/*   82 */         Sign sign = (Sign)e.getClickedBlock().getState();
/*      */         
/*   84 */         if ((sign.getLine(0).equalsIgnoreCase("§6TNTWars")) && 
/*   85 */           (sign.getLine(1).equalsIgnoreCase("TNTMissle Cruiser")) && 
/*   86 */           (sign.getLine(2).equalsIgnoreCase("§a§nBreak me!"))) {
/*   87 */           if (sign.getLine(3).equalsIgnoreCase("1")) {
/*   88 */             Block b = sign.getBlock();
/*   89 */             b.setType(Material.AIR);
/*   90 */             Location loc = b.getLocation();
/*      */             
/*   92 */             loc.setZ(loc.getZ() + 1.0D);
/*   93 */             loc.setX(loc.getX() - 1.0D);
/*   94 */             b = loc.getBlock();
/*   95 */             b.setType(Material.AIR);
/*      */             
/*   97 */             e.setCancelled(true);
/*   98 */             return;
/*      */           }
/*      */           
/*  101 */           if (sign.getLine(3).equalsIgnoreCase("2")) {
/*  102 */             Block b = sign.getBlock();
/*  103 */             b.setType(Material.AIR);
/*  104 */             Location loc = b.getLocation();
/*      */             
/*  106 */             loc.setZ(loc.getZ() - 1.0D);
/*  107 */             loc.setX(loc.getX() + 1.0D);
/*  108 */             b = loc.getBlock();
/*  109 */             b.setType(Material.AIR);
/*      */             
/*  111 */             e.setCancelled(true);
/*  112 */             return;
/*      */           }
/*      */           
/*  115 */           if (sign.getLine(3).equalsIgnoreCase("3"))
/*      */           {
/*  117 */             Block b = sign.getBlock();
/*  118 */             b.setType(Material.AIR);
/*  119 */             Location loc = b.getLocation();
/*      */             
/*  121 */             loc.setX(loc.getX() + 1.0D);
/*  122 */             loc.setZ(loc.getZ() + 1.0D);
/*  123 */             b = loc.getBlock();
/*  124 */             b.setType(Material.AIR);
/*      */             
/*  126 */             e.setCancelled(true);
/*  127 */             return;
/*      */           }
/*      */           
/*  130 */           if (sign.getLine(3).equalsIgnoreCase("4"))
/*      */           {
/*  132 */             Block b = sign.getBlock();
/*  133 */             b.setType(Material.AIR);
/*  134 */             Location loc = b.getLocation();
/*      */             
/*  136 */             loc.setX(loc.getX() - 1.0D);
/*  137 */             loc.setZ(loc.getZ() - 1.0D);
/*  138 */             b = loc.getBlock();
/*  139 */             b.setType(Material.AIR);
/*      */             
/*  141 */             e.setCancelled(true);
/*  142 */             return;
/*      */           }
/*      */           
/*  145 */           if (sign.getLine(3).equalsIgnoreCase("5")) {
/*  146 */             Block b = sign.getBlock();
/*  147 */             b.setType(Material.AIR);
/*  148 */             Location loc = b.getLocation();
/*      */             
/*  150 */             loc.setX(loc.getX() - 1.0D);
/*  151 */             loc.setZ(loc.getZ() - 1.0D);
/*  152 */             b = loc.getBlock();
/*  153 */             b.setType(Material.AIR);
/*      */             
/*  155 */             e.setCancelled(true);
/*  156 */             return;
/*      */           }
/*      */           
/*  159 */           if (sign.getLine(3).equalsIgnoreCase("6")) {
/*  160 */             Block b = sign.getBlock();
/*  161 */             b.setType(Material.AIR);
/*  162 */             Location loc = b.getLocation();
/*      */             
/*  164 */             loc.setX(loc.getX() + 1.0D);
/*  165 */             loc.setZ(loc.getZ() + 1.0D);
/*  166 */             b = loc.getBlock();
/*  167 */             b.setType(Material.AIR);
/*      */             
/*  169 */             e.setCancelled(true);
/*  170 */             return;
/*      */           }
/*      */           
/*  173 */           if (sign.getLine(3).equalsIgnoreCase("7")) {
/*  174 */             Block b = sign.getBlock();
/*  175 */             b.setType(Material.AIR);
/*  176 */             Location loc = b.getLocation();
/*      */             
/*  178 */             loc.setX(loc.getX() + 1.0D);
/*  179 */             loc.setZ(loc.getZ() - 1.0D);
/*  180 */             b = loc.getBlock();
/*  181 */             b.setType(Material.AIR);
/*      */             
/*  183 */             e.setCancelled(true);
/*  184 */             return;
/*      */           }
/*      */           
/*  187 */           if (sign.getLine(3).equalsIgnoreCase("8")) {
/*  188 */             Block b = sign.getBlock();
/*  189 */             b.setType(Material.AIR);
/*  190 */             Location loc = b.getLocation();
/*      */             
/*  192 */             loc.setX(loc.getX() - 1.0D);
/*  193 */             loc.setZ(loc.getZ() + 1.0D);
/*  194 */             b = loc.getBlock();
/*  195 */             b.setType(Material.AIR);
/*      */             
/*  197 */             e.setCancelled(true);
/*  198 */             return;
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */       }
/*      */       catch (Exception localException)
/*      */       {
/*  206 */         if (e.getMaterial() == Material.MONSTER_EGG) {
/*      */           try {
/*  208 */             if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "TNTMissle")) {
/*  209 */               e.setCancelled(true);
/*      */               
/*      */ 
/*      */ 
/*  213 */               if (HimmelsRichtung.getDirection(p).equalsIgnoreCase("N")) {
/*  214 */                 final Location loc = e.getClickedBlock().getLocation();
/*      */                 
/*  216 */                 loc.setZ(loc.getZ() - 2.0D);
/*  217 */                 loc.setY(loc.getY() + 2.0D);
/*      */                 
/*      */ 
/*  220 */                 Block b1 = loc.getBlock();
/*  221 */                 b1.setType(Material.PISTON_BASE);
/*  222 */                 b1.setData((byte)2);
/*      */                 
/*  224 */                 loc.setY(loc.getY() + 1.0D);
/*  225 */                 b1 = loc.getBlock();
/*  226 */                 b1.setType(Material.PISTON_BASE);
/*  227 */                 b1.setData((byte)3);
/*      */                 
/*  229 */                 loc.setZ(loc.getZ() - 1.0D);
/*  230 */                 b1 = loc.getBlock();
/*  231 */                 b1.setType(Material.REDSTONE_BLOCK);
/*      */                 
/*  233 */                 loc.setY(loc.getY() - 1.0D);
/*  234 */                 b1 = loc.getBlock();
/*  235 */                 b1.setType(Material.SLIME_BLOCK);
/*      */                 
/*  237 */                 loc.setZ(loc.getZ() - 1.0D);
/*  238 */                 b1 = loc.getBlock();
/*  239 */                 b1.setType(Material.TNT);
/*      */                 
/*  241 */                 loc.setZ(loc.getZ() - 1.0D);
/*  242 */                 b1 = loc.getBlock();
/*  243 */                 b1.setType(Material.FURNACE);
/*      */                 
/*  245 */                 loc.setY(loc.getY() + 1.0D);
/*  246 */                 b1 = loc.getBlock();
/*  247 */                 b1.setType(Material.STAINED_GLASS);
/*      */                 
/*  249 */                 loc.setZ(loc.getZ() + 1.0D);
/*  250 */                 b1 = loc.getBlock();
/*  251 */                 b1.setType(Material.SLIME_BLOCK);
/*      */                 
/*  253 */                 loc.setX(loc.getX() - 1.0D);
/*  254 */                 b1 = loc.getBlock();
/*  255 */                 b1.setType(Material.PISTON_STICKY_BASE);
/*  256 */                 b1.setData((byte)3);
/*      */                 
/*  258 */                 loc.setY(loc.getY() - 1.0D);
/*  259 */                 b1 = loc.getBlock();
/*  260 */                 b1.setType(Material.PISTON_BASE);
/*  261 */                 b1.setData((byte)2);
/*      */                 
/*  263 */                 loc.setZ(loc.getZ() + 1.0D);
/*  264 */                 b1 = loc.getBlock();
/*  265 */                 b1.setType(Material.TNT);
/*      */                 
/*  267 */                 loc.setZ(loc.getZ() + 1.0D);
/*  268 */                 b1 = loc.getBlock();
/*  269 */                 b1.setType(Material.SLIME_BLOCK);
/*      */                 
/*  271 */                 loc.setY(loc.getY() + 1.0D);
/*  272 */                 b1 = loc.getBlock();
/*  273 */                 b1.setType(Material.SLIME_BLOCK);
/*      */                 
/*  275 */                 loc.setZ(loc.getZ() - 1.0D);
/*  276 */                 b1 = loc.getBlock();
/*  277 */                 b1.setType(Material.SLIME_BLOCK);
/*      */                 
/*  279 */                 loc.setZ(loc.getZ() - 3.0D);
/*  280 */                 b1 = loc.getBlock();
/*  281 */                 b1.setType(Material.REDSTONE_BLOCK);
/*      */                 
/*  283 */                 loc.setZ(loc.getZ() - 1.0D);
/*  284 */                 b1 = loc.getBlock();
/*  285 */                 b1.setType(Material.STAINED_GLASS);
/*      */                 
/*      */ 
/*  288 */                 loc.setZ(loc.getZ() + 1.0D);
/*  289 */                 loc.setY(loc.getY() - 1.0D);
/*  290 */                 b1 = loc.getBlock();
/*  291 */                 b1.setType(Material.SLIME_BLOCK);
/*      */                 
/*  293 */                 loc.setZ(loc.getZ() - 1.0D);
/*  294 */                 b1 = loc.getBlock();
/*  295 */                 b1.setType(Material.TNT);
/*      */                 
/*  297 */                 loc.setZ(loc.getZ() - 1.0D);
/*  298 */                 b1 = loc.getBlock();
/*  299 */                 b1.setType(Material.TNT);
/*      */                 
/*  301 */                 loc.setY(loc.getY() + 1.0D);
/*  302 */                 b1 = loc.getBlock();
/*  303 */                 b1.setType(Material.PISTON_BASE);
/*  304 */                 b1.setData((byte)2);
/*      */                 
/*  306 */                 loc.setX(loc.getX() + 1.0D);
/*  307 */                 b1 = loc.getBlock();
/*  308 */                 b1.setType(Material.REDSTONE_BLOCK);
/*      */                 
/*  310 */                 loc.setZ(loc.getZ() + 1.0D);
/*  311 */                 b1 = loc.getBlock();
/*  312 */                 b1.setType(Material.STAINED_GLASS);
/*      */                 
/*  314 */                 loc.setZ(loc.getZ() + 1.0D);
/*  315 */                 b1 = loc.getBlock();
/*  316 */                 b1.setType(Material.STAINED_GLASS);
/*      */                 
/*  318 */                 loc.setY(loc.getY() - 1.0D);
/*  319 */                 b1 = loc.getBlock();
/*  320 */                 b1.setType(Material.TNT);
/*      */                 
/*  322 */                 loc.setZ(loc.getZ() - 1.0D);
/*  323 */                 b1 = loc.getBlock();
/*  324 */                 b1.setType(Material.TNT);
/*      */                 
/*  326 */                 loc.setZ(loc.getZ() - 2.0D);
/*  327 */                 b1 = loc.getBlock();
/*  328 */                 b1.setType(Material.STAINED_GLASS);
/*      */                 
/*  330 */                 loc.setX(loc.getX() - 1.0D);
/*  331 */                 b1 = loc.getBlock();
/*  332 */                 b1.setType(Material.SLIME_BLOCK);
/*      */                 
/*  334 */                 loc.setY(loc.getY() + 1.0D);
/*  335 */                 loc.setZ(loc.getZ() - 1.0D);
/*  336 */                 b1 = loc.getBlock();
/*  337 */                 b1.setType(Material.TNT);
/*      */                 
/*  339 */                 loc.setZ(loc.getZ() - 1.0D);
/*  340 */                 b1 = loc.getBlock();
/*  341 */                 b1.setType(Material.SLIME_BLOCK);
/*      */                 
/*  343 */                 loc.setY(loc.getY() - 1.0D);
/*  344 */                 b1 = loc.getBlock();
/*  345 */                 b1.setType(Material.TNT);
/*      */                 
/*  347 */                 loc.setZ(loc.getZ() - 1.0D);
/*  348 */                 b1 = loc.getBlock();
/*  349 */                 b1.setType(Material.TNT);
/*      */                 
/*  351 */                 loc.setZ(loc.getZ() - 1.0D);
/*  352 */                 b1 = loc.getBlock();
/*  353 */                 b1.setType(Material.TNT);
/*      */                 
/*  355 */                 loc.setY(loc.getY() + 1.0D);
/*  356 */                 b1 = loc.getBlock();
/*  357 */                 b1.setType(Material.TNT);
/*      */                 
/*  359 */                 loc.setZ(loc.getZ() + 1.0D);
/*  360 */                 b1 = loc.getBlock();
/*  361 */                 b1.setType(Material.TNT);
/*      */                 
/*  363 */                 loc.setX(loc.getX() + 1.0D);
/*  364 */                 b1 = loc.getBlock();
/*  365 */                 b1.setType(Material.TNT);
/*      */                 
/*  367 */                 loc.setZ(loc.getZ() + 1.0D);
/*  368 */                 b1 = loc.getBlock();
/*  369 */                 b1.setType(Material.TNT);
/*      */                 
/*  371 */                 loc.setY(loc.getY() - 1.0D);
/*  372 */                 b1 = loc.getBlock();
/*  373 */                 b1.setType(Material.TNT);
/*      */                 
/*  375 */                 loc.setZ(loc.getZ() + 1.0D);
/*  376 */                 b1 = loc.getBlock();
/*  377 */                 b1.setType(Material.TNT);
/*      */                 
/*  379 */                 loc.setZ(loc.getZ() - 4.0D);
/*  380 */                 b1 = loc.getBlock();
/*  381 */                 b1.setType(Material.TNT);
/*      */                 
/*  383 */                 loc.setY(loc.getY() + 1.0D);
/*  384 */                 b1 = loc.getBlock();
/*  385 */                 b1.setType(Material.SLIME_BLOCK);
/*      */                 
/*      */ 
/*      */ 
/*  389 */                 Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*      */                 {
/*      */ 
/*      */                   public void run()
/*      */                   {
/*      */ 
/*  395 */                     loc.setY(loc.getY() - 1.0D);
/*  396 */                     loc.setZ(loc.getZ() + 12.0D);
/*  397 */                     loc.setX(loc.getX() + 1.0D);
/*      */                     
/*      */ 
/*  400 */                     Block b1 = loc.getBlock();
/*  401 */                     b1.setType(Material.WALL_SIGN);
/*  402 */                     b1.setData((byte)5);
/*      */                     
/*      */                     try
/*      */                     {
/*  406 */                       Sign sign = (Sign)b1.getLocation().getBlock().getState();
/*      */                       
/*  408 */                       sign.setLine(0, "§6TNTWars");
/*  409 */                       sign.setLine(1, "TNTMissle Cruiser");
/*  410 */                       sign.setLine(2, "§a§nBreak me!");
/*  411 */                       sign.setLine(3, "1");
/*  412 */                       sign.update();
/*      */                     }
/*      */                     catch (Exception localException) {}
/*      */                     
/*  416 */                     loc.setZ(loc.getZ() + 1.0D);
/*  417 */                     loc.setX(loc.getX() - 1.0D);
/*  418 */                     b1 = loc.getBlock();
/*  419 */                     b1.setType(Material.WALL_SIGN);
/*  420 */                     b1.setData((byte)3);
/*      */                     
/*      */                     try
/*      */                     {
/*  424 */                       Sign sign = (Sign)b1.getLocation().getBlock().getState();
/*      */                       
/*  426 */                       sign.setLine(0, "§6TNTWars");
/*  427 */                       sign.setLine(1, "TNTMissle Cruiser");
/*  428 */                       sign.setLine(2, "§a§nBreak me!");
/*  429 */                       sign.setLine(3, "2");
/*  430 */                       sign.update();
/*      */                     }
/*      */                     catch (Exception localException1) {}
/*      */                     
/*  434 */                     loc.setZ(loc.getZ() - 1.0D);
/*  435 */                     loc.setX(loc.getX() + 1.0D);
/*      */                     
/*      */ 
/*  438 */                     loc.setZ(loc.getZ() - 3.0D);
/*  439 */                     loc.setX(loc.getX() - 1.0D);
/*  440 */                     b1 = loc.getBlock();
/*  441 */                     b1.setType(Material.AIR);
/*      */                     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  447 */                     if (p.getItemInHand().getAmount() < 2) {
/*  448 */                       if (e.getItem().getDurability() == 93) { ItemStack[] arrayOfItemStack;
/*  449 */                         int j = (arrayOfItemStack = p.getInventory().getContents()).length; for (int i = 0; i < j; i++) { ItemStack current = arrayOfItemStack[i];
/*      */                           try {
/*  451 */                             if ((current.getType() != null) && 
/*  452 */                               (current.getType() == Material.MONSTER_EGG) && 
/*  453 */                               (current.getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "TNTMissle")) && 
/*  454 */                               (current.getDurability() == 93) && 
/*  455 */                               (current.getAmount() < 2)) {
/*  456 */                               p.getInventory().removeItem(new ItemStack[] { current });
/*      */                             }
/*      */                             
/*      */ 
/*      */                           }
/*      */                           catch (NullPointerException localNullPointerException) {}
/*      */                         }
/*      */                         
/*      */                       }
/*      */                     }
/*      */                     else {
/*  467 */                       p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
/*      */                     }
/*      */                     
/*      */                   }
/*      */                   
/*  472 */                 }, 2L);
/*      */                 
/*      */ 
/*  475 */                 p.sendMessage("§6Missle made by §aCubehamster §6on §cYouTube!");
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*  480 */               if (HimmelsRichtung.getDirection(p).equalsIgnoreCase("O")) {
/*  481 */                 final Location loc = e.getClickedBlock().getLocation();
/*      */                 
/*  483 */                 loc.setX(loc.getX() + 2.0D);
/*  484 */                 loc.setY(loc.getY() + 3.0D);
/*      */                 
/*  486 */                 Block b = loc.getBlock();
/*  487 */                 b.setType(Material.PISTON_BASE);
/*  488 */                 b.setData((byte)4);
/*      */                 
/*  490 */                 loc.setY(loc.getY() - 1.0D);
/*  491 */                 b = loc.getBlock();
/*  492 */                 b.setType(Material.PISTON_BASE);
/*  493 */                 b.setData((byte)5);
/*      */                 
/*  495 */                 loc.setX(loc.getX() + 1.0D);
/*  496 */                 b = loc.getBlock();
/*  497 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  499 */                 loc.setY(loc.getY() + 1.0D);
/*  500 */                 b = loc.getBlock();
/*  501 */                 b.setType(Material.REDSTONE_BLOCK);
/*      */                 
/*  503 */                 loc.setX(loc.getX() - 1.0D);
/*      */                 
/*      */ 
/*  506 */                 loc.setZ(loc.getZ() - 1.0D);
/*  507 */                 b = loc.getBlock();
/*  508 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  510 */                 loc.setY(loc.getY() - 1.0D);
/*  511 */                 b = loc.getBlock();
/*  512 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  514 */                 loc.setX(loc.getX() + 1.0D);
/*  515 */                 b = loc.getBlock();
/*  516 */                 b.setType(Material.TNT);
/*      */                 
/*  518 */                 loc.setY(loc.getY() + 1.0D);
/*  519 */                 b = loc.getBlock();
/*  520 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  522 */                 loc.setX(loc.getX() + 1.0D);
/*  523 */                 b = loc.getBlock();
/*  524 */                 b.setType(Material.PISTON_STICKY_BASE);
/*  525 */                 b.setData((byte)4);
/*      */                 
/*  527 */                 loc.setY(loc.getY() - 1.0D);
/*  528 */                 b = loc.getBlock();
/*  529 */                 b.setType(Material.PISTON_BASE);
/*  530 */                 b.setData((byte)5);
/*      */                 
/*  532 */                 loc.setZ(loc.getZ() + 1.0D);
/*  533 */                 loc.setY(loc.getY() + 1.0D);
/*  534 */                 b = loc.getBlock();
/*  535 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  537 */                 loc.setY(loc.getY() - 1.0D);
/*  538 */                 b = loc.getBlock();
/*  539 */                 b.setType(Material.TNT);
/*      */                 
/*  541 */                 loc.setX(loc.getX() + 1.0D);
/*  542 */                 b = loc.getBlock();
/*  543 */                 b.setType(Material.FURNACE);
/*      */                 
/*  545 */                 loc.setY(loc.getY() + 1.0D);
/*  546 */                 b = loc.getBlock();
/*  547 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  549 */                 loc.setX(loc.getX() + 1.0D);
/*  550 */                 b = loc.getBlock();
/*  551 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  553 */                 loc.setY(loc.getY() - 1.0D);
/*  554 */                 b = loc.getBlock();
/*  555 */                 b.setType(Material.TNT);
/*      */                 
/*  557 */                 loc.setZ(loc.getZ() - 1.0D);
/*  558 */                 b = loc.getBlock();
/*  559 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  561 */                 loc.setY(loc.getY() + 1.0D);
/*  562 */                 b = loc.getBlock();
/*  563 */                 b.setType(Material.REDSTONE_BLOCK);
/*      */                 
/*  565 */                 loc.setX(loc.getX() + 1.0D);
/*  566 */                 b = loc.getBlock();
/*  567 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  569 */                 loc.setY(loc.getY() - 1.0D);
/*  570 */                 b = loc.getBlock();
/*  571 */                 b.setType(Material.TNT);
/*      */                 
/*  573 */                 loc.setZ(loc.getZ() + 1.0D);
/*  574 */                 b = loc.getBlock();
/*  575 */                 b.setType(Material.TNT);
/*      */                 
/*  577 */                 loc.setY(loc.getY() + 1.0D);
/*  578 */                 b = loc.getBlock();
/*  579 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  581 */                 loc.setX(loc.getX() + 1.0D);
/*  582 */                 b = loc.getBlock();
/*  583 */                 b.setType(Material.REDSTONE_BLOCK);
/*      */                 
/*  585 */                 loc.setZ(loc.getZ() - 1.0D);
/*  586 */                 b = loc.getBlock();
/*  587 */                 b.setType(Material.PISTON_BASE);
/*  588 */                 b.setData((byte)5);
/*      */                 
/*  590 */                 loc.setY(loc.getY() - 1.0D);
/*  591 */                 b = loc.getBlock();
/*  592 */                 b.setType(Material.TNT);
/*      */                 
/*  594 */                 loc.setX(loc.getX() + 1.0D);
/*  595 */                 b = loc.getBlock();
/*  596 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  598 */                 loc.setZ(loc.getZ() + 1.0D);
/*  599 */                 b = loc.getBlock();
/*  600 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  602 */                 loc.setX(loc.getX() + 1.0D);
/*  603 */                 b = loc.getBlock();
/*  604 */                 b.setType(Material.TNT);
/*      */                 
/*  606 */                 loc.setZ(loc.getZ() - 1.0D);
/*  607 */                 loc.setY(loc.getY() + 1.0D);
/*  608 */                 b = loc.getBlock();
/*  609 */                 b.setType(Material.TNT);
/*      */                 
/*  611 */                 loc.setX(loc.getX() + 1.0D);
/*  612 */                 b = loc.getBlock();
/*  613 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  615 */                 loc.setY(loc.getY() - 1.0D);
/*  616 */                 b = loc.getBlock();
/*  617 */                 b.setType(Material.TNT);
/*      */                 
/*  619 */                 loc.setX(loc.getX() + 1.0D);
/*  620 */                 b = loc.getBlock();
/*  621 */                 b.setType(Material.TNT);
/*      */                 
/*  623 */                 loc.setY(loc.getY() + 1.0D);
/*  624 */                 b = loc.getBlock();
/*  625 */                 b.setType(Material.TNT);
/*      */                 
/*  627 */                 loc.setX(loc.getX() + 1.0D);
/*  628 */                 b = loc.getBlock();
/*  629 */                 b.setType(Material.TNT);
/*      */                 
/*  631 */                 loc.setY(loc.getY() - 1.0D);
/*  632 */                 b = loc.getBlock();
/*  633 */                 b.setType(Material.TNT);
/*      */                 
/*  635 */                 loc.setZ(loc.getZ() + 1.0D);
/*  636 */                 b = loc.getBlock();
/*  637 */                 b.setType(Material.TNT);
/*      */                 
/*  639 */                 loc.setY(loc.getY() + 1.0D);
/*  640 */                 b = loc.getBlock();
/*  641 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  643 */                 loc.setX(loc.getX() - 1.0D);
/*  644 */                 b = loc.getBlock();
/*  645 */                 b.setType(Material.TNT);
/*      */                 
/*  647 */                 loc.setX(loc.getX() - 1.0D);
/*  648 */                 b = loc.getBlock();
/*  649 */                 b.setType(Material.TNT);
/*      */                 
/*  651 */                 loc.setY(loc.getY() - 1.0D);
/*  652 */                 b = loc.getBlock();
/*  653 */                 b.setType(Material.TNT);
/*      */                 
/*  655 */                 Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*      */                 {
/*      */ 
/*      */                   public void run()
/*      */                   {
/*  660 */                     loc.setX(loc.getX() - 9.0D);
/*  661 */                     loc.setZ(loc.getZ() + 1.0D);
/*  662 */                     Block b = loc.getBlock();
/*  663 */                     b.setType(Material.WALL_SIGN);
/*  664 */                     b.setData((byte)3);
/*      */                     
/*      */                     try
/*      */                     {
/*  668 */                       Sign sign = (Sign)b.getLocation().getBlock().getState();
/*      */                       
/*  670 */                       sign.setLine(0, "§6TNTWars");
/*  671 */                       sign.setLine(1, "TNTMissle Cruiser");
/*  672 */                       sign.setLine(2, "§a§nBreak me!");
/*  673 */                       sign.setLine(3, "5");
/*  674 */                       sign.update();
/*      */                     }
/*      */                     catch (Exception localException) {}
/*      */                     
/*  678 */                     loc.setX(loc.getX() - 1.0D);
/*  679 */                     loc.setZ(loc.getZ() - 1.0D);
/*  680 */                     b = loc.getBlock();
/*  681 */                     b.setType(Material.WALL_SIGN);
/*  682 */                     b.setData((byte)4);
/*      */                     
/*      */                     try
/*      */                     {
/*  686 */                       Sign sign = (Sign)b.getLocation().getBlock().getState();
/*      */                       
/*  688 */                       sign.setLine(0, "§6TNTWars");
/*  689 */                       sign.setLine(1, "TNTMissle Cruiser");
/*  690 */                       sign.setLine(2, "§a§nBreak me!");
/*  691 */                       sign.setLine(3, "6");
/*  692 */                       sign.update();
/*      */                     }
/*      */                     catch (Exception localException1) {}
/*      */                     
/*      */ 
/*  697 */                     loc.setX(loc.getX() + 1.0D);
/*  698 */                     loc.setX(loc.getX() + 3.0D);
/*  699 */                     b = loc.getBlock();
/*  700 */                     b.setType(Material.AIR);
/*      */                     
/*      */ 
/*      */ 
/*  704 */                     if (p.getItemInHand().getAmount() < 2) {
/*  705 */                       if (e.getItem().getDurability() == 93) { ItemStack[] arrayOfItemStack;
/*  706 */                         int j = (arrayOfItemStack = p.getInventory().getContents()).length; for (int i = 0; i < j; i++) { ItemStack current = arrayOfItemStack[i];
/*      */                           try {
/*  708 */                             if ((current.getType() != null) && 
/*  709 */                               (current.getType() == Material.MONSTER_EGG) && 
/*  710 */                               (current.getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "TNTMissle")) && 
/*  711 */                               (current.getDurability() == 93) && 
/*  712 */                               (current.getAmount() < 2)) {
/*  713 */                               p.getInventory().removeItem(new ItemStack[] { current });
/*      */                             }
/*      */                             
/*      */ 
/*      */                           }
/*      */                           catch (NullPointerException localNullPointerException) {}
/*      */                         }
/*      */                         
/*      */                       }
/*      */                     }
/*      */                     else {
/*  724 */                       p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
/*      */                     }
/*      */                     
/*      */                   }
/*      */                   
/*  729 */                 }, 2L);
/*      */                 
/*  731 */                 p.sendMessage("§6Missle made by §aCubehamster §6on §cYouTube!");
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*  737 */               if (HimmelsRichtung.getDirection(p).equalsIgnoreCase("S"))
/*      */               {
/*  739 */                 final Location loc = e.getClickedBlock().getLocation();
/*      */                 
/*  741 */                 loc.setY(loc.getY() + 3.0D);
/*  742 */                 loc.setZ(loc.getZ() + 2.0D);
/*      */                 
/*  744 */                 Block b = loc.getBlock();
/*  745 */                 b.setType(Material.PISTON_BASE);
/*  746 */                 b.setData((byte)2);
/*      */                 
/*  748 */                 loc.setY(loc.getY() - 1.0D);
/*  749 */                 b = loc.getBlock();
/*  750 */                 b.setType(Material.PISTON_BASE);
/*  751 */                 b.setData((byte)3);
/*      */                 
/*  753 */                 loc.setZ(loc.getZ() + 1.0D);
/*  754 */                 b = loc.getBlock();
/*  755 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  757 */                 loc.setY(loc.getY() + 1.0D);
/*  758 */                 b = loc.getBlock();
/*  759 */                 b.setType(Material.REDSTONE_BLOCK);
/*      */                 
/*  761 */                 loc.setZ(loc.getZ() + 1.0D);
/*  762 */                 b = loc.getBlock();
/*  763 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  765 */                 loc.setY(loc.getY() - 1.0D);
/*  766 */                 b = loc.getBlock();
/*  767 */                 b.setType(Material.TNT);
/*      */                 
/*  769 */                 loc.setZ(loc.getZ() + 1.0D);
/*  770 */                 b = loc.getBlock();
/*  771 */                 b.setType(Material.FURNACE);
/*      */                 
/*  773 */                 loc.setY(loc.getY() + 1.0D);
/*  774 */                 b = loc.getBlock();
/*  775 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  777 */                 loc.setZ(loc.getZ() + 1.0D);
/*  778 */                 b = loc.getBlock();
/*  779 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  781 */                 loc.setY(loc.getY() - 1.0D);
/*  782 */                 b = loc.getBlock();
/*  783 */                 b.setType(Material.TNT);
/*      */                 
/*  785 */                 loc.setZ(loc.getZ() + 1.0D);
/*  786 */                 b = loc.getBlock();
/*  787 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  789 */                 loc.setY(loc.getY() + 1.0D);
/*  790 */                 b = loc.getBlock();
/*  791 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  793 */                 loc.setX(loc.getX() + 1.0D);
/*  794 */                 b = loc.getBlock();
/*  795 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  797 */                 loc.setY(loc.getY() - 1.0D);
/*  798 */                 b = loc.getBlock();
/*  799 */                 b.setType(Material.TNT);
/*      */                 
/*  801 */                 loc.setZ(loc.getZ() - 1.0D);
/*  802 */                 b = loc.getBlock();
/*  803 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  805 */                 loc.setY(loc.getY() + 1.0D);
/*  806 */                 b = loc.getBlock();
/*  807 */                 b.setType(Material.REDSTONE_BLOCK);
/*      */                 
/*  809 */                 loc.setZ(loc.getZ() - 2.0D);
/*  810 */                 b = loc.getBlock();
/*  811 */                 b.setType(Material.PISTON_STICKY_BASE);
/*  812 */                 b.setData((byte)2);
/*      */                 
/*  814 */                 loc.setY(loc.getY() - 1.0D);
/*  815 */                 b = loc.getBlock();
/*  816 */                 b.setType(Material.PISTON_BASE);
/*  817 */                 b.setData((byte)3);
/*      */                 
/*  819 */                 loc.setZ(loc.getZ() - 1.0D);
/*  820 */                 b = loc.getBlock();
/*  821 */                 b.setType(Material.TNT);
/*      */                 
/*  823 */                 loc.setY(loc.getY() + 1.0D);
/*  824 */                 b = loc.getBlock();
/*  825 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  827 */                 loc.setZ(loc.getZ() - 1.0D);
/*  828 */                 b = loc.getBlock();
/*  829 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  831 */                 loc.setY(loc.getY() - 1.0D);
/*  832 */                 b = loc.getBlock();
/*  833 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  835 */                 loc.setZ(loc.getZ() + 6.0D);
/*  836 */                 b = loc.getBlock();
/*  837 */                 b.setType(Material.TNT);
/*      */                 
/*  839 */                 loc.setY(loc.getY() + 1.0D);
/*  840 */                 b = loc.getBlock();
/*  841 */                 b.setType(Material.PISTON_BASE);
/*  842 */                 b.setData((byte)3);
/*      */                 
/*  844 */                 loc.setX(loc.getX() - 1.0D);
/*  845 */                 b = loc.getBlock();
/*  846 */                 b.setType(Material.REDSTONE_BLOCK);
/*      */                 
/*  848 */                 loc.setZ(loc.getZ() + 1.0D);
/*  849 */                 loc.setY(loc.getY() - 1.0D);
/*  850 */                 b = loc.getBlock();
/*  851 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/*  853 */                 loc.setZ(loc.getZ() + 1.0D);
/*  854 */                 b = loc.getBlock();
/*  855 */                 b.setType(Material.TNT);
/*      */                 
/*  857 */                 loc.setZ(loc.getZ() + 1.0D);
/*  858 */                 b = loc.getBlock();
/*  859 */                 b.setType(Material.TNT);
/*      */                 
/*  861 */                 loc.setY(loc.getY() + 1.0D);
/*  862 */                 b = loc.getBlock();
/*  863 */                 b.setType(Material.TNT);
/*      */                 
/*  865 */                 loc.setZ(loc.getZ() + 1.0D);
/*  866 */                 b = loc.getBlock();
/*  867 */                 b.setType(Material.TNT);
/*      */                 
/*  869 */                 loc.setZ(loc.getZ() + 1.0D);
/*  870 */                 b = loc.getBlock();
/*  871 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  873 */                 loc.setY(loc.getY() - 1.0D);
/*  874 */                 b = loc.getBlock();
/*  875 */                 b.setType(Material.TNT);
/*      */                 
/*  877 */                 loc.setX(loc.getX() + 1.0D);
/*  878 */                 b = loc.getBlock();
/*  879 */                 b.setType(Material.TNT);
/*      */                 
/*  881 */                 loc.setY(loc.getY() + 1.0D);
/*  882 */                 b = loc.getBlock();
/*  883 */                 b.setType(Material.TNT);
/*      */                 
/*  885 */                 loc.setZ(loc.getZ() - 1.0D);
/*  886 */                 b = loc.getBlock();
/*  887 */                 b.setType(Material.TNT);
/*      */                 
/*  889 */                 loc.setY(loc.getY() - 1.0D);
/*  890 */                 b = loc.getBlock();
/*  891 */                 b.setType(Material.TNT);
/*      */                 
/*  893 */                 loc.setZ(loc.getZ() - 1.0D);
/*  894 */                 b = loc.getBlock();
/*  895 */                 b.setType(Material.TNT);
/*      */                 
/*  897 */                 loc.setY(loc.getY() + 1.0D);
/*  898 */                 b = loc.getBlock();
/*  899 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*  901 */                 loc.setZ(loc.getZ() - 1.0D);
/*  902 */                 b = loc.getBlock();
/*  903 */                 b.setType(Material.TNT);
/*      */                 
/*  905 */                 loc.setZ(loc.getZ() - 1.0D);
/*  906 */                 loc.setY(loc.getY() - 1.0D);
/*  907 */                 b = loc.getBlock();
/*  908 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/*      */ 
/*  911 */                 Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*      */                 {
/*      */ 
/*      */                   public void run()
/*      */                   {
/*  916 */                     loc.setX(loc.getX() - 2.0D);
/*  917 */                     loc.setZ(loc.getZ() - 7.0D);
/*  918 */                     Block b = loc.getBlock();
/*  919 */                     b.setType(Material.WALL_SIGN);
/*  920 */                     b.setData((byte)4);
/*      */                     
/*      */ 
/*      */                     try
/*      */                     {
/*  925 */                       Sign sign = (Sign)b.getLocation().getBlock().getState();
/*      */                       
/*  927 */                       sign.setLine(0, "§6TNTWars");
/*  928 */                       sign.setLine(1, "TNTMissle Cruiser");
/*  929 */                       sign.setLine(2, "§a§nBreak me!");
/*  930 */                       sign.setLine(3, "7");
/*  931 */                       sign.update();
/*      */                     }
/*      */                     catch (Exception localException) {}
/*      */                     
/*  935 */                     loc.setX(loc.getX() + 1.0D);
/*  936 */                     loc.setZ(loc.getZ() - 1.0D);
/*  937 */                     b = loc.getBlock();
/*  938 */                     b.setType(Material.WALL_SIGN);
/*  939 */                     b.setData((byte)1);
/*      */                     
/*      */                     try
/*      */                     {
/*  943 */                       Sign sign = (Sign)b.getLocation().getBlock().getState();
/*      */                       
/*  945 */                       sign.setLine(0, "§6TNTWars");
/*  946 */                       sign.setLine(1, "TNTMissle Cruiser");
/*  947 */                       sign.setLine(2, "§a§nBreak me!");
/*  948 */                       sign.setLine(3, "8");
/*  949 */                       sign.update();
/*      */                     }
/*      */                     catch (Exception localException1) {}
/*      */                     
/*  953 */                     loc.setZ(loc.getZ() + 4.0D);
/*  954 */                     b = loc.getBlock();
/*  955 */                     b.setType(Material.AIR);
/*      */                     
/*      */ 
/*      */ 
/*  959 */                     if (p.getItemInHand().getAmount() < 2) {
/*  960 */                       if (e.getItem().getDurability() == 93) { ItemStack[] arrayOfItemStack;
/*  961 */                         int j = (arrayOfItemStack = p.getInventory().getContents()).length; for (int i = 0; i < j; i++) { ItemStack current = arrayOfItemStack[i];
/*      */                           try {
/*  963 */                             if ((current.getType() != null) && 
/*  964 */                               (current.getType() == Material.MONSTER_EGG) && 
/*  965 */                               (current.getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "TNTMissle")) && 
/*  966 */                               (current.getDurability() == 93) && 
/*  967 */                               (current.getAmount() < 2)) {
/*  968 */                               p.getInventory().removeItem(new ItemStack[] { current });
/*      */                             }
/*      */                             
/*      */ 
/*      */                           }
/*      */                           catch (NullPointerException localNullPointerException) {}
/*      */                         }
/*      */                         
/*      */                       }
/*      */                     }
/*      */                     else {
/*  979 */                       p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
/*      */                     }
/*      */                     
/*      */                   }
/*      */                   
/*  984 */                 }, 2L);
/*      */                 
/*      */ 
/*  987 */                 p.sendMessage("§6Missle made by §aCubehamster §6on §cYouTube!");
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*  993 */               if ((HimmelsRichtung.getDirection(p).equalsIgnoreCase("W")) || (HimmelsRichtung.getDirection(p).equalsIgnoreCase("NW")))
/*      */               {
/*  995 */                 final Location loc = e.getClickedBlock().getLocation();
/*      */                 
/*  997 */                 loc.setX(loc.getX() - 2.0D);
/*  998 */                 loc.setY(loc.getY() + 3.0D);
/*      */                 
/* 1000 */                 Block b = loc.getBlock();
/* 1001 */                 b.setType(Material.PISTON_BASE);
/* 1002 */                 b.setData((byte)5);
/*      */                 
/* 1004 */                 loc.setZ(loc.getZ() + 1.0D);
/* 1005 */                 b = loc.getBlock();
/* 1006 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/* 1008 */                 loc.setY(loc.getY() - 1.0D);
/* 1009 */                 b = loc.getBlock();
/* 1010 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/* 1012 */                 loc.setZ(loc.getZ() - 1.0D);
/* 1013 */                 b = loc.getBlock();
/* 1014 */                 b.setType(Material.PISTON_BASE);
/* 1015 */                 b.setData((byte)4);
/*      */                 
/* 1017 */                 loc.setX(loc.getX() - 1.0D);
/* 1018 */                 b = loc.getBlock();
/* 1019 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/* 1021 */                 loc.setX(loc.getX() - 1.0D);
/* 1022 */                 b = loc.getBlock();
/* 1023 */                 b.setType(Material.TNT);
/*      */                 
/* 1025 */                 loc.setX(loc.getX() - 1.0D);
/* 1026 */                 b = loc.getBlock();
/* 1027 */                 b.setType(Material.FURNACE);
/*      */                 
/* 1029 */                 loc.setY(loc.getY() + 1.0D);
/* 1030 */                 b = loc.getBlock();
/* 1031 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/* 1033 */                 loc.setX(loc.getX() + 1.0D);
/* 1034 */                 b = loc.getBlock();
/* 1035 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/* 1037 */                 loc.setX(loc.getX() + 1.0D);
/* 1038 */                 b = loc.getBlock();
/* 1039 */                 b.setType(Material.REDSTONE_BLOCK);
/*      */                 
/* 1041 */                 loc.setZ(loc.getZ() + 1.0D);
/* 1042 */                 b = loc.getBlock();
/* 1043 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/* 1045 */                 loc.setY(loc.getY() - 1.0D);
/* 1046 */                 b = loc.getBlock();
/* 1047 */                 b.setType(Material.TNT);
/*      */                 
/* 1049 */                 loc.setX(loc.getX() - 1.0D);
/* 1050 */                 b = loc.getBlock();
/* 1051 */                 b.setType(Material.PISTON_BASE);
/* 1052 */                 b.setData((byte)4);
/*      */                 
/* 1054 */                 loc.setY(loc.getY() + 1.0D);
/* 1055 */                 b = loc.getBlock();
/* 1056 */                 b.setType(Material.PISTON_STICKY_BASE);
/* 1057 */                 b.setData((byte)5);
/*      */                 
/* 1059 */                 loc.setY(loc.getY() - 1.0D);
/* 1060 */                 loc.setX(loc.getX() - 2.0D);
/* 1061 */                 b = loc.getBlock();
/* 1062 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/* 1064 */                 loc.setY(loc.getY() + 1.0D);
/* 1065 */                 b = loc.getBlock();
/* 1066 */                 b.setType(Material.REDSTONE_BLOCK);
/*      */                 
/* 1068 */                 loc.setX(loc.getX() - 1.0D);
/* 1069 */                 b = loc.getBlock();
/* 1070 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/* 1072 */                 loc.setY(loc.getY() - 1.0D);
/* 1073 */                 b = loc.getBlock();
/* 1074 */                 b.setType(Material.TNT);
/*      */                 
/* 1076 */                 loc.setX(loc.getX() - 1.0D);
/* 1077 */                 b = loc.getBlock();
/* 1078 */                 b.setType(Material.TNT);
/*      */                 
/* 1080 */                 loc.setY(loc.getY() + 1.0D);
/* 1081 */                 b = loc.getBlock();
/* 1082 */                 b.setType(Material.PISTON_BASE);
/* 1083 */                 b.setData((byte)4);
/*      */                 
/* 1085 */                 loc.setZ(loc.getZ() - 1.0D);
/* 1086 */                 b = loc.getBlock();
/* 1087 */                 b.setType(Material.REDSTONE_BLOCK);
/*      */                 
/* 1089 */                 loc.setX(loc.getX() + 1.0D);
/* 1090 */                 b = loc.getBlock();
/* 1091 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/* 1093 */                 loc.setX(loc.getX() + 1.0D);
/* 1094 */                 b = loc.getBlock();
/* 1095 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/* 1097 */                 loc.setY(loc.getY() - 1.0D);
/* 1098 */                 b = loc.getBlock();
/* 1099 */                 b.setType(Material.TNT);
/*      */                 
/* 1101 */                 loc.setX(loc.getX() - 1.0D);
/* 1102 */                 b = loc.getBlock();
/* 1103 */                 b.setType(Material.TNT);
/*      */                 
/* 1105 */                 loc.setX(loc.getX() - 2.0D);
/* 1106 */                 b = loc.getBlock();
/* 1107 */                 b.setType(Material.STAINED_GLASS);
/*      */                 
/* 1109 */                 loc.setZ(loc.getZ() + 1.0D);
/* 1110 */                 b = loc.getBlock();
/* 1111 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/* 1113 */                 loc.setX(loc.getX() - 1.0D);
/* 1114 */                 loc.setY(loc.getY() + 1.0D);
/* 1115 */                 b = loc.getBlock();
/* 1116 */                 b.setType(Material.TNT);
/*      */                 
/* 1118 */                 loc.setX(loc.getX() - 1.0D);
/* 1119 */                 b = loc.getBlock();
/* 1120 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/* 1122 */                 loc.setY(loc.getY() - 1.0D);
/* 1123 */                 b = loc.getBlock();
/* 1124 */                 b.setType(Material.TNT);
/*      */                 
/* 1126 */                 loc.setX(loc.getX() - 1.0D);
/* 1127 */                 b = loc.getBlock();
/* 1128 */                 b.setType(Material.TNT);
/*      */                 
/* 1130 */                 loc.setX(loc.getX() - 1.0D);
/* 1131 */                 b = loc.getBlock();
/* 1132 */                 b.setType(Material.TNT);
/*      */                 
/* 1134 */                 loc.setY(loc.getY() + 1.0D);
/* 1135 */                 b = loc.getBlock();
/* 1136 */                 b.setType(Material.TNT);
/*      */                 
/* 1138 */                 loc.setX(loc.getX() + 1.0D);
/* 1139 */                 b = loc.getBlock();
/* 1140 */                 b.setType(Material.TNT);
/*      */                 
/* 1142 */                 loc.setZ(loc.getZ() - 1.0D);
/* 1143 */                 b = loc.getBlock();
/* 1144 */                 b.setType(Material.TNT);
/*      */                 
/* 1146 */                 loc.setX(loc.getX() - 1.0D);
/* 1147 */                 b = loc.getBlock();
/* 1148 */                 b.setType(Material.SLIME_BLOCK);
/*      */                 
/* 1150 */                 loc.setY(loc.getY() - 1.0D);
/* 1151 */                 b = loc.getBlock();
/* 1152 */                 b.setType(Material.TNT);
/*      */                 
/* 1154 */                 loc.setX(loc.getX() + 2.0D);
/* 1155 */                 b = loc.getBlock();
/* 1156 */                 b.setType(Material.TNT);
/*      */                 
/* 1158 */                 loc.setY(loc.getY() + 1.0D);
/* 1159 */                 b = loc.getBlock();
/* 1160 */                 b.setType(Material.TNT);
/*      */                 
/* 1162 */                 loc.setX(loc.getX() + 1.0D);
/* 1163 */                 loc.setY(loc.getY() - 1.0D);
/* 1164 */                 b = loc.getBlock();
/* 1165 */                 b.setType(Material.TNT);
/*      */                 
/* 1167 */                 Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*      */                 {
/*      */ 
/*      */                   public void run()
/*      */                   {
/* 1172 */                     loc.setX(loc.getX() + 8.0D);
/* 1173 */                     loc.setZ(loc.getZ() - 1.0D);
/* 1174 */                     Block b = loc.getBlock();
/* 1175 */                     b.setType(Material.WALL_SIGN);
/* 1176 */                     b.setData((byte)2);
/*      */                     
/*      */                     try
/*      */                     {
/* 1180 */                       Sign sign = (Sign)b.getLocation().getBlock().getState();
/*      */                       
/* 1182 */                       sign.setLine(0, "§6TNTWars");
/* 1183 */                       sign.setLine(1, "TNTMissle Cruiser");
/* 1184 */                       sign.setLine(2, "§a§nBreak me!");
/* 1185 */                       sign.setLine(3, "3");
/* 1186 */                       sign.update();
/*      */                     }
/*      */                     catch (Exception localException) {}
/*      */                     
/* 1190 */                     loc.setX(loc.getX() + 1.0D);
/* 1191 */                     loc.setZ(loc.getZ() + 1.0D);
/* 1192 */                     b = loc.getBlock();
/* 1193 */                     b.setType(Material.WALL_SIGN);
/* 1194 */                     b.setData((byte)5);
/*      */                     
/*      */                     try
/*      */                     {
/* 1198 */                       Sign sign = (Sign)b.getLocation().getBlock().getState();
/*      */                       
/* 1200 */                       sign.setLine(0, "§6TNTWars");
/* 1201 */                       sign.setLine(1, "TNTMissle Cruiser");
/* 1202 */                       sign.setLine(2, "§a§nBreak me!");
/* 1203 */                       sign.setLine(3, "4");
/* 1204 */                       sign.update();
/*      */                     }
/*      */                     catch (Exception localException1) {}
/*      */                     
/*      */ 
/* 1209 */                     loc.setX(loc.getX() - 1.0D);
/* 1210 */                     loc.setX(loc.getX() - 3.0D);
/* 1211 */                     b = loc.getBlock();
/* 1212 */                     b.setType(Material.AIR);
/*      */                     
/*      */ 
/*      */ 
/* 1216 */                     if (p.getItemInHand().getAmount() < 2) {
/* 1217 */                       if (e.getItem().getDurability() == 93) { ItemStack[] arrayOfItemStack;
/* 1218 */                         int j = (arrayOfItemStack = p.getInventory().getContents()).length; for (int i = 0; i < j; i++) { ItemStack current = arrayOfItemStack[i];
/*      */                           try {
/* 1220 */                             if ((current.getType() != null) && 
/* 1221 */                               (current.getType() == Material.MONSTER_EGG) && 
/* 1222 */                               (current.getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "TNTMissle")) && 
/* 1223 */                               (current.getDurability() == 93) && 
/* 1224 */                               (current.getAmount() < 2)) {
/* 1225 */                               p.getInventory().removeItem(new ItemStack[] { current });
/*      */                             }
/*      */                             
/*      */ 
/*      */                           }
/*      */                           catch (NullPointerException localNullPointerException) {}
/*      */                         }
/*      */                         
/*      */                       }
/*      */                     }
/*      */                     else {
/* 1236 */                       p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
/*      */                     }
/*      */                     
/*      */                   }
/*      */                   
/* 1241 */                 }, 2L);
/*      */                 
/*      */ 
/* 1244 */                 p.sendMessage("§6Missle made by §aCubehamster §6on §cYouTube!");
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Exception localException1) {}
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onBlockPhysics(final BlockPhysicsEvent e)
/*      */   {
/* 1257 */     final Block b = e.getBlock();
/* 1258 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable() {
/*      */       public void run() {
/* 1260 */         if (b.getType() == Material.WALL_SIGN) {
/*      */           try
/*      */           {
/* 1263 */             Sign s = (Sign)e.getBlock().getState();
/* 1264 */             if ((s.getLine(0).equalsIgnoreCase("§6TNTWars")) && 
/* 1265 */               (s.getLine(1).equalsIgnoreCase("TNTMissle Cruiser")) && 
/* 1266 */               (s.getLine(2).equalsIgnoreCase("§a§nBreak me!"))) {
/* 1267 */               for (Entity ent : s.getWorld().getEntities()) {
/* 1268 */                 if ((ent instanceof Item)) {
/* 1269 */                   Item item = (Item)ent;
/* 1270 */                   if ((item.getType().equals(Material.SIGN)) && 
/* 1271 */                     (ent.getLocation().equals(s.getLocation()))) {
/* 1272 */                     ent.remove();
/*      */                   }
/*      */                   
/*      */                 }
/*      */                 
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Exception localException) {}
/*      */         }
/*      */       }
/* 1283 */     }, 1L);
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onBlockBreak(BlockBreakEvent e) {
/* 1288 */     if (e.getBlock().getType() == Material.WALL_SIGN) {
/* 1289 */       Sign sign = (Sign)e.getBlock().getState();
/* 1290 */       if ((sign.getLine(0).equalsIgnoreCase("§6TNTWars")) && 
/* 1291 */         (sign.getLine(1).equalsIgnoreCase("TNTMissle Cruiser")) && 
/* 1292 */         (sign.getLine(2).equalsIgnoreCase("§a§nBreak me!"))) {
/* 1293 */         if (sign.getLine(3).equalsIgnoreCase("1")) {
/* 1294 */           Block b = sign.getBlock();
/* 1295 */           b.setType(Material.AIR);
/* 1296 */           Location loc = b.getLocation();
/*      */           
/* 1298 */           loc.setZ(loc.getZ() + 1.0D);
/* 1299 */           loc.setX(loc.getX() - 1.0D);
/* 1300 */           b = loc.getBlock();
/* 1301 */           b.setType(Material.AIR);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1306 */         if (sign.getLine(3).equalsIgnoreCase("2")) {
/* 1307 */           Block b = sign.getBlock();
/* 1308 */           b.setType(Material.AIR);
/* 1309 */           Location loc = b.getLocation();
/*      */           
/* 1311 */           loc.setZ(loc.getZ() - 1.0D);
/* 1312 */           loc.setX(loc.getX() + 1.0D);
/* 1313 */           b = loc.getBlock();
/* 1314 */           b.setType(Material.AIR);
/*      */         }
/*      */         
/*      */ 
/* 1318 */         if (sign.getLine(3).equalsIgnoreCase("3")) {
/* 1319 */           Block b = sign.getBlock();
/* 1320 */           b.setType(Material.AIR);
/* 1321 */           Location loc = b.getLocation();
/*      */           
/* 1323 */           loc.setX(loc.getX() + 1.0D);
/* 1324 */           loc.setZ(loc.getZ() + 1.0D);
/* 1325 */           b = loc.getBlock();
/* 1326 */           b.setType(Material.AIR);
/*      */           
/* 1328 */           e.setCancelled(true);
/* 1329 */           return;
/*      */         }
/*      */         
/* 1332 */         if (sign.getLine(3).equalsIgnoreCase("4")) {
/* 1333 */           Block b = sign.getBlock();
/* 1334 */           b.setType(Material.AIR);
/* 1335 */           Location loc = b.getLocation();
/*      */           
/* 1337 */           loc.setX(loc.getX() - 1.0D);
/* 1338 */           loc.setZ(loc.getZ() - 1.0D);
/* 1339 */           b = loc.getBlock();
/* 1340 */           b.setType(Material.AIR);
/*      */           
/* 1342 */           e.setCancelled(true);
/* 1343 */           return;
/*      */         }
/*      */         
/* 1346 */         if (sign.getLine(3).equalsIgnoreCase("5")) {
/* 1347 */           Block b = sign.getBlock();
/* 1348 */           b.setType(Material.AIR);
/* 1349 */           Location loc = b.getLocation();
/*      */           
/* 1351 */           loc.setX(loc.getX() - 1.0D);
/* 1352 */           loc.setZ(loc.getZ() - 1.0D);
/* 1353 */           b = loc.getBlock();
/* 1354 */           b.setType(Material.AIR);
/*      */           
/* 1356 */           e.setCancelled(true);
/* 1357 */           return;
/*      */         }
/*      */         
/* 1360 */         if (sign.getLine(3).equalsIgnoreCase("6")) {
/* 1361 */           Block b = sign.getBlock();
/* 1362 */           b.setType(Material.AIR);
/* 1363 */           Location loc = b.getLocation();
/*      */           
/* 1365 */           loc.setX(loc.getX() + 1.0D);
/* 1366 */           loc.setZ(loc.getZ() + 1.0D);
/* 1367 */           b = loc.getBlock();
/* 1368 */           b.setType(Material.AIR);
/*      */           
/* 1370 */           e.setCancelled(true);
/* 1371 */           return;
/*      */         }
/*      */         
/* 1374 */         if (sign.getLine(3).equalsIgnoreCase("7")) {
/* 1375 */           Block b = sign.getBlock();
/* 1376 */           b.setType(Material.AIR);
/* 1377 */           Location loc = b.getLocation();
/*      */           
/* 1379 */           loc.setX(loc.getX() + 1.0D);
/* 1380 */           loc.setZ(loc.getZ() - 1.0D);
/* 1381 */           b = loc.getBlock();
/* 1382 */           b.setType(Material.AIR);
/*      */           
/* 1384 */           e.setCancelled(true);
/* 1385 */           return;
/*      */         }
/*      */         
/* 1388 */         if (sign.getLine(3).equalsIgnoreCase("8")) {
/* 1389 */           Block b = sign.getBlock();
/* 1390 */           b.setType(Material.AIR);
/* 1391 */           Location loc = b.getLocation();
/*      */           
/* 1393 */           loc.setX(loc.getX() - 1.0D);
/* 1394 */           loc.setZ(loc.getZ() + 1.0D);
/* 1395 */           b = loc.getBlock();
/* 1396 */           b.setType(Material.AIR);
/*      */           
/* 1398 */           e.setCancelled(true);
/* 1399 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\items\TNTMissle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */