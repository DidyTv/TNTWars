/*     */ package me.Mr_Coding.tntwars.items;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import me.Mr_Coding.tntwars.start.start;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class Granate implements org.bukkit.event.Listener
/*     */ {
/*     */   private Plugin plugin;
/*     */   
/*     */   public Granate(start main)
/*     */   {
/*  25 */     this.plugin = main;
/*  26 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*     */   public static void Granade(Player p, int slot, int size) {
/*  30 */     ItemStack Granate = new ItemStack(Material.FIREWORK_CHARGE);
/*  31 */     Granate.setAmount(size);
/*  32 */     ItemMeta GranateMeta = Granate.getItemMeta();
/*     */     
/*  34 */     Granate.setDurability((short)0);
/*     */     
/*  36 */     GranateMeta.setDisplayName(ChatColor.GOLD + "Granate");
/*     */     
/*  38 */     ArrayList<String> Granatelore = new ArrayList();
/*  39 */     Granatelore.add(ChatColor.LIGHT_PURPLE + "Throw it in your eyes direction!");
/*     */     
/*  41 */     GranateMeta.setLore(Granatelore);
/*  42 */     Granate.setItemMeta(GranateMeta);
/*     */     
/*  44 */     p.getInventory().setItem(slot, Granate);
/*     */   }
/*     */   
/*     */   public static void Granade(Player p, int size)
/*     */   {
/*  49 */     ItemStack Granate = new ItemStack(Material.FIREWORK_CHARGE);
/*  50 */     Granate.setAmount(size);
/*  51 */     ItemMeta GranateMeta = Granate.getItemMeta();
/*     */     
/*  53 */     Granate.setDurability((short)0);
/*     */     
/*  55 */     GranateMeta.setDisplayName(ChatColor.GOLD + "Granate");
/*     */     
/*  57 */     ArrayList<String> Granatelore = new ArrayList();
/*  58 */     Granatelore.add(ChatColor.LIGHT_PURPLE + "Throw it in your eyes direction!");
/*     */     
/*  60 */     GranateMeta.setLore(Granatelore);
/*  61 */     Granate.setItemMeta(GranateMeta);
/*     */     
/*  63 */     p.getInventory().addItem(new ItemStack[] { Granate });
/*     */   }
/*     */   
/*     */   @org.bukkit.event.EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent e)
/*     */   {
/*  69 */     Player p = e.getPlayer();
/*  70 */     if (((e.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) || (e.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_AIR)) && 
/*  71 */       (e.getMaterial() == Material.FIREWORK_CHARGE) && 
/*  72 */       (e.getItem().getItemMeta().getDisplayName() != null) && 
/*  73 */       (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "Granate")))
/*     */     {
/*  75 */       final Item FireCharge = p.getWorld().dropItem(p.getEyeLocation(), new ItemStack(Material.FIREWORK_CHARGE));
/*     */       
/*     */ 
/*  78 */       if (p.getItemInHand().getAmount() < 2) { ItemStack[] arrayOfItemStack;
/*  79 */         int j = (arrayOfItemStack = p.getInventory().getContents()).length; for (int i = 0; i < j; i++) { ItemStack current = arrayOfItemStack[i];
/*     */           try {
/*  81 */             if ((current.getType() != null) && 
/*  82 */               (current.getType() == Material.FIREWORK_CHARGE) && 
/*  83 */               (current.getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "Granate")) && 
/*  84 */               (current.getAmount() < 2)) {
/*  85 */               p.getInventory().removeItem(new ItemStack[] { current });
/*  86 */               p.updateInventory();
/*     */             }
/*     */             
/*     */           }
/*     */           catch (NullPointerException localNullPointerException) {}
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  95 */         p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
/*     */       }
/*     */       
/*  98 */       FireCharge.setVelocity(p.getLocation().getDirection().multiply(2));
/*  99 */       FireCharge.setPickupDelay(90000);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 104 */       FireCharge.getWorld().playSound(FireCharge.getLocation(), Sound.BURP, 1.0F, 10.0F);
/*     */       
/*     */ 
/* 107 */       Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 111 */           FireCharge.getWorld().playSound(FireCharge.getLocation(), Sound.BURP, 1.0F, 10.0F);
/*     */         }
/* 113 */       }, 20L);
/*     */       
/*     */ 
/* 116 */       Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 120 */           FireCharge.getWorld().playSound(FireCharge.getLocation(), Sound.BURP, 1.0F, 10.0F);
/*     */         }
/* 122 */       }, 40L);
/*     */       
/*     */ 
/* 125 */       Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 129 */           FireCharge.getWorld().playSound(FireCharge.getLocation(), Sound.BURP, 1.0F, 10.0F);
/*     */         }
/* 131 */       }, 60L);
/*     */       
/*     */ 
/* 134 */       Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 138 */           FireCharge.getWorld().createExplosion(FireCharge.getLocation(), 3.0F, false);
/* 139 */           FireCharge.remove();
/*     */         }
/* 141 */       }, 80L);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\items\Granate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */