/*     */ package me.Mr_Coding.tntwars.items;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import me.Mr_Coding.tntwars.start.HimmelsRichtung;
/*     */ import me.Mr_Coding.tntwars.start.start;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.Sign;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class TNTCanon implements org.bukkit.event.Listener
/*     */ {
/*     */   private Plugin plugin;
/*     */   int SchedTNTCanonNorden;
/*     */   
/*     */   public TNTCanon(start main)
/*     */   {
/*  32 */     this.plugin = main;
/*  33 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  39 */   private ArrayList<Player> inTNTCanon = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   public static void TNTCanon(Player p, int slot, int size)
/*     */   {
/*  45 */     ItemStack TNTCanon = new ItemStack(Material.MONSTER_EGG);
/*  46 */     TNTCanon.setAmount(size);
/*  47 */     TNTCanon.setDurability((short)93);
/*  48 */     ItemMeta TNTCanonMeta = TNTCanon.getItemMeta();
/*     */     
/*  50 */     TNTCanon.setDurability((short)0);
/*     */     
/*  52 */     TNTCanonMeta.setDisplayName(ChatColor.GOLD + "TNTCanon");
/*     */     
/*  54 */     ArrayList<String> Granadelore = new ArrayList();
/*  55 */     Granadelore.add(ChatColor.LIGHT_PURPLE + "Place it in your eyes direction!");
/*     */     
/*  57 */     TNTCanonMeta.setLore(Granadelore);
/*  58 */     TNTCanon.setItemMeta(TNTCanonMeta);
/*     */     
/*  60 */     p.getInventory().setItem(slot, TNTCanon);
/*     */   }
/*     */   
/*     */ 
/*     */   @org.bukkit.event.EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent e)
/*     */   {
/*  67 */     final Player p = e.getPlayer();
/*  68 */     if (((e.getAction() == Action.RIGHT_CLICK_BLOCK) || (e.getAction() == Action.RIGHT_CLICK_AIR)) && 
/*  69 */       (e.getMaterial() == Material.MONSTER_EGG)) {
/*     */       try {
/*  71 */         if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "TNTCanon")) {
/*  72 */           e.setCancelled(true);
/*     */           
/*  74 */           if (this.inTNTCanon.contains(p)) {
/*  75 */             p.sendMessage("§cDu kannst nur §e1 §6TNTKanone §cplatzieren!");
/*  76 */             return;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*  81 */           if (p.getItemInHand().getAmount() < 2) { ItemStack[] arrayOfItemStack;
/*  82 */             int j = (arrayOfItemStack = p.getInventory().getContents()).length; for (int i = 0; i < j; i++) { ItemStack current = arrayOfItemStack[i];
/*     */               try {
/*  84 */                 if ((current.getType() != null) && 
/*  85 */                   (current.getType() == Material.MONSTER_EGG) && 
/*  86 */                   (current.getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "TNTCanon")) && 
/*  87 */                   (current.getAmount() < 2)) {
/*  88 */                   p.getInventory().removeItem(new ItemStack[] { current });
/*  89 */                   p.updateInventory();
/*     */                 }
/*     */                 
/*     */               }
/*     */               catch (NullPointerException localNullPointerException) {}
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/*  98 */             p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
/*     */           }
/*     */           
/* 101 */           if (HimmelsRichtung.getDirection(p).equalsIgnoreCase("N")) {
/* 102 */             final Location loc = e.getClickedBlock().getLocation();
/*     */             
/*     */ 
/* 105 */             loc.setY(loc.getY() + 1.0D);
/* 106 */             Block b = loc.getBlock();
/* 107 */             b.setType(Material.SPRUCE_FENCE);
/*     */             
/* 109 */             loc.setY(loc.getY() + 1.0D);
/* 110 */             b = loc.getBlock();
/* 111 */             b.setType(Material.DISPENSER);
/* 112 */             b.setData((byte)2);
/*     */             
/*     */ 
/* 115 */             loc.setY(loc.getY() + 1.0D);
/* 116 */             b = loc.getBlock();
/* 117 */             b.setType(Material.IRON_PLATE);
/*     */             
/* 119 */             loc.setY(loc.getY() - 1.0D);
/* 120 */             loc.setX(loc.getX() - 1.0D);
/* 121 */             b = loc.getBlock();
/* 122 */             b.setType(Material.WALL_SIGN);
/* 123 */             b.setData((byte)4);
/*     */             
/* 125 */             loc.setX(loc.getX() + 2.0D);
/* 126 */             b = loc.getBlock();
/* 127 */             b.setType(Material.WALL_SIGN);
/* 128 */             b.setData((byte)5);
/*     */             
/* 130 */             loc.setX(loc.getX() - 1.0D);
/* 131 */             loc.setZ(loc.getZ() + 1.0D);
/* 132 */             b = loc.getBlock();
/* 133 */             b.setType(Material.WALL_SIGN);
/* 134 */             b.setData((byte)3);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 139 */             final Sign sign1 = (Sign)loc.getBlock().getState();
/*     */             
/* 141 */             loc.setZ(loc.getZ() - 1.0D);
/* 142 */             loc.setX(loc.getX() + 1.0D);
/* 143 */             final Sign sign2 = (Sign)loc.getBlock().getState();
/*     */             
/* 145 */             loc.setX(loc.getX() - 2.0D);
/* 146 */             final Sign sign3 = (Sign)loc.getBlock().getState();
/*     */             
/* 148 */             this.inTNTCanon.add(p);
/*     */             
/*     */ 
/* 151 */             this.SchedTNTCanonNorden = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable()
/*     */             {
/*     */               int counter;
/*     */               
/*     */ 
/*     */ 
/*     */               int counter1;
/*     */               
/*     */ 
/*     */ 
/*     */               public void run()
/*     */               {
/* 163 */                 if (this.counter1 > 36) {
/* 164 */                   Bukkit.getScheduler().cancelTask(TNTCanon.this.SchedTNTCanonNorden);
/* 165 */                   TNTCanon.this.inTNTCanon.remove(p);
/*     */                   
/* 167 */                   sign1.setLine(0, "");
/* 168 */                   sign1.setLine(1, "");
/* 169 */                   sign1.setLine(2, "");
/* 170 */                   sign1.setLine(3, "");
/* 171 */                   sign1.update();
/*     */                   
/*     */ 
/* 174 */                   sign2.setLine(0, "");
/* 175 */                   sign2.setLine(1, "");
/* 176 */                   sign2.setLine(2, "");
/* 177 */                   sign2.setLine(3, "");
/* 178 */                   sign2.update();
/*     */                   
/*     */ 
/* 181 */                   sign3.setLine(0, "");
/* 182 */                   sign3.setLine(1, "");
/* 183 */                   sign3.setLine(2, "");
/* 184 */                   sign3.setLine(3, "");
/* 185 */                   sign3.update();
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 191 */                   this.counter1 = 0;
/*     */                   
/* 193 */                   p.sendMessage("§dDeine §6TNT-Kanone §dist §ckaputt §dgeganen!");
/* 194 */                   return;
/*     */                 }
/*     */                 
/* 197 */                 if (this.counter == 3)
/*     */                 {
/* 199 */                   sign1.setLine(0, "");
/* 200 */                   sign1.setLine(2, "");
/* 201 */                   sign1.setLine(3, "");
/* 202 */                   sign1.setLine(1, "§c3");
/* 203 */                   sign1.update();
/*     */                   
/*     */ 
/* 206 */                   sign2.setLine(0, "");
/* 207 */                   sign2.setLine(2, "");
/* 208 */                   sign2.setLine(3, "");
/* 209 */                   sign2.setLine(1, "§c3");
/* 210 */                   sign2.update();
/*     */                   
/*     */ 
/* 213 */                   sign3.setLine(0, "");
/* 214 */                   sign3.setLine(2, "");
/* 215 */                   sign3.setLine(3, "");
/* 216 */                   sign3.setLine(1, "§c3");
/* 217 */                   sign3.update();
/* 218 */                 } else if (this.counter == 2)
/*     */                 {
/* 220 */                   sign1.setLine(0, "");
/* 221 */                   sign1.setLine(2, "");
/* 222 */                   sign1.setLine(3, "");
/* 223 */                   sign1.setLine(1, "§e2");
/* 224 */                   sign1.update();
/*     */                   
/*     */ 
/* 227 */                   sign2.setLine(0, "");
/* 228 */                   sign2.setLine(2, "");
/* 229 */                   sign2.setLine(3, "");
/* 230 */                   sign2.setLine(1, "§e2");
/* 231 */                   sign2.update();
/*     */                   
/*     */ 
/* 234 */                   sign3.setLine(0, "");
/* 235 */                   sign3.setLine(2, "");
/* 236 */                   sign3.setLine(3, "");
/* 237 */                   sign3.setLine(1, "§e2");
/* 238 */                   sign3.update();
/* 239 */                 } else if (this.counter == 1)
/*     */                 {
/* 241 */                   sign1.setLine(0, "");
/* 242 */                   sign1.setLine(2, "");
/* 243 */                   sign1.setLine(3, "");
/* 244 */                   sign1.setLine(1, "§a1");
/* 245 */                   sign1.update();
/*     */                   
/*     */ 
/* 248 */                   sign2.setLine(0, "");
/* 249 */                   sign2.setLine(2, "");
/* 250 */                   sign2.setLine(3, "");
/* 251 */                   sign2.setLine(1, "§a1");
/* 252 */                   sign2.update();
/*     */                   
/*     */ 
/* 255 */                   sign3.setLine(0, "");
/* 256 */                   sign3.setLine(2, "");
/* 257 */                   sign3.setLine(3, "");
/* 258 */                   sign3.setLine(1, "§a1");
/* 259 */                   sign3.update();
/*     */                 } else {
/* 261 */                   this.counter = 4;
/*     */                   
/* 263 */                   sign1.getWorld().playEffect(sign1.getLocation(), org.bukkit.Effect.EXPLOSION_HUGE, 1);
/* 264 */                   sign1.getWorld().playSound(sign1.getLocation(), org.bukkit.Sound.BLAZE_BREATH, 1.0F, 10.0F);
/*     */                   
/* 266 */                   Location loctnt = new Location(loc.getWorld(), 
/* 267 */                     loc.getX() + 1.5D, 
/* 268 */                     loc.getY(), 
/* 269 */                     loc.getZ());
/*     */                   
/* 271 */                   Entity TNT = sign1.getWorld().spawnEntity(loctnt, org.bukkit.entity.EntityType.PRIMED_TNT);
/* 272 */                   Vector v = new Vector(0.0D, 0.1D, -10.0D);
/* 273 */                   TNT.setVelocity(v);
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/* 278 */                   sign1.setLine(0, "§6GO!");
/* 279 */                   sign1.setLine(1, "§6GO!");
/* 280 */                   sign1.setLine(2, "§6GO!");
/* 281 */                   sign1.setLine(3, "§6GO!");
/* 282 */                   sign1.update();
/*     */                   
/*     */ 
/* 285 */                   sign2.setLine(0, "§6GO!");
/* 286 */                   sign2.setLine(1, "§6GO!");
/* 287 */                   sign2.setLine(2, "§6GO!");
/* 288 */                   sign2.setLine(3, "§6GO!");
/* 289 */                   sign2.update();
/*     */                   
/*     */ 
/* 292 */                   sign3.setLine(0, "§6GO!");
/* 293 */                   sign3.setLine(1, "§6GO!");
/* 294 */                   sign3.setLine(2, "§6GO!");
/* 295 */                   sign3.setLine(3, "§6GO!");
/* 296 */                   sign3.update();
/*     */                 }
/*     */                 
/* 299 */                 this.counter -= 1;
/* 300 */                 this.counter1 += 1;
/*     */               }
/*     */               
/*     */ 
/* 304 */             }, 0L, 20L);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 309 */           if (HimmelsRichtung.getDirection(p).equalsIgnoreCase("O")) {
/* 310 */             p.sendMessage(ChatColor.RED + "Osten");
/*     */           }
/*     */           
/* 313 */           if (HimmelsRichtung.getDirection(p).equalsIgnoreCase("S")) {
/* 314 */             p.sendMessage(ChatColor.RED + "Süden");
/*     */           }
/*     */           
/* 317 */           if ((HimmelsRichtung.getDirection(p).equalsIgnoreCase("W")) || (HimmelsRichtung.getDirection(p).equalsIgnoreCase("NW"))) {
/* 318 */             p.sendMessage(ChatColor.RED + "Westen");
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\items\TNTCanon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */