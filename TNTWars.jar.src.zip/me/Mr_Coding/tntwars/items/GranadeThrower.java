/*     */ package me.Mr_Coding.tntwars.items;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import me.Mr_Coding.tntwars.start.start;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class GranadeThrower implements org.bukkit.event.Listener
/*     */ {
/*     */   private start plugin;
/*     */   
/*     */   public GranadeThrower(start main)
/*     */   {
/*  26 */     this.plugin = main;
/*  27 */     this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*  30 */   private ArrayList<Player> CantThrow = new ArrayList();
/*  31 */   private HashMap<Player, Integer> CantThrowTime = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   public static void Common(Player p, int slot, int size)
/*     */   {
/*  37 */     ItemStack GranadeThrower = new ItemStack(Material.DIAMOND_SWORD);
/*  38 */     GranadeThrower.setAmount(size);
/*  39 */     ItemMeta GranadeThrowerMeta = GranadeThrower.getItemMeta();
/*     */     
/*     */ 
/*  42 */     GranadeThrowerMeta.setDisplayName("§6Normaler Granatwerfer");
/*     */     
/*  44 */     ArrayList<String> GranadeThrowerlore = new ArrayList();
/*  45 */     GranadeThrowerlore.add(ChatColor.LIGHT_PURPLE + "§66");
/*     */     
/*  47 */     GranadeThrowerMeta.setLore(GranadeThrowerlore);
/*  48 */     GranadeThrower.setItemMeta(GranadeThrowerMeta);
/*     */     
/*  50 */     p.getInventory().setItem(slot, GranadeThrower);
/*     */   }
/*     */   
/*     */   public static void Common(Player p, int size)
/*     */   {
/*  55 */     ItemStack GranadeThrower = new ItemStack(Material.DIAMOND_SWORD);
/*  56 */     GranadeThrower.setAmount(size);
/*  57 */     ItemMeta GranadeThrowerMeta = GranadeThrower.getItemMeta();
/*     */     
/*     */ 
/*  60 */     GranadeThrowerMeta.setDisplayName("§6Normaler Granatwerfer");
/*     */     
/*     */ 
/*  63 */     GranadeThrower.setItemMeta(GranadeThrowerMeta);
/*     */     
/*  65 */     p.getInventory().addItem(new ItemStack[] { GranadeThrower });
/*     */   }
/*     */   
/*     */   @org.bukkit.event.EventHandler
/*     */   public void onSpawn(PlayerInteractEvent e)
/*     */   {
/*  71 */     Player p = e.getPlayer();
/*     */     
/*  73 */     if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) || (e.getAction() == Action.RIGHT_CLICK_AIR))
/*     */     {
/*  75 */       if (e.getMaterial() == Material.DIAMOND_SWORD) {
/*     */         try {
/*  77 */           if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.GOLD + "Normaler Granatwerfer"))
/*     */           {
/*  79 */             if (this.CantThrow.contains(p)) {
/*  80 */               p.sendMessage("§2[§4TNT§6Wars§2]§d §cLädt nach... Remaining Time: §a" + this.CantThrowTime.get(p));
/*  81 */               return;
/*     */             }
/*     */             
/*  84 */             this.CantThrow.add(p);
/*     */             
/*  86 */             final Item Granade = p.getWorld().dropItem(p.getEyeLocation(), new ItemStack(Material.MONSTER_EGG));
/*     */             
/*  88 */             Granade.setVelocity(p.getLocation().getDirection().multiply(2));
/*  89 */             Granade.setPickupDelay(90000);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*  94 */             Granade.getWorld().playSound(Granade.getLocation(), Sound.CHICKEN_WALK, 1.0F, 100.0F);
/*     */             
/*     */ 
/*  97 */             Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */             {
/*     */               public void run()
/*     */               {
/* 101 */                 Granade.getWorld().playSound(Granade.getLocation(), Sound.CHICKEN_WALK, 1.0F, 100.0F);
/*     */               }
/* 103 */             }, 20L);
/*     */             
/*     */ 
/* 106 */             Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */             {
/*     */               public void run()
/*     */               {
/* 110 */                 Granade.getWorld().playSound(Granade.getLocation(), Sound.CHICKEN_WALK, 1.0F, 100.0F);
/*     */               }
/* 112 */             }, 40L);
/*     */             
/*     */ 
/* 115 */             Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */             {
/*     */               public void run()
/*     */               {
/* 119 */                 Granade.getWorld().playSound(Granade.getLocation(), Sound.CHICKEN_WALK, 1.0F, 100.0F);
/*     */               }
/* 121 */             }, 60L);
/*     */             
/*     */ 
/* 124 */             Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */             {
/*     */               public void run()
/*     */               {
/* 128 */                 Granade.getWorld().createExplosion(Granade.getLocation(), 3.0F, false);
/* 129 */                 Granade.remove();
/*     */               }
/* 131 */             }, 80L);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 136 */             RemoveCantThrow(p);
/*     */           }
/* 138 */         } catch (Exception ex) { Bukkit.getConsoleSender().sendMessage("§4Critial ERROR: §cPlease Report this to §aMr_Coding! §3ERRORCODE: §aGT_PIT_SWITCH_NO_SETDOWN");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void RemoveCantThrow(final Player p)
/*     */   {
/* 146 */     this.CantThrowTime.put(p, Integer.valueOf(10));
/*     */     
/*     */ 
/* 149 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 153 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(9));
/*     */       }
/*     */       
/* 156 */     }, 20L);
/*     */     
/* 158 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 162 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(8));
/*     */       }
/*     */       
/* 165 */     }, 40L);
/*     */     
/* 167 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 171 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(7));
/*     */       }
/*     */       
/* 174 */     }, 60L);
/*     */     
/* 176 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 180 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(6));
/*     */       }
/*     */       
/* 183 */     }, 80L);
/*     */     
/* 185 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 189 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(5));
/*     */       }
/*     */       
/* 192 */     }, 100L);
/*     */     
/* 194 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 198 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(4));
/*     */       }
/*     */       
/* 201 */     }, 120L);
/*     */     
/* 203 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 207 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(3));
/*     */       }
/*     */       
/* 210 */     }, 140L);
/*     */     
/* 212 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 216 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(2));
/*     */       }
/*     */       
/* 219 */     }, 160L);
/*     */     
/* 221 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 225 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(1));
/*     */       }
/*     */       
/* 228 */     }, 180L);
/*     */     
/* 230 */     Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 234 */         GranadeThrower.this.CantThrowTime.put(p, Integer.valueOf(0));
/* 235 */         GranadeThrower.this.CantThrow.remove(p);
/* 236 */         p.sendMessage("§2[§4TNT§6Wars§2]§d Granate Werfer §anachgeladen!");
/*     */       }
/*     */       
/* 239 */     }, 200L);
/*     */   }
/*     */ }


/* Location:              C:\Users\Andreas\Desktop\Java\Plugins\TNTWars.jar!\me\Mr_Coding\tntwars\items\GranadeThrower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */